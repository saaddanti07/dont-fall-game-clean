import type { SaveData } from "../game/storage";
import { MusicIcon, SoundIcon } from "./Icons";
import { Modal } from "./Modal";

interface Props {
  save: SaveData;
  onChange: (patch: Partial<SaveData>) => void;
  onTestSfx: () => void;
  onClose: () => void;
}

interface RowProps {
  label: string;
  on: boolean;
  volume: number;
  icon: React.ReactNode;
  onToggle: () => void;
  onVolume: (v: number) => void;
  onCommit?: () => void;
}

function Row({ label, on, volume, icon, onToggle, onVolume, onCommit }: RowProps) {
  return (
    <div className="rounded-2xl bg-black/30 p-3">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <span className={`flex h-10 w-10 items-center justify-center rounded-xl ${on ? "bg-teal-500 text-white" : "bg-[#3b2c58] text-[#a698c4]"}`}>{icon}</span>
          <span className="text-[1.1rem] font-semibold text-white">{label}</span>
        </div>
        <button
          role="switch"
          aria-checked={on}
          aria-label={`${label} ${on ? "on" : "off"}`}
          onClick={onToggle}
          className={`relative h-9 w-[68px] shrink-0 rounded-full border-[3px] border-[#1b0a3d] transition-colors ${on ? "bg-emerald-400" : "bg-[#4b3a6e]"}`}
        >
          <span className={`absolute top-0.5 h-6 w-6 rounded-full border-2 border-[#1b0a3d] bg-white transition-all ${on ? "left-[33px]" : "left-0.5"}`} />
        </button>
      </div>
      <div className={`mt-3 flex items-center gap-3 ${on ? "" : "opacity-45"}`}>
        <span className="w-9 text-[0.8rem] font-semibold uppercase tracking-wider text-violet-100">Vol</span>
        <input
          type="range"
          min={0}
          max={100}
          value={Math.round(volume * 100)}
          disabled={!on}
          onChange={(e) => onVolume(Number(e.target.value) / 100)}
          onPointerUp={onCommit}
          aria-label={`${label} volume`}
          className="h-8 flex-1 accent-[#ffc61f]"
        />
        <span className="w-10 text-right text-[0.95rem] font-bold tabular-nums text-white">{Math.round(volume * 100)}%</span>
      </div>
    </div>
  );
}

export function AudioSettingsModal({ save, onChange, onTestSfx, onClose }: Props) {
  return (
    <Modal title="Audio" onClose={onClose}>
      <div className="flex flex-col gap-3">
        <Row
          label="Music"
          on={save.musicOn}
          volume={save.musicVol}
          icon={<MusicIcon muted={!save.musicOn} className="h-6 w-6" />}
          onToggle={() => onChange({ musicOn: !save.musicOn })}
          onVolume={(v) => onChange({ musicVol: v })}
        />
        <Row
          label="Sound effects"
          on={save.sfxOn}
          volume={save.sfxVol}
          icon={<SoundIcon muted={!save.sfxOn} className="h-6 w-6" />}
          onToggle={() => onChange({ sfxOn: !save.sfxOn })}
          onVolume={(v) => onChange({ sfxVol: v })}
          onCommit={onTestSfx}
        />
      </div>
      <button className="btn btn-play mt-4 w-full text-[1.4rem]" style={{ minHeight: 58 }} onClick={onClose}>
        DONE
      </button>
    </Modal>
  );
}
