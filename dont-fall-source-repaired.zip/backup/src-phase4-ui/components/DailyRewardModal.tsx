import { DAILY_REWARDS, activeStreak, canClaimDaily, nextStreak, rewardForStreak, type SaveData } from "../game/storage";
import { CheckIcon, CoinIcon } from "./Icons";
import { Modal } from "./Modal";

interface Props {
  save: SaveData;
  onClaim: () => void;
  onClose: () => void;
}

export function DailyRewardModal({ save, onClaim, onClose }: Props) {
  const canClaim = canClaimDaily(save);
  const streakNow = canClaim ? nextStreak(save) : activeStreak(save);
  const todayIdx = (Math.max(1, streakNow) - 1) % DAILY_REWARDS.length;
  const reward = rewardForStreak(streakNow);

  return (
    <Modal title="Daily Reward" onClose={onClose}>
      <p className="mb-3 text-center text-[0.95rem] font-medium leading-snug text-violet-100">
        Come back every day to grow your streak and earn bigger rewards!
      </p>

      <div className="grid grid-cols-4 gap-2">
        {DAILY_REWARDS.map((amount, i) => {
          const claimed = canClaim ? i < todayIdx : i <= todayIdx;
          const isToday = i === todayIdx;
          return (
            <div
              key={i}
              className={`relative flex flex-col items-center gap-1 rounded-2xl border-[3px] px-1 py-2 ${
                isToday && canClaim
                  ? "border-[#ffd62e] bg-[#5a2f9e] shadow-[0_0_14px_rgba(255,214,46,0.55)]"
                  : claimed
                    ? "border-[#2c8f56] bg-[#1d4a46]"
                    : "border-white/15 bg-black/30"
              } ${i === 6 ? "col-span-2" : ""}`}
            >
              <span className="text-[0.7rem] font-bold uppercase tracking-wider text-violet-100">Day {i + 1}</span>
              {claimed ? (
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-emerald-400 text-[#06361b]">
                  <CheckIcon className="h-4 w-4" />
                </span>
              ) : (
                <CoinIcon className="h-7 w-7" />
              )}
              <span className="font-display text-[1.05rem] leading-none text-white">{amount}</span>
            </div>
          );
        })}
      </div>

      <div className="mt-4">
        {canClaim ? (
          <button className="btn btn-gold w-full gap-2 text-[1.35rem]" style={{ minHeight: 60 }} onClick={onClaim}>
            <CoinIcon className="h-8 w-8" /> CLAIM +{reward}
          </button>
        ) : (
          <div className="flex flex-col items-center gap-1">
            <button className="btn btn-muted w-full text-[1.15rem]" style={{ minHeight: 56 }} disabled>
              CLAIMED TODAY ✓
            </button>
            <span className="mt-2 text-center text-[0.9rem] font-medium text-violet-100">
              Come back tomorrow for +{rewardForStreak(streakNow + 1)} coins
            </span>
          </div>
        )}
      </div>
    </Modal>
  );
}
