import { AudioToggles } from "./AudioToggles";
import { CaveBackground } from "./CaveBackground";
import { CoinCounter } from "./CoinCounter";
import { CoinIcon, FlameIcon, SlidersIcon, TrophyIcon } from "./Icons";
import { MenuCharacter } from "./MenuCharacter";
import { StackedTitle } from "./StackedTitle";

interface Props {
  coins: number;
  best: number;
  streak: number;
  musicOn: boolean;
  sfxOn: boolean;
  dailyReady: boolean;
  onPlay: () => void;
  onDaily: () => void;
  onAudioSettings: () => void;
  onToggleMusic: () => void;
  onToggleSfx: () => void;
}

export function MainMenu(p: Props) {
  return (
    <div className="relative h-full w-full">
      <CaveBackground />

      <div
        className="relative z-10 flex h-full flex-col px-4"
        style={{
          paddingTop: "max(28px, calc(env(safe-area-inset-top) + 12px))",
          paddingBottom: "calc(26px + env(safe-area-inset-bottom) + 10px)",
        }}
      >
        {/* TOP: title + coins + audio */}
        <header className="flex shrink-0 flex-col items-center gap-[min(2dvh,14px)]">
          <StackedTitle lines={["DON'T", "FALL!"]} label="DON'T FALL!" />
          <div className="flex w-full items-center justify-between">
            <CoinCounter value={p.coins} />
            <AudioToggles musicOn={p.musicOn} sfxOn={p.sfxOn} onMusic={p.onToggleMusic} onSfx={p.onToggleSfx} />
          </div>
        </header>

        {/* CENTER: hero, subtitle, stats */}
        <main className="flex min-h-0 flex-1 flex-col items-center justify-center gap-[min(1.4dvh,10px)] py-2">
          <div className="relative min-h-[84px] w-full max-w-[300px] flex-1">
            <MenuCharacter />
          </div>
          <p className="text-outline shrink-0 text-center text-[clamp(0.95rem,4.2vw,1.15rem)] font-semibold leading-tight text-white">
            Climb. Bounce. Outrun the lava!
          </p>
          <div className="panel grid w-full max-w-[340px] shrink-0 grid-cols-2 divide-x-2 divide-white/10 py-2">
            <div className="flex flex-col items-center gap-1.5 px-2">
              <span className="panel-label flex items-center gap-1.5">
                <TrophyIcon className="h-4 w-4" /> Best
              </span>
              <span className="value-text text-[1.5rem] leading-none tabular-nums">{p.best.toLocaleString()}</span>
            </div>
            <div className="flex flex-col items-center gap-1.5 px-2">
              <span className="panel-label flex items-center gap-1.5">
                <FlameIcon className="h-4 w-4" /> Streak
              </span>
              <span className="value-text text-[1.5rem] leading-none tabular-nums">
                {p.streak}
                <span className="ml-1 font-body text-[0.8rem] font-semibold tracking-normal text-violet-100">{p.streak === 1 ? "day" : "days"}</span>
              </span>
            </div>
          </div>
        </main>

        {/* LOWER CENTER: play */}
        <div className="shrink-0 px-2 pb-[min(2.4dvh,16px)] pt-1">
          <button className="btn btn-play w-full text-[clamp(2rem,10vw,2.8rem)] leading-none" style={{ minHeight: "clamp(64px,10dvh,84px)" }} onClick={p.onPlay}>
            PLAY
          </button>
        </div>

        {/* BOTTOM: daily reward + audio settings */}
        <footer className="panel flex shrink-0 items-stretch gap-2.5 rounded-3xl p-2.5">
          <button className="btn btn-gold flex-1 gap-1.5 whitespace-nowrap px-2 text-[clamp(0.8rem,3.9vw,1.2rem)]" onClick={p.onDaily}>
            <CoinIcon className="h-7 w-7 shrink-0" />
            <span className="flex flex-col items-start leading-none">
              <span>Daily Reward</span>
              <span className="mt-1 font-body text-[0.7rem] font-bold tracking-normal">{p.dailyReady ? "Ready to claim!" : "Come back tomorrow"}</span>
            </span>
            {p.dailyReady && (
              <span
                className="absolute -right-1.5 -top-2 flex h-6 w-6 items-center justify-center rounded-full border-2 border-white bg-red-500 font-body text-sm font-bold text-white"
                style={{ animation: "badgePulse 1.2s ease-in-out infinite" }}
                aria-hidden="true"
              >
                !
              </span>
            )}
          </button>
          <button className="btn btn-purple w-[34%] shrink-0 flex-col gap-0.5 px-1 text-[0.95rem]" onClick={p.onAudioSettings} aria-label="Audio settings">
            <SlidersIcon className="h-6 w-6" />
            <span className="leading-none">Audio</span>
          </button>
        </footer>
      </div>
    </div>
  );
}
