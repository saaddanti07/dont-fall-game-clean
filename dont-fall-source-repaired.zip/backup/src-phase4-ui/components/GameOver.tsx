import { CoinIcon, HomeIcon, RestartIcon, TrophyIcon } from "./Icons";
import { StackedTitle } from "./StackedTitle";

interface Props {
  score: number;
  best: number;
  coins: number;
  newBest: boolean;
  onRestart: () => void;
  onMenu: () => void;
}

export function GameOver({ score, best, coins, newBest, onRestart, onMenu }: Props) {
  return (
    <div
      className="fade-in absolute inset-0 z-20 flex flex-col items-center justify-center gap-[min(2.6dvh,20px)] overflow-y-auto px-5"
      style={{
        background: "radial-gradient(ellipse at 50% 40%, rgba(60,20,110,0.88), rgba(10,3,22,0.94))",
        paddingTop: "max(20px, env(safe-area-inset-top))",
        paddingBottom: "max(20px, env(safe-area-inset-bottom))",
      }}
    >
      <StackedTitle lines={["GAME", "OVER!"]} label="Game Over" />

      <div className="pop-in panel flex w-full max-w-[340px] flex-col items-center gap-3 rounded-3xl px-4 py-4">
        <div className="flex flex-col items-center gap-2">
          <span className="panel-label">Final score</span>
          <span className="value-text text-[clamp(3rem,16vw,4.2rem)] leading-none tabular-nums">{score.toLocaleString()}</span>
          {newBest && (
            <span className="rounded-full border-2 border-[#5a2f00] bg-gradient-to-b from-[#fff29a] to-[#ffb300] px-3 py-1 text-xs font-bold uppercase tracking-wider text-[#3b1a00]">
              ★ New best! ★
            </span>
          )}
        </div>

        <div className="grid w-full grid-cols-2 gap-2.5">
          <div className="flex flex-col items-center gap-1.5 rounded-2xl bg-black/30 py-2.5">
            <span className="panel-label flex items-center gap-1.5">
              <TrophyIcon className="h-4 w-4" /> Best
            </span>
            <span className="value-text text-[1.5rem] leading-none tabular-nums">{best.toLocaleString()}</span>
          </div>
          <div className="flex flex-col items-center gap-1.5 rounded-2xl bg-black/30 py-2.5">
            <span className="panel-label flex items-center gap-1.5">
              <CoinIcon className="h-4 w-4" /> Coins
            </span>
            <span className="value-text text-[1.5rem] leading-none tabular-nums">+{coins}</span>
          </div>
        </div>
      </div>

      <div className="pop-in flex w-full max-w-[340px] flex-col gap-3.5">
        <button className="btn btn-play min-h-[68px] gap-2.5 text-[1.9rem]" onClick={onRestart}>
          <RestartIcon className="h-7 w-7" /> RESTART
        </button>
        <button className="btn btn-purple min-h-[56px] gap-2 text-[1.2rem]" onClick={onMenu}>
          <HomeIcon className="h-6 w-6" /> MAIN MENU
        </button>
      </div>
    </div>
  );
}
