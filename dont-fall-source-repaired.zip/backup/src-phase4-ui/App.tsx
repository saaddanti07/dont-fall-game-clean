import { useCallback, useEffect, useRef, useState } from "react";
import { AudioSettingsModal } from "./components/AudioSettingsModal";
import { DailyRewardModal } from "./components/DailyRewardModal";
import { GameOver } from "./components/GameOver";
import { GameScreen } from "./components/GameScreen";
import { MainMenu } from "./components/MainMenu";
import { audio } from "./game/audio";
import { activeStreak, canClaimDaily, dayKey, loadSave, nextStreak, persist, rewardForStreak, type SaveData } from "./game/storage";

type Screen = "menu" | "playing" | "over";
type ModalName = "daily" | "audio" | null;

interface RunResult {
  score: number;
  coins: number;
  newBest: boolean;
}

export default function App() {
  const [save, setSave] = useState<SaveData>(loadSave);
  const [screen, setScreen] = useState<Screen>("menu");
  const [modal, setModal] = useState<ModalName>(null);
  const [runKey, setRunKey] = useState(0);
  const [result, setResult] = useState<RunResult>({ score: 0, coins: 0, newBest: false });
  const saveRef = useRef(save);
  saveRef.current = save;

  // persist + apply audio settings whenever the save changes
  useEffect(() => {
    persist(save);
    audio.configure(save);
  }, [save]);

  const update = useCallback((patch: Partial<SaveData>) => setSave((s) => ({ ...s, ...patch })), []);

  const click = () => {
    audio.unlock();
    audio.sfx("click");
  };

  const play = () => {
    click();
    setModal(null);
    setRunKey((k) => k + 1);
    setScreen("playing");
  };

  const onCoin = useCallback(() => setSave((s) => ({ ...s, coins: s.coins + 1 })), []);

  const onGameOver = useCallback((r: { score: number; coins: number }) => {
    const newBest = r.score > saveRef.current.best;
    setSave((s) => ({ ...s, best: Math.max(s.best, r.score) }));
    setResult({ ...r, newBest });
    setScreen("over");
  }, []);

  const claimDaily = () => {
    const s = saveRef.current;
    if (!canClaimDaily(s)) return;
    const streak = nextStreak(s);
    audio.sfx("reward");
    update({ coins: s.coins + rewardForStreak(streak), streak, lastClaim: dayKey() });
  };

  const streak = activeStreak(save);

  return (
    <div className="fixed inset-0 flex justify-center bg-[#0d0418]">
      <div className="relative h-full w-full max-w-[480px] overflow-hidden font-body shadow-[0_0_60px_rgba(120,60,200,0.35)]">
        {screen === "menu" && (
          <MainMenu
            coins={save.coins}
            best={save.best}
            streak={streak}
            musicOn={save.musicOn}
            sfxOn={save.sfxOn}
            dailyReady={canClaimDaily(save)}
            onPlay={play}
            onDaily={() => {
              click();
              setModal("daily");
            }}
            onAudioSettings={() => {
              click();
              setModal("audio");
            }}
            onToggleMusic={() => {
              audio.unlock();
              update({ musicOn: !save.musicOn });
              audio.sfx("click");
            }}
            onToggleSfx={() => {
              audio.unlock();
              update({ sfxOn: !save.sfxOn });
              // play the click only when turning sounds on
              if (!save.sfxOn) setTimeout(() => audio.sfx("click"), 30);
            }}
          />
        )}

        {(screen === "playing" || screen === "over") && (
          <GameScreen key={runKey} onCoin={onCoin} onGameOver={onGameOver} onExit={() => setScreen("menu")} />
        )}

        {screen === "over" && (
          <GameOver
            score={result.score}
            best={save.best}
            coins={result.coins}
            newBest={result.newBest}
            onRestart={play}
            onMenu={() => {
              click();
              setScreen("menu");
            }}
          />
        )}

        {modal === "daily" && screen === "menu" && <DailyRewardModal save={save} onClaim={claimDaily} onClose={() => setModal(null)} />}
        {modal === "audio" && screen === "menu" && (
          <AudioSettingsModal save={save} onChange={update} onTestSfx={() => audio.sfx("click")} onClose={() => setModal(null)} />
        )}
      </div>
    </div>
  );
}
