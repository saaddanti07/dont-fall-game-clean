// Persistent save data: coins, best score, daily reward streak and audio settings.

export interface SaveData {
  coins: number;
  best: number;
  streak: number; // consecutive days a daily reward was claimed
  lastClaim: string | null; // YYYY-MM-DD (local)
  musicOn: boolean;
  sfxOn: boolean;
  musicVol: number;
  sfxVol: number;
}

const KEY = "dontfall.save.v1";

export const DAILY_REWARDS = [10, 20, 30, 40, 50, 75, 100];

const defaults: SaveData = {
  coins: 0,
  best: 0,
  streak: 0,
  lastClaim: null,
  musicOn: true,
  sfxOn: true,
  musicVol: 0.6,
  sfxVol: 0.8,
};

export function loadSave(): SaveData {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { ...defaults };
    return { ...defaults, ...JSON.parse(raw) };
  } catch {
    return { ...defaults };
  }
}

export function persist(data: SaveData) {
  try {
    localStorage.setItem(KEY, JSON.stringify(data));
  } catch {
    /* storage unavailable */
  }
}

export function dayKey(d = new Date()): string {
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${m}-${day}`;
}

function yesterdayKey(): string {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return dayKey(d);
}

export function canClaimDaily(save: SaveData): boolean {
  return save.lastClaim !== dayKey();
}

/** Streak that is still alive (claimed today or yesterday). */
export function activeStreak(save: SaveData): number {
  if (!save.lastClaim) return 0;
  if (save.lastClaim === dayKey() || save.lastClaim === yesterdayKey()) return save.streak;
  return 0;
}

/** Streak value the next claim would produce. */
export function nextStreak(save: SaveData): number {
  return activeStreak(save) + 1;
}

export function rewardForStreak(streak: number): number {
  return DAILY_REWARDS[(Math.max(1, streak) - 1) % DAILY_REWARDS.length];
}
