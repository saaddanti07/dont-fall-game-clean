// Tiny WebAudio synth: sound effects + looping cave music. No external assets.

type SfxName = "jump" | "coin" | "crumble" | "die" | "click" | "reward" | "spring";

class AudioEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private musicOn = true;
  private sfxOn = true;
  private musicVol = 0.6;
  private sfxVol = 0.8;
  private timer: number | null = null;
  private step = 0;
  private nextTime = 0;

  /** Must be called from a user gesture at least once. */
  unlock() {
    if (!this.ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.9;
      this.master.connect(this.ctx.destination);
      this.musicGain = this.ctx.createGain();
      this.sfxGain = this.ctx.createGain();
      this.musicGain.connect(this.master);
      this.sfxGain.connect(this.master);
      this.applyVolumes();
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
    this.syncMusic();
  }

  configure(s: { musicOn: boolean; sfxOn: boolean; musicVol: number; sfxVol: number }) {
    this.musicOn = s.musicOn;
    this.sfxOn = s.sfxOn;
    this.musicVol = s.musicVol;
    this.sfxVol = s.sfxVol;
    this.applyVolumes();
    this.syncMusic();
  }

  private applyVolumes() {
    if (!this.ctx || !this.musicGain || !this.sfxGain) return;
    this.musicGain.gain.setTargetAtTime(this.musicOn ? this.musicVol * 0.22 : 0, this.ctx.currentTime, 0.05);
    this.sfxGain.gain.setTargetAtTime(this.sfxOn ? this.sfxVol * 0.5 : 0, this.ctx.currentTime, 0.02);
  }

  private tone(freq: number, start: number, dur: number, type: OscillatorType, vol: number, dest: AudioNode, slideTo?: number) {
    if (!this.ctx) return;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, start);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, start + dur);
    g.gain.setValueAtTime(0.0001, start);
    g.gain.exponentialRampToValueAtTime(vol, start + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, start + dur);
    o.connect(g);
    g.connect(dest);
    o.start(start);
    o.stop(start + dur + 0.05);
  }

  sfx(name: SfxName) {
    if (!this.ctx || !this.sfxGain || !this.sfxOn) return;
    const t = this.ctx.currentTime;
    const d = this.sfxGain;
    switch (name) {
      case "jump":
        this.tone(320, t, 0.18, "square", 0.35, d, 640);
        break;
      case "spring":
        this.tone(260, t, 0.3, "square", 0.35, d, 980);
        break;
      case "coin":
        this.tone(988, t, 0.08, "square", 0.3, d);
        this.tone(1319, t + 0.07, 0.18, "square", 0.3, d);
        break;
      case "crumble":
        this.tone(140, t, 0.25, "sawtooth", 0.35, d, 50);
        break;
      case "die":
        this.tone(440, t, 0.7, "sawtooth", 0.4, d, 70);
        this.tone(330, t + 0.1, 0.7, "square", 0.25, d, 50);
        break;
      case "click":
        this.tone(520, t, 0.07, "triangle", 0.4, d, 700);
        break;
      case "reward":
        [523, 659, 784, 1047].forEach((f, i) => this.tone(f, t + i * 0.09, 0.2, "square", 0.3, d));
        break;
    }
  }

  // --- music: a simple minor arpeggio over a bass line --------------------
  private readonly bass = [110, 110, 87.31, 98];
  private readonly arp = [440, 523.25, 659.25, 523.25, 392, 466.16, 587.33, 466.16];

  private syncMusic() {
    if (!this.ctx) return;
    if (this.musicOn && this.timer === null) {
      this.nextTime = this.ctx.currentTime + 0.05;
      this.timer = window.setInterval(() => this.schedule(), 100);
    } else if (!this.musicOn && this.timer !== null) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  private schedule() {
    if (!this.ctx || !this.musicGain) return;
    const stepDur = 0.19;
    while (this.nextTime < this.ctx.currentTime + 0.3) {
      const s = this.step;
      const bar = Math.floor(s / 8) % 4;
      this.tone(this.arp[s % 8] * (bar === 2 ? 0.794 : bar === 3 ? 0.891 : 1), this.nextTime, 0.16, "triangle", 0.5, this.musicGain);
      if (s % 4 === 0) this.tone(this.bass[bar], this.nextTime, 0.6, "sine", 0.9, this.musicGain);
      this.step = (this.step + 1) % 32;
      this.nextTime += stepDur;
    }
  }
}

export const audio = new AudioEngine();
