// DON'T FALL game engine: physics, platform generation, lava, difficulty, coins and rendering.

import { audio } from "./audio";
import { drawCoin, drawPlatform, drawPlayer, type PlatformKind } from "./sprites";

export const WORLD_W = 360;

// --- tuning (gameplay constants) ------------------------------------------
const GRAVITY = 1400;
const JUMP_V = 720;
const MOVE_SPEED = 230;
const PLAYER_HALF_W = 12;
const SCORE_DIV = 10; // world px per score point

export interface GameCallbacks {
  onScore: (score: number) => void;
  onCoin: (runCoins: number) => void;
  onGameOver: (result: { score: number; coins: number }) => void;
}

interface Platform {
  x: number;
  y: number;
  w: number;
  kind: PlatformKind;
  dir: number;
  speed: number;
  crumbling: boolean;
  crumbleT: number;
  dead: boolean;
}

interface Coin {
  x: number;
  y: number;
  taken: boolean;
  phase: number;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  color: string;
  size: number;
}

function hash(n: number) {
  const s = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return s - Math.floor(s);
}

export class Game {
  private ctx: CanvasRenderingContext2D;
  private raf = 0;
  private last = 0;
  private time = 0;
  private scale = 1;
  private viewH = 640;

  private platforms: Platform[] = [];
  private coins: Coin[] = [];
  private particles: Particle[] = [];
  private genY = 0;
  private lastWasCrumble = false;
  private lastCenter = WORLD_W / 2;

  private px = WORLD_W / 2;
  private py = 0;
  private vx = 0;
  private vy = 0;
  private facing = 1;
  private stretch = 1;
  private camY = 0;
  private lavaY = 260;
  private maxHeight = 0;
  private score = 0;
  private runCoins = 0;
  private dir = 0;
  private paused = false;
  private state: "playing" | "dying" | "over" = "playing";
  private dyingT = 0;

  constructor(private canvas: HTMLCanvasElement, private cb: GameCallbacks) {
    this.ctx = canvas.getContext("2d")!;
    this.reset();
  }

  // --- public API ---------------------------------------------------------
  start() {
    this.last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(0.033, (now - this.last) / 1000);
      this.last = now;
      if (!this.paused && this.state !== "over") this.update(dt);
      this.time += this.paused ? 0 : dt;
      this.render();
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  }

  destroy() {
    cancelAnimationFrame(this.raf);
  }

  setPaused(p: boolean) {
    this.paused = p;
  }

  setInput(dir: number) {
    this.dir = dir;
  }

  resize(cssW: number, cssH: number, dpr: number) {
    this.canvas.width = Math.round(cssW * dpr);
    this.canvas.height = Math.round(cssH * dpr);
    this.scale = cssW / WORLD_W;
    this.viewH = cssH / this.scale;
    this.ctx.setTransform(this.scale * dpr, 0, 0, this.scale * dpr, 0, 0);
    // keep camera consistent with start layout if the run hasn't begun
    if (this.maxHeight === 0 && this.state === "playing") this.camY = -this.viewH * 0.72;
  }

  reset() {
    this.platforms = [];
    this.coins = [];
    this.particles = [];
    this.px = WORLD_W / 2;
    this.py = 0;
    this.vx = 0;
    this.vy = -JUMP_V;
    this.facing = 1;
    this.stretch = 1;
    this.camY = -this.viewH * 0.72;
    this.lavaY = 260;
    this.maxHeight = 0;
    this.score = 0;
    this.runCoins = 0;
    this.state = "playing";
    this.dyingT = 0;
    this.lastWasCrumble = false;
    this.lastCenter = WORLD_W / 2;
    // wide starting ground
    this.platforms.push({ x: 40, y: 0, w: WORLD_W - 80, kind: "normal", dir: 0, speed: 0, crumbling: false, crumbleT: 0, dead: false });
    this.genY = 0;
    this.generate();
  }

  // --- difficulty -----------------------------------------------------------
  private difficulty(score: number) {
    return Math.min(1, score / 2000);
  }

  private lavaSpeed() {
    const d = this.difficulty(this.score);
    const grace = Math.min(1, this.time / 2.5); // gentle start
    return (24 + 78 * d) * grace;
  }

  // --- platform generation ----------------------------------------------------
  private generate() {
    while (this.genY > this.camY - 320) {
      const score = -this.genY / SCORE_DIV;
      const d = this.difficulty(score);
      const gap = Math.min(138, 62 + 70 * d + Math.random() * 22);
      const y = this.genY - gap;
      const w = (84 - 32 * d) * (0.92 + Math.random() * 0.22);
      let x = this.lastCenter + (Math.random() - 0.5) * 340 - w / 2;
      x = Math.max(4, Math.min(WORLD_W - w - 4, x));

      let kind: PlatformKind = "normal";
      const r = Math.random();
      if (score > 120 && r < 0.1 + 0.3 * d) kind = "moving";
      else if (score > 250 && !this.lastWasCrumble && r > 0.9 - 0.2 * d) kind = "crumble";
      this.lastWasCrumble = kind === "crumble";

      const p: Platform = {
        x,
        y,
        w,
        kind,
        dir: Math.random() < 0.5 ? -1 : 1,
        speed: 40 + Math.random() * 50,
        crumbling: false,
        crumbleT: 0,
        dead: false,
      };
      this.platforms.push(p);
      this.lastCenter = x + w / 2;
      this.genY = y;

      if (Math.random() < 0.38) {
        this.coins.push({ x: x + w / 2, y: y - 42, taken: false, phase: Math.random() * 6 });
      }
    }
    // cull anything well below the screen
    const bottom = this.camY + this.viewH + 150;
    this.platforms = this.platforms.filter((p) => p.y < bottom && !p.dead);
    this.coins = this.coins.filter((c) => c.y < bottom && !c.taken);
  }

  private burst(x: number, y: number, n: number, colors: string[], power: number) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = (0.3 + Math.random()) * power;
      this.particles.push({
        x,
        y,
        vx: Math.cos(a) * s,
        vy: Math.sin(a) * s - power * 0.3,
        life: 0,
        max: 0.4 + Math.random() * 0.5,
        color: colors[Math.floor(Math.random() * colors.length)],
        size: 2 + Math.random() * 3,
      });
    }
  }

  // --- simulation -----------------------------------------------------------------
  private update(dt: number) {
    // particles
    for (const p of this.particles) {
      p.life += dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vy += 500 * dt;
    }
    this.particles = this.particles.filter((p) => p.life < p.max);

    // lava always rises
    this.lavaY -= this.lavaSpeed() * dt;
    const camBottom = this.camY + this.viewH;
    this.lavaY = Math.min(this.lavaY, camBottom + 220);

    for (const p of this.platforms) {
      if (p.kind === "moving" && !p.dead) {
        p.x += p.dir * p.speed * dt;
        if (p.x < 2) {
          p.x = 2;
          p.dir = 1;
        } else if (p.x + p.w > WORLD_W - 2) {
          p.x = WORLD_W - 2 - p.w;
          p.dir = -1;
        }
      }
      if (p.crumbling) {
        p.crumbleT += dt;
        if (p.crumbleT >= 0.5) p.dead = true;
      }
    }

    if (this.state === "dying") {
      this.dyingT += dt;
      if (this.dyingT > 0.9) {
        this.state = "over";
        this.cb.onGameOver({ score: this.score, coins: this.runCoins });
      }
      return;
    }

    // horizontal movement
    const target = this.dir * MOVE_SPEED;
    this.vx += (target - this.vx) * Math.min(1, dt * 10);
    this.px += this.vx * dt;
    if (this.px < -PLAYER_HALF_W) this.px = WORLD_W + PLAYER_HALF_W;
    else if (this.px > WORLD_W + PLAYER_HALF_W) this.px = -PLAYER_HALF_W;
    if (this.vx > 15) this.facing = 1;
    else if (this.vx < -15) this.facing = -1;

    // vertical movement + platform collision
    const prevFeet = this.py;
    this.vy += GRAVITY * dt;
    this.py += this.vy * dt;
    this.stretch += (1 - this.stretch) * Math.min(1, dt * 9);

    if (this.vy > 0) {
      for (const p of this.platforms) {
        if (p.dead) continue;
        if (prevFeet <= p.y + 1 && this.py >= p.y && this.px > p.x - 8 && this.px < p.x + p.w + 8) {
          this.py = p.y;
          this.vy = -JUMP_V;
          this.stretch = 0.78;
          audio.sfx("jump");
          this.burst(this.px, p.y, 6, ["#e9d8ff", "#b9a0ee"], 70);
          if (p.kind === "crumble" && !p.crumbling) {
            p.crumbling = true;
            audio.sfx("crumble");
          }
          break;
        }
      }
    }
    if (this.vy < -300) this.stretch += (1.12 - this.stretch) * Math.min(1, dt * 6);

    // coins
    for (const c of this.coins) {
      if (c.taken) continue;
      const dx = c.x - this.px;
      const dy = c.y - (this.py - 22);
      if (dx * dx + dy * dy < 30 * 30) {
        c.taken = true;
        this.runCoins++;
        audio.sfx("coin");
        this.burst(c.x, c.y, 8, ["#ffe066", "#fff6b0", "#f59e0b"], 90);
        this.cb.onCoin(this.runCoins);
      }
    }

    // score
    if (-this.py > this.maxHeight) {
      this.maxHeight = -this.py;
      const s = Math.floor(this.maxHeight / SCORE_DIV);
      if (s !== this.score) {
        this.score = s;
        this.cb.onScore(s);
      }
    }

    // camera follows upward progress only
    const camTarget = this.py - this.viewH * 0.42;
    if (camTarget < this.camY) this.camY += (camTarget - this.camY) * Math.min(1, dt * 9);

    this.generate();

    // death: lava or falling off the bottom
    if (this.py > this.lavaY + 2 || this.py > this.camY + this.viewH + 80) {
      this.state = "dying";
      this.dyingT = 0;
      audio.sfx("die");
      this.burst(this.px, Math.min(this.py, this.lavaY), 22, ["#ff7a18", "#ffd23f", "#ff3d00"], 200);
    }
  }

  // --- rendering --------------------------------------------------------------------
  private render() {
    const ctx = this.ctx;
    const W = WORLD_W;
    const H = this.viewH;
    const cam = this.camY;

    // cave background
    const bg = ctx.createLinearGradient(0, 0, 0, H);
    bg.addColorStop(0, "#1a0833");
    bg.addColorStop(0.6, "#2e1058");
    bg.addColorStop(1, "#4a1a7c");
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, W, H);

    this.drawBackdrop(ctx, W, H, cam);

    // coins
    for (const c of this.coins) {
      if (c.taken) continue;
      const sy = c.y - cam;
      if (sy < -30 || sy > H + 30) continue;
      drawCoin(ctx, c.x, sy + Math.sin(this.time * 3 + c.phase) * 3, 10, this.time * 4 + c.phase);
    }

    // platforms
    for (const p of this.platforms) {
      const sy = p.y - cam;
      if (sy < -30 || sy > H + 30) continue;
      drawPlatform(ctx, p.x, sy, p.w, p.kind, p.crumbling ? Math.min(1, p.crumbleT / 0.5) : 0);
    }

    // player (hidden once swallowed by lava)
    const feetScreen = this.py - cam;
    const lavaScreen = this.lavaY - cam;
    if (!(this.state !== "playing" && this.py > this.lavaY)) {
      const phase = this.time * 4;
      drawPlayer(ctx, this.px, feetScreen, this.facing, this.stretch, phase);
      // wrap-around ghost
      if (this.px < PLAYER_HALF_W + 10) drawPlayer(ctx, this.px + W + PLAYER_HALF_W * 2, feetScreen, this.facing, this.stretch, phase);
      if (this.px > W - PLAYER_HALF_W - 10) drawPlayer(ctx, this.px - W - PLAYER_HALF_W * 2, feetScreen, this.facing, this.stretch, phase);
    }

    // particles
    for (const p of this.particles) {
      ctx.globalAlpha = Math.max(0, 1 - p.life / p.max);
      ctx.fillStyle = p.color;
      ctx.fillRect(p.x - p.size / 2, p.y - cam - p.size / 2, p.size, p.size);
    }
    ctx.globalAlpha = 1;

    this.drawLava(ctx, W, H, lavaScreen);

    // danger glow when lava is close
    const dist = lavaScreen - feetScreen;
    if (this.state === "playing" && dist < 170) {
      const a = (1 - Math.max(0, dist) / 170) * (0.28 + 0.1 * Math.sin(this.time * 9));
      const g = ctx.createLinearGradient(0, H, 0, H - 260);
      g.addColorStop(0, `rgba(255,60,20,${a})`);
      g.addColorStop(1, "rgba(255,60,20,0)");
      ctx.fillStyle = g;
      ctx.fillRect(0, H - 260, W, 260);
    }
  }

  private drawBackdrop(ctx: CanvasRenderingContext2D, W: number, H: number, cam: number) {
    // far crystals (slow parallax)
    const tile = 260;
    const off = cam * 0.25;
    const first = Math.floor(off / tile) - 1;
    const last = Math.ceil((off + H) / tile) + 1;
    for (let i = first; i <= last; i++) {
      for (let k = 0; k < 3; k++) {
        const seed = i * 7 + k * 13;
        const x = hash(seed) * W;
        const y = i * tile + hash(seed + 1) * tile - off;
        const s = 14 + hash(seed + 2) * 26;
        const hue = hash(seed + 3) > 0.5 ? "rgba(190,130,255," : "rgba(110,220,255,";
        ctx.fillStyle = hue + "0.16)";
        ctx.beginPath();
        ctx.moveTo(x, y - s * 1.6);
        ctx.lineTo(x + s * 0.5, y);
        ctx.lineTo(x - s * 0.5, y);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = hue + "0.1)";
        ctx.beginPath();
        ctx.moveTo(x + s * 0.7, y - s);
        ctx.lineTo(x + s * 1.1, y);
        ctx.lineTo(x + s * 0.3, y);
        ctx.closePath();
        ctx.fill();
      }
    }
    // cave walls (medium parallax)
    const wallOff = cam * 0.6;
    const step = 46;
    const a = Math.floor(wallOff / step) - 1;
    const b = Math.ceil((wallOff + H) / step) + 1;
    ctx.fillStyle = "#150626";
    ctx.beginPath();
    ctx.moveTo(0, -10);
    for (let i = a; i <= b; i++) ctx.lineTo(8 + hash(i) * 14, i * step - wallOff);
    ctx.lineTo(0, H + 10);
    ctx.closePath();
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(W, -10);
    for (let i = a; i <= b; i++) ctx.lineTo(W - 8 - hash(i + 99) * 14, i * step - wallOff);
    ctx.lineTo(W, H + 10);
    ctx.closePath();
    ctx.fill();
  }

  private drawLava(ctx: CanvasRenderingContext2D, W: number, H: number, ly: number) {
    if (ly > H + 20) return;
    const t = this.time;
    // glow above surface
    const glow = ctx.createLinearGradient(0, ly - 110, 0, ly);
    glow.addColorStop(0, "rgba(255,90,20,0)");
    glow.addColorStop(1, "rgba(255,110,30,0.4)");
    ctx.fillStyle = glow;
    ctx.fillRect(0, ly - 110, W, 110);

    const wave = (x: number) => Math.sin(x * 0.045 + t * 2.2) * 5 + Math.sin(x * 0.11 - t * 3.1) * 2.5;
    const body = ctx.createLinearGradient(0, ly, 0, ly + 140);
    body.addColorStop(0, "#ffc233");
    body.addColorStop(0.12, "#ff7a18");
    body.addColorStop(0.55, "#e0310f");
    body.addColorStop(1, "#8c0f08");
    ctx.fillStyle = body;
    ctx.beginPath();
    ctx.moveTo(0, H + 20);
    for (let x = 0; x <= W; x += 6) ctx.lineTo(x, ly + wave(x));
    ctx.lineTo(W, H + 20);
    ctx.closePath();
    ctx.fill();

    // bright crest line
    ctx.strokeStyle = "#ffe28a";
    ctx.lineWidth = 3;
    ctx.lineJoin = "round";
    ctx.beginPath();
    for (let x = 0; x <= W; x += 6) {
      const y = ly + wave(x);
      if (x === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    // bubbles
    ctx.fillStyle = "rgba(255,220,120,0.75)";
    for (let i = 0; i < 7; i++) {
      const bx = hash(i * 3.3) * W;
      const ph = (t * 0.5 + hash(i) * 3) % 1;
      const by = ly + 40 - ph * 55 + wave(bx);
      const r = 2 + hash(i + 5) * 3.5 * (1 - ph);
      ctx.beginPath();
      ctx.arc(bx, by, r, 0, Math.PI * 2);
      ctx.fill();
    }
  }
}
