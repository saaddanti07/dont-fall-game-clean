// Canvas drawing helpers shared by the game and the menu (original adventurer character).

const OUT = "#26102f";

function rr(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

/**
 * Draws the adventurer with its feet at (x, y).
 * facing: 1 = right, -1 = left. stretch: vertical scale (jump squash/stretch). legPhase: 0..1 leg swing.
 */
export function drawPlayer(ctx: CanvasRenderingContext2D, x: number, y: number, facing: number, stretch = 1, legPhase = 0) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(facing * (1 / Math.sqrt(stretch)), stretch);
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  ctx.lineWidth = 2.5;
  ctx.strokeStyle = OUT;

  // backpack (behind body)
  ctx.fillStyle = "#8a5a2b";
  rr(ctx, -17, -27, 11, 16, 4);
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = "#c28a4a";
  rr(ctx, -15, -24, 7, 4, 2);
  ctx.fill();

  // boots
  const swing = Math.sin(legPhase * Math.PI * 2) * 2;
  ctx.fillStyle = "#5b3418";
  rr(ctx, -9 + swing, -8, 8, 8, 3);
  ctx.fill();
  ctx.stroke();
  rr(ctx, 1 - swing, -8, 8, 8, 3);
  ctx.fill();
  ctx.stroke();

  // body / jacket
  const g = ctx.createLinearGradient(0, -28, 0, -8);
  g.addColorStop(0, "#ff9f43");
  g.addColorStop(1, "#e2671c");
  ctx.fillStyle = g;
  rr(ctx, -10, -27, 20, 20, 7);
  ctx.fill();
  ctx.stroke();
  // belt
  ctx.fillStyle = "#4a2a14";
  ctx.fillRect(-9.5, -14, 19, 3.5);
  ctx.fillStyle = "#ffd23f";
  ctx.fillRect(-2, -14.5, 4.5, 4.5);

  // arm
  ctx.fillStyle = "#ff9f43";
  rr(ctx, 4, -25, 6, 12, 3);
  ctx.fill();
  ctx.stroke();

  // scarf
  ctx.fillStyle = "#e63946";
  rr(ctx, -10, -30, 20, 6, 3);
  ctx.fill();
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(-9, -26);
  ctx.lineTo(-17, -22 + swing * 0.5);
  ctx.lineTo(-10, -22);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // head
  ctx.fillStyle = "#ffd7b0";
  ctx.beginPath();
  ctx.arc(0, -36, 10, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // eyes
  ctx.fillStyle = "#fff";
  ctx.beginPath();
  ctx.ellipse(3.5, -36, 3.4, 4, 0, 0, Math.PI * 2);
  ctx.ellipse(-3, -36, 3, 3.6, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = OUT;
  ctx.beginPath();
  ctx.arc(4.6, -35.5, 1.8, 0, Math.PI * 2);
  ctx.arc(-2, -35.5, 1.6, 0, Math.PI * 2);
  ctx.fill();
  // smile
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.arc(2, -32, 3, 0.2, Math.PI - 0.5);
  ctx.stroke();
  ctx.lineWidth = 2.5;

  // explorer hat
  ctx.fillStyle = "#b9803f";
  ctx.beginPath();
  ctx.ellipse(0, -42, 15, 4.5, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  const hg = ctx.createLinearGradient(0, -53, 0, -42);
  hg.addColorStop(0, "#d79a52");
  hg.addColorStop(1, "#a76f33");
  ctx.fillStyle = hg;
  ctx.beginPath();
  ctx.moveTo(-9, -42);
  ctx.quadraticCurveTo(-9, -54, 0, -54);
  ctx.quadraticCurveTo(9, -54, 9, -42);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = "#e63946";
  ctx.fillRect(-8.6, -46, 17.2, 3.4);

  ctx.restore();
}

export type PlatformKind = "normal" | "moving" | "crumble";

export function drawPlatform(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, kind: PlatformKind, crumble = 0) {
  const h = 14;
  const palettes: Record<PlatformKind, [string, string, string]> = {
    normal: ["#8b7bb0", "#5d4a8a", "#6fe08a"],
    moving: ["#6fb4d9", "#3c78a8", "#a8f0ff"],
    crumble: ["#b58b6a", "#85583c", "#d8b48c"],
  };
  const [top, bot, trim] = palettes[kind];
  ctx.save();
  if (crumble > 0) {
    ctx.translate((Math.random() - 0.5) * 2.4, crumble * crumble * 30);
    ctx.globalAlpha = Math.max(0, 1 - crumble * 0.9);
  }
  ctx.lineWidth = 2.5;
  ctx.strokeStyle = OUT;
  ctx.lineJoin = "round";
  const g = ctx.createLinearGradient(0, y, 0, y + h);
  g.addColorStop(0, top);
  g.addColorStop(1, bot);
  ctx.fillStyle = g;
  rr(ctx, x, y, w, h, 6);
  ctx.fill();
  ctx.stroke();
  // grass / trim cap
  ctx.fillStyle = trim;
  rr(ctx, x + 2, y + 1.5, w - 4, 4.5, 2.5);
  ctx.fill();
  if (kind === "crumble") {
    ctx.strokeStyle = OUT;
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(x + w * 0.3, y + 3);
    ctx.lineTo(x + w * 0.38, y + 8);
    ctx.lineTo(x + w * 0.33, y + h - 1);
    ctx.moveTo(x + w * 0.7, y + 3);
    ctx.lineTo(x + w * 0.63, y + 9);
    ctx.stroke();
  }
  if (kind === "moving") {
    ctx.fillStyle = "rgba(255,255,255,0.8)";
    ctx.beginPath();
    ctx.arc(x + 8, y + h / 2 + 2, 1.8, 0, Math.PI * 2);
    ctx.arc(x + w - 8, y + h / 2 + 2, 1.8, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

export function drawCoin(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, spin: number) {
  const sx = Math.max(0.18, Math.abs(Math.cos(spin)));
  ctx.save();
  ctx.translate(x, y);
  // glow
  const glow = ctx.createRadialGradient(0, 0, 2, 0, 0, r * 2);
  glow.addColorStop(0, "rgba(255,220,80,0.45)");
  glow.addColorStop(1, "rgba(255,220,80,0)");
  ctx.fillStyle = glow;
  ctx.beginPath();
  ctx.arc(0, 0, r * 2, 0, Math.PI * 2);
  ctx.fill();
  ctx.scale(sx, 1);
  ctx.lineWidth = 2.2;
  ctx.strokeStyle = "#5a3300";
  const g = ctx.createLinearGradient(0, -r, 0, r);
  g.addColorStop(0, "#fff08a");
  g.addColorStop(1, "#f59e0b");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(0, 0, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.lineWidth = 1.6;
  ctx.strokeStyle = "rgba(160,90,0,0.8)";
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.58, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();
}
