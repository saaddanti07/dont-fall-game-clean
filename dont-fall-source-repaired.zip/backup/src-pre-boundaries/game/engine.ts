// DON'T FALL game engine.
// Core physics / controls / lava / difficulty are the original ones. On top of that: six worlds, extra platform
// types, world hazards, power-ups, weather and run statistics.

import { audio } from "./audio";
import { drawCoin, drawPlatform, drawPlayer, type PlatformKind } from "./sprites";
import type { Skin } from "./skins";
import {
  POWER_COLOR, POWER_NAME, WARN_COLOR, drawCactus, drawHazard, drawPlant, drawPowerup, drawWarning,
  type HazKind, type PowerType,
} from "./hazards";
import { WORLDS, drawWorldBackground, hash, worldAt, worldLabel, worldTitle, type WorldInfo } from "./worlds";
import type { RunStats } from "./progression";

export const WORLD_W = 360;

// --- tuning (original gameplay constants) ----------------------------------------------------------
const GRAVITY = 1400;
const JUMP_V = 720;
const MOVE_SPEED = 230;
const PLAYER_HALF_W = 12;
const SCORE_DIV = 10; // world px per meter

// --- new, clearly defined special physics ----------------------------------------------------------
const SPRING_MULT = 1.32; // spring platforms bounce higher
const SLIP_TIME = 0.55; // ice: steering is sluggish for the first part of the flight
const SLIP_K = 3; // (normal steering uses 10)
const ROCKET_V = 860;
const ROCKET_TIME = 1.25;
const PLAYER_R = 11; // forgiving hit circle, centred 26px above the feet

export const POWER_DURATION: Record<PowerType, number> = { shield: 25, magnet: 9, double: 12, rocket: ROCKET_TIME, slow: 8 };

const FRAGILE_DUR: Partial<Record<PlatformKind, number>> = { crumble: 0.5, sand: 0.9, temp: 1.5 };
const isFragile = (k: PlatformKind) => k === "crumble" || k === "sand" || k === "temp";

export interface HudPower {
  type: PowerType;
  frac: number;
}
export interface HudState {
  score: number;
  distance: number;
  bonus: number;
  coins: number;
  powers: HudPower[];
}
export interface WorldEvent {
  seg: number;
  index: number;
  loop: number;
  name: string;
  label: string;
  subtitle: string;
  accent: string;
}
export interface GameCallbacks {
  onHud: (h: HudState) => void;
  onCoin: (amount: number) => void;
  onWorld: (w: WorldEvent) => void;
  onGameOver: (r: RunStats) => void;
}
export interface GameOptions {
  startMeters?: number;
  god?: boolean;
  bot?: boolean;
}

interface PlatHaz {
  type: "plant" | "cactus";
  side: number;
  phase: number;
  warned: boolean;
}
interface Platform {
  x: number;
  y: number;
  w: number;
  kind: PlatformKind;
  theme: number;
  dir: number;
  speed: number;
  crumbling: boolean;
  crumbleT: number;
  dead: boolean;
  haz?: PlatHaz;
}
interface Coin {
  x: number;
  y: number;
  taken: boolean;
  phase: number;
}
interface PowerItem {
  x: number;
  y: number;
  type: PowerType;
  taken: boolean;
  phase: number;
}
interface Hazard {
  kind: HazKind;
  x: number;
  y: number; // lower-centre point
  vx: number;
  vy: number;
  g: number;
  r: number;
  c0: number; // collision segment from y-c0 ...
  c1: number; // ... to y-c1
  warn: number; // seconds of warning left (hazard not active yet)
  dir: number;
  dead: boolean;
  near: boolean;
  awarded: boolean;
}
interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  color: string;
  size: number;
}
interface FloatText {
  x: number;
  y: number;
  text: string;
  color: string;
  life: number;
}
interface Amb {
  x: number;
  y: number;
  s: number;
  ph: number;
  rot: number;
}

const FALL_SPEC: Record<string, { r: number; c0: number; c1: number }> = {
  icicle: { r: 7, c0: 3, c1: 30 },
  rock: { r: 9, c0: 2, c1: 22 },
  firerock: { r: 11, c0: 11, c1: 11 },
  fruit: { r: 10, c0: 10, c1: 10 },
  star: { r: 10, c0: 11, c1: 11 },
  fireball: { r: 11, c0: 11, c1: 11 },
  bird: { r: 11, c0: 12, c1: 12 },
};

// which falling hazard each world drops (cave only in endless levels)
const FALL_KIND: (HazKind | null)[] = ["rock", "icicle", "firerock", "fruit", null, "star"];

// platform kind tables per world: [kind, base chance, extra chance at full difficulty]
const KIND_TABLE: Record<number, [PlatformKind, number, number][]> = {
  1: [["ice", 0.22, 0.18], ["moving", 0.08, 0.12], ["crumble", 0.06, 0.1], ["spring", 0.06, 0]],
  2: [["temp", 0.18, 0.12], ["moving", 0.08, 0.1], ["crumble", 0.08, 0.08], ["spring", 0.05, 0]],
  3: [["wooden", 0.28, 0.12], ["crumble", 0.07, 0.07], ["spring", 0.07, 0]],
  4: [["sand", 0.26, 0.14], ["moving", 0.08, 0.1], ["spring", 0.05, 0]],
  5: [["moving", 0.28, 0.12], ["temp", 0.1, 0.1], ["spring", 0.07, 0]],
};

const AMB_MAX = 96;

function segDist(px: number, py: number, x: number, y0: number, y1: number): number {
  // distance from point to vertical segment (x, y0..y1) with y0 <= y1
  const cy = Math.max(y0, Math.min(y1, py));
  return Math.hypot(px - x, py - cy);
}

function plantStage(t: number, phase: number): { stage: 0 | 1 | 2; u: number } {
  const c = (t + phase) % 3;
  if (c < 1.9) return { stage: 0, u: c / 1.9 };
  if (c < 2.6) return { stage: 1, u: (c - 1.9) / 0.7 };
  return { stage: 2, u: (c - 2.6) / 0.4 };
}

export class Game {
  private ctx: CanvasRenderingContext2D;
  private raf = 0;
  private last = 0;
  private time = 0;
  private scale = 1;
  private viewH = 640;

  private platforms: Platform[] = [];
  private coins: Coin[] = [];
  private powerItems: PowerItem[] = [];
  private hazards: Hazard[] = [];
  private particles: Particle[] = [];
  private texts: FloatText[] = [];
  private amb: Amb[] = [];
  private genY = 0;
  private lastWasFragile = false;
  private lastWasIce = false;
  private lastCenter = WORLD_W / 2;
  private hazCooldown = 0;
  private puCooldown = 0;

  private px = WORLD_W / 2;
  private py = 0;
  private vx = 0;
  private vy = 0;
  private facing = 1;
  private stretch = 1;
  private camY = 0;
  private lavaY = 260;
  private startY = 0;
  private startMax = 0;
  private maxHeight = 0;
  private dist = 0;
  private bonus = 0;
  private runCoins = 0;
  private dir = 0;
  private paused = false;
  private state: "playing" | "dying" | "over" = "playing";
  private deathBy: "lava" | "hazard" = "lava";
  private dyingT = 0;

  // run stats
  private playTime = 0;
  private platformsLanded = 0;
  private powerupsTaken = 0;
  private nearMisses = 0;

  // worlds
  private curSeg = 0;
  private curIdx = 0;
  private curLoop = 0;
  private prevIdx = 0;
  private transT = 1;
  private maxSeg = 0;

  // power-up timers
  private shieldT = 0;
  private magnetT = 0;
  private doubleT = 0;
  private slowT = 0;
  private rocketT = 0;
  private invulnT = 0;
  private slipT = 0;

  // hazards / weather timers
  private fallT = 3.5;
  private birdT = 5;
  private eruptT = 6;
  private stormTimer = 8;
  private stormOn = false;
  private storm = 0;
  private windState = 0; // 0 idle, 1 warning, 2 gust
  private windTimer = 8;
  private windDir = 1;
  private wind = 0;
  private windTarget = 0;

  private hudT = 0;
  private god: boolean;
  private bot: boolean;

  constructor(private canvas: HTMLCanvasElement, private skin: Skin, private cb: GameCallbacks, opts: GameOptions = {}) {
    this.ctx = canvas.getContext("2d")!;
    this.god = !!opts.god;
    this.bot = !!opts.bot;
    for (let i = 0; i < AMB_MAX; i++) this.amb.push({ x: Math.random() * WORLD_W, y: Math.random() * 640, s: Math.random(), ph: Math.random() * 6.28, rot: Math.random() * 6.28 });
    this.reset(opts.startMeters ?? 0);
  }

  // --- public API ------------------------------------------------------------------------------------
  start() {
    this.last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(0.033, (now - this.last) / 1000);
      this.last = now;
      if (!this.paused && this.state !== "over") this.update(dt);
      this.time += this.paused ? 0 : dt;
      this.render();
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  }

  destroy() {
    cancelAnimationFrame(this.raf);
  }

  setPaused(p: boolean) {
    this.paused = p;
  }

  setInput(dir: number) {
    this.dir = dir;
  }

  getRunStats(): RunStats {
    return {
      distance: this.dist,
      score: this.dist + this.bonus,
      bonus: this.bonus,
      coins: this.runCoins,
      platforms: this.platformsLanded,
      time: this.playTime,
      powerups: this.powerupsTaken,
      nearMisses: this.nearMisses,
      worldSeg: this.maxSeg,
    };
  }

  resize(cssW: number, cssH: number, dpr: number) {
    this.canvas.width = Math.round(cssW * dpr);
    this.canvas.height = Math.round(cssH * dpr);
    this.scale = cssW / WORLD_W;
    this.viewH = cssH / this.scale;
    this.ctx.setTransform(this.scale * dpr, 0, 0, this.scale * dpr, 0, 0);
    // keep camera consistent with start layout if the run hasn't begun
    if (this.maxHeight === this.startMax && this.state === "playing") this.camY = this.startY - this.viewH * 0.72;
  }

  reset(startMeters = 0) {
    this.platforms = [];
    this.coins = [];
    this.powerItems = [];
    this.hazards = [];
    this.particles = [];
    this.texts = [];
    this.startY = -startMeters * SCORE_DIV;
    this.startMax = startMeters * SCORE_DIV;
    this.px = WORLD_W / 2;
    this.py = this.startY;
    this.vx = 0;
    this.vy = -JUMP_V;
    this.facing = 1;
    this.stretch = 1;
    this.camY = this.startY - this.viewH * 0.72;
    this.lavaY = this.startY + 260;
    this.maxHeight = this.startMax;
    this.dist = Math.floor(startMeters);
    this.bonus = 0;
    this.runCoins = 0;
    this.state = "playing";
    this.dyingT = 0;
    this.lastWasFragile = false;
    this.lastWasIce = false;
    this.lastCenter = WORLD_W / 2;
    this.hazCooldown = 2;
    this.puCooldown = 3;
    const info = worldAt(this.dist);
    this.curSeg = this.maxSeg = info.seg;
    this.curIdx = this.prevIdx = info.index;
    this.curLoop = info.loop;
    this.transT = 1;
    audio.setWorld(info.index);
    if (startMeters > 0) this.announce(info);
    // wide starting ground
    this.platforms.push({ x: 40, y: this.startY, w: WORLD_W - 80, kind: "normal", theme: info.index, dir: 0, speed: 0, crumbling: false, crumbleT: 0, dead: false });
    this.genY = this.startY;
    this.generate();
  }

  // --- debug / test hooks (only reachable via ?debug) ---------------------------------------------------
  debugState() {
    const kinds: Record<string, number> = {};
    for (const p of this.platforms) kinds[p.kind] = (kinds[p.kind] ?? 0) + 1;
    return {
      dist: this.dist, world: this.curIdx, loop: this.curLoop, state: this.state, coins: this.runCoins, bonus: this.bonus,
      shield: this.shieldT, magnet: this.magnetT, double: this.doubleT, slow: this.slowT, rocket: this.rocketT,
      hazards: this.hazards.filter((h) => !h.dead).length, kinds, py: this.py, lavaY: this.lavaY, storm: this.storm, wind: this.wind,
      platforms: this.platformsLanded, nearMisses: this.nearMisses,
    };
  }
  debugGive(type: PowerType) {
    this.applyPower(type, this.px, this.py - 40);
  }
  debugSpawn(kind: HazKind) {
    if (kind === "bird") this.spawnBird();
    else if (kind === "fireball") this.spawnEruption();
    else this.spawnFalling(kind);
  }
  setBot(b: boolean) {
    this.bot = b;
  }
  setGod(g: boolean) {
    this.god = g;
  }

  // --- difficulty (original formulas) -------------------------------------------------------------------
  private difficulty(score: number) {
    return Math.min(1, score / 2000);
  }

  private lavaSpeed() {
    const d = this.difficulty(this.dist);
    const grace = Math.min(1, this.time / 2.5); // gentle start
    const endless = Math.min(14, this.curLoop * 5); // slightly faster in endless levels
    return (24 + 78 * d + endless) * grace;
  }

  // --- platform generation -----------------------------------------------------------------------------------
  private pickKind(widx: number, score: number, d: number, loop: number): PlatformKind {
    const r = Math.random();
    let kind: PlatformKind = "normal";
    if (widx === 0) {
      // original cave rules
      if (score > 120 && r < 0.1 + 0.3 * d) kind = "moving";
      else if (score > 250 && !this.lastWasFragile && r > 0.9 - 0.2 * d) kind = "crumble";
      else if (score > 100 && r >= 0.5 && r < 0.54) kind = "spring";
    } else {
      const k = 1 + 0.25 * loop;
      let acc = 0;
      for (const [kd, base, extra] of KIND_TABLE[widx]) {
        acc += (base + extra * d) * k;
        if (r < acc) {
          kind = kd;
          break;
        }
      }
    }
    if (isFragile(kind) && this.lastWasFragile) kind = "normal";
    return kind;
  }

  private generate() {
    while (this.genY > this.camY - 320) {
      const score = -this.genY / SCORE_DIV;
      const d = this.difficulty(score);
      const gap = Math.min(138, 62 + 70 * d + Math.random() * 22);
      const y = this.genY - gap;
      const info = worldAt(-y / SCORE_DIV);
      let w = (84 - 32 * d) * (0.92 + Math.random() * 0.22) * (1 - Math.min(0.1, info.loop * 0.03));

      const kind = this.pickKind(info.index, score, d, info.loop);
      if (kind === "ice") w *= 1.1;
      this.lastWasFragile = isFragile(kind);

      // hazard mounted on the platform (plants in the forest, cacti in the desert) — never next to another one
      let haz: PlatHaz | undefined;
      this.hazCooldown--;
      const worldM = (-y / SCORE_DIV) % 500;
      if (kind === "normal" && (info.index === 3 || info.index === 4) && this.hazCooldown <= 0 && worldM > 40 && Math.random() < 0.26 + 0.2 * d + 0.04 * info.loop) {
        haz = { type: info.index === 3 ? "plant" : "cactus", side: Math.random() < 0.5 ? -1 : 1, phase: Math.random() * 3, warned: false };
        w = Math.max(w, 80);
        this.hazCooldown = 3;
      }

      // reachability: bounded horizontal step (tighter after slippery ice)
      const maxDx = this.lastWasIce ? 70 : 128;
      const off = Math.max(-maxDx, Math.min(maxDx, (Math.random() - 0.5) * 340));
      let x = this.lastCenter + off - w / 2;
      x = Math.max(4, Math.min(WORLD_W - w - 4, x));
      this.lastWasIce = kind === "ice";

      const p: Platform = {
        x, y, w, kind, theme: info.index,
        dir: Math.random() < 0.5 ? -1 : 1,
        speed: kind === "wooden" ? 32 + Math.random() * 30 : 40 + Math.random() * 50,
        crumbling: false, crumbleT: 0, dead: false, haz,
      };
      this.platforms.push(p);
      this.lastCenter = x + w / 2;
      this.genY = y;

      // power-up or coin above the platform
      this.puCooldown--;
      if (!haz && this.puCooldown <= 0 && score > 40 && Math.random() < 0.2) {
        this.powerItems.push({ x: x + w / 2, y: y - 50, type: this.pickPower(score), taken: false, phase: Math.random() * 6 });
        this.puCooldown = 7;
      } else if (Math.random() < 0.38) {
        this.coins.push({ x: x + w / 2, y: y - 42, taken: false, phase: Math.random() * 6 });
      }
    }
    // cull anything well below the screen
    const bottom = this.camY + this.viewH + 150;
    this.platforms = this.platforms.filter((p) => p.y < bottom && !p.dead);
    this.coins = this.coins.filter((c) => c.y < bottom && !c.taken);
    this.powerItems = this.powerItems.filter((c) => c.y < bottom && !c.taken);
  }

  private pickPower(score: number): PowerType {
    const table: [PowerType, number][] = [["shield", 22], ["magnet", 20], ["double", 20], ["slow", 22], ["rocket", score > 120 ? 8 : 0]];
    const total = table.reduce((s, [, w]) => s + w, 0);
    let r = Math.random() * total;
    for (const [t, w] of table) {
      r -= w;
      if (r <= 0) return t;
    }
    return "shield";
  }

  private burst(x: number, y: number, n: number, colors: string[], power: number) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = (0.3 + Math.random()) * power;
      this.particles.push({
        x, y,
        vx: Math.cos(a) * s,
        vy: Math.sin(a) * s - power * 0.3,
        life: 0,
        max: 0.4 + Math.random() * 0.5,
        color: colors[Math.floor(Math.random() * colors.length)],
        size: 2 + Math.random() * 3,
      });
    }
  }

  private text(x: number, y: number, text: string, color: string) {
    this.texts.push({ x, y, text, color, life: 0 });
  }

  // --- worlds ----------------------------------------------------------------------------------------------------
  private announce(info: WorldInfo) {
    const w = WORLDS[info.index];
    this.cb.onWorld({
      seg: info.seg, index: info.index, loop: info.loop,
      name: worldTitle(info.index, info.loop), label: worldLabel(info.seg, info.loop),
      subtitle: w.subtitle, accent: w.accent,
    });
  }

  private enterWorld(info: WorldInfo) {
    this.prevIdx = this.curIdx;
    this.curIdx = info.index;
    this.curLoop = info.loop;
    this.curSeg = info.seg;
    this.maxSeg = Math.max(this.maxSeg, info.seg);
    this.transT = 0;
    // grace period: no hazards right after entering a new world
    this.fallT = Math.max(this.fallT, 3.5);
    this.birdT = Math.max(this.birdT, 5);
    this.eruptT = Math.max(this.eruptT, 6);
    this.windState = 0;
    this.windTimer = 7;
    this.stormOn = false;
    this.stormTimer = 9;
    audio.setWorld(info.index);
    audio.sfx("world");
    this.announce(info);
  }

  // --- hazards ---------------------------------------------------------------------------------------------------
  private spawnFalling(kind: HazKind) {
    const spec = FALL_SPEC[kind];
    let x = Math.max(26, Math.min(WORLD_W - 26, this.px + (Math.random() - 0.5) * 220));
    for (const o of this.hazards) if (!o.dead && Math.abs(o.x - x) < 60 && o.vy !== undefined && o.kind !== "bird" && o.kind !== "fireball") x = Math.max(26, Math.min(WORLD_W - 26, x + 80));
    const d = this.difficulty(this.dist);
    this.hazards.push({
      kind, x, y: -1e9, vx: 0, vy: 190 + 80 * d, g: 380, r: spec.r, c0: spec.c0, c1: spec.c1,
      warn: 1.0, dir: 1, dead: false, near: false, awarded: false,
    });
    audio.sfx("warn");
  }

  private spawnBird() {
    const dir = Math.random() < 0.5 ? 1 : -1;
    const y = Math.max(this.camY + 150, Math.min(this.camY + this.viewH - 150, this.py - 70 - Math.random() * 80));
    const d = this.difficulty(this.dist);
    this.hazards.push({
      kind: "bird", x: dir > 0 ? -34 : WORLD_W + 34, y, vx: dir * (165 + 60 * d), vy: 0, g: 0, r: 11, c0: 12, c1: 12,
      warn: 1.15, dir, dead: false, near: false, awarded: false,
    });
    audio.sfx("warn");
  }

  private spawnEruption() {
    const x = Math.max(30, Math.min(WORLD_W - 30, this.px + (Math.random() - 0.5) * 180));
    this.hazards.push({
      kind: "fireball", x, y: this.lavaY, vx: (Math.random() - 0.5) * 40, vy: -(520 + Math.random() * 140), g: 520, r: 11, c0: 11, c1: 11,
      warn: 1.3, dir: 1, dead: false, near: false, awarded: false,
    });
    audio.sfx("warn");
  }

  private updateSpawns(dt: number) {
    if (this.state !== "playing" || this.rocketT > 0) return;
    const d = this.difficulty(this.dist);
    const loop = this.curLoop;
    const idx = this.curIdx;
    const fallKind = FALL_KIND[idx];
    this.fallT -= dt;
    if (this.fallT <= 0) {
      if (fallKind && (idx !== 0 || loop > 0)) this.spawnFalling(fallKind);
      this.fallT = Math.max(2.1, 4.6 - 1.9 * d - 0.4 * loop) + Math.random() * 1.3;
    }
    if (idx === 4) {
      this.birdT -= dt;
      if (this.birdT <= 0) {
        this.spawnBird();
        this.birdT = Math.max(4, 6.5 - 2 * d - 0.3 * loop) + Math.random() * 2;
      }
    }
    if (idx === 2) {
      this.eruptT -= dt;
      if (this.eruptT <= 0) {
        if (this.lavaY - this.camY < this.viewH - 20) this.spawnEruption();
        this.eruptT = Math.max(4.5, 7 - 2 * d - 0.4 * loop) + Math.random() * 2;
      }
    }
  }

  private hurt(h?: Hazard) {
    if (this.god || this.invulnT > 0 || this.rocketT > 0 || this.state !== "playing") return;
    if (this.shieldT > 0) {
      this.shieldT = 0;
      this.invulnT = 1.2;
      audio.sfx("shield");
      this.burst(this.px, this.py - 26, 16, ["#3fb7ff", "#bfe9ff", "#ffffff"], 160);
      this.text(this.px, this.py - 70, "SHIELD!", "#7fd0ff");
      if (h) h.dead = true;
      return;
    }
    this.state = "dying";
    this.deathBy = "hazard";
    this.dyingT = 0;
    this.vy = -320;
    audio.sfx("die");
    this.burst(this.px, this.py - 26, 20, ["#ff5a5a", "#ffd23f", "#ffffff"], 190);
    if (h) h.dead = true;
  }

  private updateHazards(dt: number) {
    const cx = this.px;
    const cy = this.py - 26;
    const camBottom = this.camY + this.viewH;
    for (const h of this.hazards) {
      if (h.dead) continue;
      if (h.warn > 0) {
        h.warn -= dt;
        if (h.kind === "fireball") {
          h.y = this.lavaY;
          h.x = Math.max(8, Math.min(WORLD_W - 8, h.x));
        }
        if (h.warn <= 0 && (h.kind !== "bird" && h.kind !== "fireball")) h.y = this.camY - 40;
        continue;
      }
      h.x += h.vx * dt;
      h.y += h.vy * dt;
      h.vy += h.g * dt;
      if (h.kind === "bird") {
        if (h.x < -60 || h.x > WORLD_W + 60 || h.y > camBottom + 60) h.dead = true;
      } else if (h.kind === "fireball") {
        if (h.vy > 0 && h.y > this.lavaY + 20) h.dead = true;
      } else if (h.y > camBottom + 80) {
        h.dead = true;
      }
      if (h.dead || this.state !== "playing") continue;
      // collision + near-miss
      const dd = segDist(cx, cy, h.x, h.y - h.c1, h.y - h.c0);
      const hit = h.r + PLAYER_R;
      if (dd < hit) {
        this.hurt(h);
      } else if (!h.awarded && this.rocketT <= 0) {
        if (dd < hit + 20) h.near = true;
        else if (h.near && dd > hit + 24) {
          h.awarded = true;
          this.bonus += 10;
          this.nearMisses++;
          audio.sfx("near");
          this.text(this.px, this.py - 72, "NEAR MISS! +10", "#ffe066");
          this.burst(this.px, this.py - 26, 12, ["#ffe066", "#ffffff", "#7fe3ff"], 130);
        }
      }
    }
    this.hazards = this.hazards.filter((h) => !h.dead);

    // platform-mounted hazards (cactus / snapping plant)
    if (this.state !== "playing") return;
    for (const p of this.platforms) {
      const hz = p.haz;
      if (!hz || p.dead) continue;
      if (Math.abs(p.y - cy) > 90) continue;
      const hx = p.x + (hz.side < 0 ? 12 : p.w - 12);
      let active = true;
      let height = 25;
      if (hz.type === "plant") {
        const st = plantStage(this.time, hz.phase);
        if (st.stage === 1 && !hz.warned && Math.abs(hx - cx) < 130) {
          hz.warned = true;
          audio.sfx("warn");
        }
        if (st.stage === 0) hz.warned = false;
        active = st.stage === 2;
        height = 36;
      }
      if (!active) continue;
      // circle vs rect
      const nx = Math.max(hx - 8, Math.min(hx + 8, cx));
      const ny = Math.max(p.y - height, Math.min(p.y, cy));
      if (Math.hypot(cx - nx, cy - ny) < PLAYER_R) this.hurt();
    }
  }

  // --- ambient / weather ---------------------------------------------------------------------------------------------
  private updateWeather(dt: number) {
    const wi = this.curIdx;
    if (wi === 1 || wi === 4) {
      this.stormTimer -= dt;
      if (this.stormTimer <= 0) {
        this.stormOn = !this.stormOn;
        this.stormTimer = this.stormOn ? 6 + Math.random() * 3 : 13 + Math.random() * 10;
      }
    } else this.stormOn = false;
    this.storm += ((this.stormOn ? 1 : 0) - this.storm) * Math.min(1, dt * 1.2);

    if (wi === 5 && this.state === "playing") {
      this.windTimer -= dt;
      if (this.windTimer <= 0) {
        if (this.windState === 0) {
          this.windState = 1;
          this.windTimer = 1.3;
          this.windDir = Math.random() < 0.5 ? -1 : 1;
          audio.sfx("warn");
        } else if (this.windState === 1) {
          this.windState = 2;
          this.windTimer = 3.2;
        } else {
          this.windState = 0;
          this.windTimer = Math.max(5, 9 - 3 * this.difficulty(this.dist)) + Math.random() * 3;
        }
      }
      this.windTarget = this.windState === 2 ? this.windDir * (52 + 14 * this.difficulty(this.dist)) : 0;
    } else {
      this.windState = 0;
      this.windTarget = 0;
    }
    this.wind += (this.windTarget - this.wind) * Math.min(1, dt * 3);
  }

  private updateAmbient(dt: number) {
    const idx = this.curIdx;
    const count = Math.min(AMB_MAX, WORLDS[idx].ambient + Math.round(this.storm * 50));
    const H = this.viewH;
    const t = this.time;
    for (let i = 0; i < count; i++) {
      const a = this.amb[i];
      let vx = 0;
      let vy = 0;
      switch (idx) {
        case 0: vx = Math.sin(t * 0.6 + a.ph) * 6; vy = -4 - a.s * 5; break;
        case 1: vx = Math.sin(t * 1.3 + a.ph) * 16 + this.storm * 120 + this.wind * 0.5; vy = 34 + a.s * 30 + this.storm * 30; break;
        case 2: vx = Math.sin(t * 1.7 + a.ph) * 14; vy = -(26 + a.s * 36); break;
        case 3: vx = Math.sin(t * 1.1 + a.ph) * 28 + 10; vy = 22 + a.s * 16; break;
        case 4: vx = 70 + a.s * 40 + this.storm * 280; vy = Math.sin(t + a.ph) * 6 + 8 + this.storm * 10; break;
        default: vx = -(50 + a.s * 50) - this.wind * 2.5; vy = 10; break;
      }
      a.x += vx * dt;
      a.y += vy * dt;
      a.rot += dt * (1 + a.s * 2);
      if (a.x < -14) a.x = WORLD_W + 14;
      else if (a.x > WORLD_W + 14) a.x = -14;
      if (a.y > H + 14) a.y = -14;
      else if (a.y < -14) a.y = H + 14;
    }
  }

  // --- power-ups -----------------------------------------------------------------------------------------------------------
  private applyPower(type: PowerType, x: number, y: number) {
    this.powerupsTaken++;
    audio.sfx("powerup");
    const col = POWER_COLOR[type];
    this.burst(x, y, 16, [col, "#ffffff", col], 150);
    this.text(x, y - 18, POWER_NAME[type], col);
    switch (type) {
      case "shield": this.shieldT = POWER_DURATION.shield; break;
      case "magnet": this.magnetT = POWER_DURATION.magnet; break;
      case "double": this.doubleT = POWER_DURATION.double; break;
      case "slow": this.slowT = POWER_DURATION.slow; break;
      case "rocket":
        this.rocketT = ROCKET_TIME;
        this.invulnT = Math.max(this.invulnT, ROCKET_TIME + 1.2); // brief grace after the boost ends
        break;
    }
  }

  private botDir(): number {
    let best: Platform | null = null;
    let bc = 1e9;
    for (const p of this.platforms) {
      if (p.dead) continue;
      const dy = p.y - this.py;
      const cxp = p.x + p.w / 2;
      const dx = Math.abs(cxp - this.px);
      if (this.vy < 0 ? dy < -25 && dy > -175 && dx < 150 : dy > -5 && dy < 120) {
        const c = dx + dy * (this.vy < 0 ? 0.5 : 0.3);
        if (c < bc) {
          bc = c;
          best = p;
        }
      }
    }
    if (!best) return 0;
    const diff = best.x + best.w / 2 - this.px;
    return Math.abs(diff) < 6 ? 0 : diff > 0 ? 1 : -1;
  }

  // --- simulation -----------------------------------------------------------------------------------------------------------------
  private update(dt: number) {
    // particles + floating texts
    for (const p of this.particles) {
      p.life += dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vy += 500 * dt;
    }
    this.particles = this.particles.filter((p) => p.life < p.max);
    for (const t of this.texts) {
      t.life += dt;
      t.y -= 26 * dt;
    }
    this.texts = this.texts.filter((t) => t.life < 1.2);

    if (this.transT < 1) this.transT = Math.min(1, this.transT + dt / 2.2);
    if (this.state === "playing") this.playTime += dt;
    this.magnetT = Math.max(0, this.magnetT - dt);
    this.doubleT = Math.max(0, this.doubleT - dt);
    this.slowT = Math.max(0, this.slowT - dt);
    this.shieldT = Math.max(0, this.shieldT - dt);
    this.invulnT = Math.max(0, this.invulnT - dt);
    this.updateWeather(dt);
    this.updateAmbient(dt);

    // lava always rises (slower while SLOW LAVA is active)
    this.lavaY -= this.lavaSpeed() * (this.slowT > 0 ? 0.4 : 1) * dt;
    const camBottom = this.camY + this.viewH;
    this.lavaY = Math.min(this.lavaY, camBottom + 220);

    for (const p of this.platforms) {
      if ((p.kind === "moving" || p.kind === "wooden") && !p.dead) {
        p.x += p.dir * p.speed * dt;
        if (p.x < 2) {
          p.x = 2;
          p.dir = 1;
        } else if (p.x + p.w > WORLD_W - 2) {
          p.x = WORLD_W - 2 - p.w;
          p.dir = -1;
        }
      }
      if (p.crumbling) {
        p.crumbleT += dt;
        if (p.kind === "sand" && Math.random() < 0.5) {
          this.particles.push({ x: p.x + Math.random() * p.w, y: p.y + 10, vx: (Math.random() - 0.5) * 20, vy: 10, life: 0, max: 0.5, color: "#f0c878", size: 2.5 });
        }
        if (p.crumbleT >= (FRAGILE_DUR[p.kind] ?? 0.5)) p.dead = true;
      }
    }

    if (this.state === "dying") {
      this.dyingT += dt;
      if (this.deathBy === "hazard") {
        this.vy += GRAVITY * dt;
        this.py += this.vy * dt;
      }
      this.updateHazards(dt);
      if (this.dyingT > 0.9) {
        this.state = "over";
        this.cb.onGameOver(this.getRunStats());
      }
      return;
    }

    if (this.bot) this.dir = this.botDir();

    // horizontal movement (ice makes steering sluggish for a short time; wind pushes in the sky world)
    const target = this.dir * MOVE_SPEED;
    const k = this.slipT > 0 ? SLIP_K : 10;
    this.slipT = Math.max(0, this.slipT - dt);
    this.vx += (target - this.vx) * Math.min(1, dt * k);
    this.px += (this.vx + this.wind) * dt;
    if (this.px < -PLAYER_HALF_W) this.px = WORLD_W + PLAYER_HALF_W;
    else if (this.px > WORLD_W + PLAYER_HALF_W) this.px = -PLAYER_HALF_W;
    if (this.vx > 15) this.facing = 1;
    else if (this.vx < -15) this.facing = -1;

    // vertical movement + platform collision
    const prevFeet = this.py;
    if (this.rocketT > 0) {
      this.rocketT -= dt;
      this.vy = -ROCKET_V;
      this.py += this.vy * dt;
      this.stretch += (1.15 - this.stretch) * Math.min(1, dt * 8);
      this.particles.push({ x: this.px + (Math.random() - 0.5) * 8, y: this.py + 2, vx: (Math.random() - 0.5) * 60, vy: 120 + Math.random() * 120, life: 0, max: 0.35, color: Math.random() < 0.5 ? "#ffb347" : "#ffe066", size: 3 + Math.random() * 3 });
      if (this.rocketT <= 0) {
        this.vy = -JUMP_V * 0.6;
        this.fallT = Math.max(this.fallT, 2.5);
      }
    } else {
      this.vy += GRAVITY * dt;
      this.py += this.vy * dt;
      this.stretch += (1 - this.stretch) * Math.min(1, dt * 9);

      if (this.vy > 0) {
        for (const p of this.platforms) {
          if (p.dead) continue;
          if (prevFeet <= p.y + 1 && this.py >= p.y && this.px > p.x - 8 && this.px < p.x + p.w + 8) {
            this.py = p.y;
            this.vy = -JUMP_V * (p.kind === "spring" ? SPRING_MULT : 1);
            this.stretch = p.kind === "spring" ? 0.7 : 0.78;
            this.platformsLanded++;
            audio.sfx(p.kind === "spring" ? "spring" : "jump");
            audio.sfx("land");
            this.burst(this.px, p.y, 6, p.kind === "ice" ? ["#ffffff", "#9fe6ff"] : ["#e9d8ff", "#b9a0ee"], 70);
            if (p.kind === "ice") this.slipT = SLIP_TIME;
            if (isFragile(p.kind) && !p.crumbling) {
              p.crumbling = true;
              if (p.kind !== "temp") audio.sfx("crumble");
            }
            break;
          }
        }
      }
      if (this.vy < -300) this.stretch += (1.12 - this.stretch) * Math.min(1, dt * 6);
    }

    // coins (magnet pulls nearby coins in; double coins doubles the value)
    for (const c of this.coins) {
      if (c.taken) continue;
      let dx = c.x - this.px;
      let dy = c.y - (this.py - 22);
      if (this.magnetT > 0) {
        const d = Math.hypot(dx, dy);
        if (d < 150 && d > 1) {
          const sp = 420 * dt;
          c.x -= (dx / d) * Math.min(sp, d);
          c.y -= (dy / d) * Math.min(sp, d);
          dx = c.x - this.px;
          dy = c.y - (this.py - 22);
        }
      }
      if (dx * dx + dy * dy < 30 * 30) {
        c.taken = true;
        const amount = this.doubleT > 0 ? 2 : 1;
        this.runCoins += amount;
        audio.sfx("coin");
        this.burst(c.x, c.y, 8, ["#ffe066", "#fff6b0", "#f59e0b"], 90);
        if (amount > 1) this.text(c.x, c.y - 10, "+2", "#ffe066");
        this.cb.onCoin(amount);
        this.emitHud();
      }
    }

    // power-ups
    for (const it of this.powerItems) {
      if (it.taken) continue;
      const dx = it.x - this.px;
      const dy = it.y - (this.py - 24);
      if (dx * dx + dy * dy < 32 * 32) {
        it.taken = true;
        this.applyPower(it.type, it.x, it.y);
      }
    }

    // distance (meters) — score also includes near-miss bonus
    if (-this.py > this.maxHeight) {
      this.maxHeight = -this.py;
      this.dist = Math.floor(this.maxHeight / SCORE_DIV);
    }
    const info = worldAt(this.dist);
    if (info.seg !== this.curSeg) this.enterWorld(info);

    // camera follows upward progress only
    const camTarget = this.py - this.viewH * 0.42;
    if (camTarget < this.camY) this.camY += (camTarget - this.camY) * Math.min(1, dt * 9);

    this.generate();
    this.updateSpawns(dt);
    this.updateHazards(dt);

    // death: lava or falling off the bottom
    if (this.state === "playing" && (this.py > this.lavaY + 2 || this.py > this.camY + this.viewH + 80)) {
      if (this.god) {
        // test mode only: bounce back up instead of dying
        this.py = Math.min(this.py, this.camY + this.viewH - 60);
        this.lavaY = this.py + 400;
        this.vy = -JUMP_V * 1.3;
      } else {
        this.state = "dying";
        this.deathBy = "lava";
        this.dyingT = 0;
        audio.sfx("die");
        this.burst(this.px, Math.min(this.py, this.lavaY), 22, ["#ff7a18", "#ffd23f", "#ff3d00"], 200);
      }
    }

    this.hudT += dt;
    if (this.hudT > 0.1) this.emitHud();
  }

  private emitHud() {
    this.hudT = 0;
    const powers: HudPower[] = [];
    if (this.rocketT > 0) powers.push({ type: "rocket", frac: this.rocketT / ROCKET_TIME });
    if (this.shieldT > 0) powers.push({ type: "shield", frac: this.shieldT / POWER_DURATION.shield });
    if (this.magnetT > 0) powers.push({ type: "magnet", frac: this.magnetT / POWER_DURATION.magnet });
    if (this.doubleT > 0) powers.push({ type: "double", frac: this.doubleT / POWER_DURATION.double });
    if (this.slowT > 0) powers.push({ type: "slow", frac: this.slowT / POWER_DURATION.slow });
    this.cb.onHud({ score: this.dist + this.bonus, distance: this.dist, bonus: this.bonus, coins: this.runCoins, powers });
  }

  // --- rendering ---------------------------------------------------------------------------------------------------------------------
  private render() {
    const ctx = this.ctx;
    const W = WORLD_W;
    const H = this.viewH;
    const cam = this.camY;
    const t = this.time;

    // background (cross-fades between worlds)
    if (this.transT < 1 && this.prevIdx !== this.curIdx) {
      drawWorldBackground(ctx, this.prevIdx, W, H, cam, t);
      ctx.globalAlpha = this.transT;
      drawWorldBackground(ctx, this.curIdx, W, H, cam, t);
      ctx.globalAlpha = 1;
    } else {
      drawWorldBackground(ctx, this.curIdx, W, H, cam, t);
    }

    this.drawAmbient(ctx, H);

    // coins
    for (const c of this.coins) {
      if (c.taken) continue;
      const sy = c.y - cam;
      if (sy < -30 || sy > H + 30) continue;
      drawCoin(ctx, c.x, sy + Math.sin(t * 3 + c.phase) * 3, 10, t * 4 + c.phase);
    }
    // power-ups
    for (const it of this.powerItems) {
      if (it.taken) continue;
      const sy = it.y - cam;
      if (sy < -40 || sy > H + 40) continue;
      drawPowerup(ctx, it.type, it.x, sy + Math.sin(t * 3 + it.phase) * 4, t);
    }

    // platforms (+ mounted hazards)
    for (const p of this.platforms) {
      const sy = p.y - cam;
      if (sy < -50 || sy > H + 30) continue;
      const dur = FRAGILE_DUR[p.kind] ?? 0.5;
      drawPlatform(ctx, p.x, sy, p.w, p.kind, p.crumbling ? Math.min(1, p.crumbleT / dur) : 0, p.theme, t);
      const hz = p.haz;
      if (hz && !p.dead) {
        const hx = p.x + (hz.side < 0 ? 12 : p.w - 12);
        if (hz.type === "cactus") drawCactus(ctx, hx, sy + 2);
        else {
          const st = plantStage(t, hz.phase);
          drawPlant(ctx, hx, sy + 2, st.stage, st.u, t);
        }
      }
    }

    // active falling / flying hazards
    for (const h of this.hazards) {
      if (h.warn > 0 || h.dead) continue;
      const sy = h.y - cam;
      if (sy < -90 || sy > H + 50) continue;
      drawHazard(ctx, h.kind, h.x, sy, t, h.dir);
    }

    // player (hidden once swallowed by lava)
    const feetScreen = this.py - cam;
    const lavaScreen = this.lavaY - cam;
    if (!(this.state !== "playing" && this.deathBy === "lava" && this.py > this.lavaY)) {
      const phase = t * 4;
      if (this.rocketT > 0) this.drawFlame(ctx, this.px, feetScreen);
      const blink = this.invulnT > 0 && this.rocketT <= 0 && Math.floor(t * 14) % 2 === 0;
      if (blink) ctx.globalAlpha = 0.45;
      drawPlayer(ctx, this.px, feetScreen, this.facing, this.stretch, phase, this.skin);
      // wrap-around ghost
      if (this.px < PLAYER_HALF_W + 10) drawPlayer(ctx, this.px + W + PLAYER_HALF_W * 2, feetScreen, this.facing, this.stretch, phase, this.skin);
      if (this.px > W - PLAYER_HALF_W - 10) drawPlayer(ctx, this.px - W - PLAYER_HALF_W * 2, feetScreen, this.facing, this.stretch, phase, this.skin);
      ctx.globalAlpha = 1;
      if (this.shieldT > 0) this.drawShield(ctx, this.px, feetScreen - 28, t);
    }

    // particles
    for (const p of this.particles) {
      ctx.globalAlpha = Math.max(0, 1 - p.life / p.max);
      ctx.fillStyle = p.color;
      ctx.fillRect(p.x - p.size / 2, p.y - cam - p.size / 2, p.size, p.size);
    }
    ctx.globalAlpha = 1;

    this.drawLava(ctx, W, H, lavaScreen);

    // weather tint
    if (this.storm > 0.02) {
      ctx.fillStyle = this.curIdx === 1 ? `rgba(235,245,255,${this.storm * 0.2})` : `rgba(240,185,100,${this.storm * 0.24})`;
      ctx.fillRect(0, 0, W, H);
    }

    // danger glow when lava is close
    const dist = lavaScreen - feetScreen;
    if (this.state === "playing" && dist < 170) {
      const a = (1 - Math.max(0, dist) / 170) * (0.28 + 0.1 * Math.sin(t * 9));
      const g = ctx.createLinearGradient(0, H, 0, H - 260);
      g.addColorStop(0, `rgba(255,60,20,${a})`);
      g.addColorStop(1, "rgba(255,60,20,0)");
      ctx.fillStyle = g;
      ctx.fillRect(0, H - 260, W, 260);
    }

    this.drawWarnings(ctx, W, H, cam, lavaScreen, t);

    // floating texts
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.lineJoin = "round";
    for (const f of this.texts) {
      ctx.globalAlpha = Math.max(0, Math.min(1, (1.2 - f.life) * 2));
      ctx.font = "700 15px 'Fredoka Variable', 'Trebuchet MS', sans-serif";
      ctx.lineWidth = 4;
      ctx.strokeStyle = "#1b0a3d";
      const x = Math.max(50, Math.min(W - 50, f.x));
      ctx.strokeText(f.text, x, f.y - cam);
      ctx.fillStyle = f.color;
      ctx.fillText(f.text, x, f.y - cam);
    }
    ctx.globalAlpha = 1;
  }

  private drawFlame(ctx: CanvasRenderingContext2D, x: number, y: number) {
    const fl = 26 + Math.random() * 14;
    ctx.fillStyle = "#ff7a18";
    ctx.beginPath();
    ctx.moveTo(x - 8, y - 4);
    ctx.quadraticCurveTo(x - 5, y + fl * 0.6, x, y + fl);
    ctx.quadraticCurveTo(x + 5, y + fl * 0.6, x + 8, y - 4);
    ctx.fill();
    ctx.fillStyle = "#ffe066";
    ctx.beginPath();
    ctx.moveTo(x - 4, y - 4);
    ctx.quadraticCurveTo(x - 2, y + fl * 0.4, x, y + fl * 0.65);
    ctx.quadraticCurveTo(x + 2, y + fl * 0.4, x + 4, y - 4);
    ctx.fill();
  }

  private drawShield(ctx: CanvasRenderingContext2D, x: number, y: number, t: number) {
    const lowFlash = this.shieldT < 4 && Math.floor(t * 8) % 2 === 0;
    ctx.save();
    ctx.globalAlpha = lowFlash ? 0.35 : 1;
    const g = ctx.createRadialGradient(x, y, 12, x, y, 36);
    g.addColorStop(0, "rgba(120,210,255,0.05)");
    g.addColorStop(1, "rgba(120,210,255,0.42)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(x, y, 36 + Math.sin(t * 6) * 1.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.lineWidth = 2.5;
    ctx.strokeStyle = "rgba(200,240,255,0.95)";
    ctx.stroke();
    ctx.restore();
  }

  private drawAmbient(ctx: CanvasRenderingContext2D, H: number) {
    const idx = this.curIdx;
    const count = Math.min(AMB_MAX, WORLDS[idx].ambient + Math.round(this.storm * 50));
    const fade = Math.min(1, this.transT * 1.5);
    const t = this.time;
    ctx.save();
    for (let i = 0; i < count; i++) {
      const a = this.amb[i];
      if (a.y > H + 14) continue;
      switch (idx) {
        case 0:
          ctx.fillStyle = `rgba(200,160,255,${0.3 * fade})`;
          ctx.beginPath();
          ctx.arc(a.x, a.y, 1 + a.s * 1.4, 0, Math.PI * 2);
          ctx.fill();
          break;
        case 1:
          ctx.fillStyle = `rgba(255,255,255,${0.85 * fade})`;
          ctx.beginPath();
          ctx.arc(a.x, a.y, 1.2 + a.s * 1.8, 0, Math.PI * 2);
          ctx.fill();
          break;
        case 2:
          ctx.fillStyle = `rgba(255,${130 + Math.floor(a.s * 90)},40,${(0.5 + 0.4 * Math.sin(t * 6 + a.ph)) * fade})`;
          ctx.fillRect(a.x, a.y, 2 + a.s * 2, 2 + a.s * 2);
          break;
        case 3:
          ctx.save();
          ctx.translate(a.x, a.y);
          ctx.rotate(a.rot);
          ctx.fillStyle = a.s > 0.6 ? `rgba(200,220,80,${0.85 * fade})` : `rgba(90,200,90,${0.85 * fade})`;
          ctx.beginPath();
          ctx.ellipse(0, 0, 4.5, 2.2, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
          break;
        case 4: {
          const len = 6 + this.storm * 18;
          ctx.strokeStyle = `rgba(255,228,170,${0.55 * fade})`;
          ctx.lineWidth = 1.4;
          ctx.beginPath();
          ctx.moveTo(a.x, a.y);
          ctx.lineTo(a.x - len, a.y - 1);
          ctx.stroke();
          break;
        }
        default: {
          const len = 16 + a.s * 22 + Math.abs(this.wind) * 0.5;
          ctx.strokeStyle = `rgba(255,255,255,${0.38 * fade})`;
          ctx.lineWidth = 1.6;
          ctx.beginPath();
          ctx.moveTo(a.x, a.y);
          ctx.lineTo(a.x + len, a.y);
          ctx.stroke();
        }
      }
    }
    ctx.restore();
  }

  private drawWarnings(ctx: CanvasRenderingContext2D, W: number, H: number, cam: number, lavaScreen: number, t: number) {
    for (const h of this.hazards) {
      if (h.warn <= 0 || h.dead) continue;
      const col = WARN_COLOR[h.kind];
      if (h.kind === "bird") {
        const y = Math.max(120, Math.min(H - 110, h.y - cam));
        const x = h.dir > 0 ? 22 : W - 22;
        drawWarning(ctx, x, y, col, t);
        // arrow showing the direction of travel
        ctx.fillStyle = col;
        ctx.strokeStyle = "#1b0a3d";
        ctx.lineWidth = 2;
        ctx.beginPath();
        const ax = x + h.dir * 24;
        ctx.moveTo(ax + h.dir * 8, y);
        ctx.lineTo(ax - h.dir * 2, y - 8);
        ctx.lineTo(ax - h.dir * 2, y + 8);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      } else if (h.kind === "fireball") {
        const y = lavaScreen - 34;
        if (y > 100 && y < H) {
          ctx.fillStyle = `rgba(255,200,80,${0.5 + 0.3 * Math.sin(t * 16)})`;
          ctx.beginPath();
          ctx.ellipse(h.x, lavaScreen - 2, 22, 7, 0, 0, Math.PI * 2);
          ctx.fill();
          drawWarning(ctx, h.x, y, col, t);
        }
      } else {
        drawWarning(ctx, h.x, 132, col, t, Math.min(260, H - 160));
      }
    }
    // wind gust warning (sky world)
    if (this.windState === 1 || (this.windState === 2 && this.windTimer > 0 && Math.abs(this.wind) > 8)) {
      const warn = this.windState === 1;
      ctx.save();
      ctx.globalAlpha = warn ? 0.55 + 0.4 * Math.sin(t * 14) : 0.5;
      ctx.lineWidth = 4;
      ctx.strokeStyle = "#ffffff";
      ctx.lineCap = "round";
      ctx.lineJoin = "round";
      const y = 150;
      const d = this.windDir;
      const shift = ((t * 70) % 30) * d;
      for (let i = 0; i < 3; i++) {
        const x = W / 2 + (i - 1) * 30 + shift;
        ctx.beginPath();
        ctx.moveTo(x - d * 8, y - 12);
        ctx.lineTo(x + d * 6, y);
        ctx.lineTo(x - d * 8, y + 12);
        ctx.stroke();
      }
      ctx.restore();
    }
  }

  private drawLava(ctx: CanvasRenderingContext2D, W: number, H: number, ly: number) {
    if (ly > H + 20) return;
    const t = this.time;
    // glow above surface
    const glow = ctx.createLinearGradient(0, ly - 110, 0, ly);
    glow.addColorStop(0, "rgba(255,90,20,0)");
    glow.addColorStop(1, "rgba(255,110,30,0.4)");
    ctx.fillStyle = glow;
    ctx.fillRect(0, ly - 110, W, 110);

    const wave = (x: number) => Math.sin(x * 0.045 + t * 2.2) * 5 + Math.sin(x * 0.11 - t * 3.1) * 2.5;
    const body = ctx.createLinearGradient(0, ly, 0, ly + 140);
    body.addColorStop(0, "#ffc233");
    body.addColorStop(0.12, "#ff7a18");
    body.addColorStop(0.55, "#e0310f");
    body.addColorStop(1, "#8c0f08");
    ctx.fillStyle = body;
    ctx.beginPath();
    ctx.moveTo(0, H + 20);
    for (let x = 0; x <= W; x += 6) ctx.lineTo(x, ly + wave(x));
    ctx.lineTo(W, H + 20);
    ctx.closePath();
    ctx.fill();

    // bright crest line
    ctx.strokeStyle = this.slowT > 0 ? "#bff3ff" : "#ffe28a";
    ctx.lineWidth = 3;
    ctx.lineJoin = "round";
    ctx.beginPath();
    for (let x = 0; x <= W; x += 6) {
      const y = ly + wave(x);
      if (x === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    // bubbles
    ctx.fillStyle = "rgba(255,220,120,0.75)";
    for (let i = 0; i < 7; i++) {
      const bx = hash(i * 3.3) * W;
      const ph = (t * 0.5 + hash(i) * 3) % 1;
      const by = ly + 40 - ph * 55 + wave(bx);
      const r = 2 + hash(i + 5) * 3.5 * (1 - ph);
      ctx.beginPath();
      ctx.arc(bx, by, r, 0, Math.PI * 2);
      ctx.fill();
    }
  }
}

