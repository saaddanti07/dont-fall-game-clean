// Drawing for hazards, warning markers and power-ups (same outlined cartoon style as the rest of the game).

export type HazKind = "icicle" | "rock" | "firerock" | "fruit" | "star" | "fireball" | "bird";
export type PowerType = "shield" | "magnet" | "double" | "rocket" | "slow";

const OUT = "#26102f";

export const POWER_COLOR: Record<PowerType, string> = {
  shield: "#3fb7ff",
  magnet: "#ff5a5a",
  double: "#ffc61f",
  rocket: "#ff7a18",
  slow: "#7fe3ff",
};

export const POWER_NAME: Record<PowerType, string> = {
  shield: "SHIELD",
  magnet: "MAGNET",
  double: "2x COINS",
  rocket: "ROCKET!",
  slow: "SLOW LAVA",
};

export const WARN_COLOR: Record<HazKind, string> = {
  icicle: "#7fe3ff",
  rock: "#c9a6ff",
  firerock: "#ff7a18",
  fruit: "#ff5a5a",
  star: "#ffe066",
  fireball: "#ff7a18",
  bird: "#ff5a5a",
};

// ---------------------------------------------------------------------------------------------
// Falling / flying hazards. (x, y) is the lower-centre point of the hazard.
// ---------------------------------------------------------------------------------------------
export function drawHazard(ctx: CanvasRenderingContext2D, kind: HazKind, x: number, y: number, t: number, dir = 1) {
  ctx.save();
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  ctx.lineWidth = 2.4;
  ctx.strokeStyle = OUT;
  switch (kind) {
    case "icicle": {
      const g = ctx.createLinearGradient(x - 7, 0, x + 7, 0);
      g.addColorStop(0, "#eafcff");
      g.addColorStop(1, "#6fc9ee");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(x - 7.5, y - 32);
      ctx.lineTo(x + 7.5, y - 32);
      ctx.lineTo(x, y + 2);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.strokeStyle = "rgba(255,255,255,0.9)";
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.moveTo(x - 3.5, y - 28);
      ctx.lineTo(x - 1.5, y - 10);
      ctx.stroke();
      break;
    }
    case "rock": {
      ctx.fillStyle = "#8b7bb0";
      ctx.beginPath();
      ctx.moveTo(x - 9, y - 24);
      ctx.lineTo(x + 9, y - 24);
      ctx.lineTo(x + 2, y + 2);
      ctx.lineTo(x - 2, y + 2);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "rgba(255,255,255,0.25)";
      ctx.fillRect(x - 6, y - 21, 3, 12);
      break;
    }
    case "firerock": {
      // flame tail (above, because it falls)
      const fl = 14 + 4 * Math.sin(t * 20);
      ctx.fillStyle = "#ff7a18";
      ctx.beginPath();
      ctx.moveTo(x - 9, y - 10);
      ctx.quadraticCurveTo(x - 7, y - 10 - fl, x, y - 14 - fl * 1.6);
      ctx.quadraticCurveTo(x + 7, y - 10 - fl, x + 9, y - 10);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = "#ffe066";
      ctx.beginPath();
      ctx.moveTo(x - 4, y - 10);
      ctx.quadraticCurveTo(x - 3, y - 10 - fl * 0.6, x, y - 10 - fl);
      ctx.quadraticCurveTo(x + 3, y - 10 - fl * 0.6, x + 4, y - 10);
      ctx.fill();
      ctx.translate(x, y - 11);
      ctx.rotate(t * 3);
      ctx.fillStyle = "#4a1a14";
      ctx.beginPath();
      ctx.moveTo(-11, -3);
      ctx.lineTo(-4, -11);
      ctx.lineTo(7, -9);
      ctx.lineTo(11, 1);
      ctx.lineTo(4, 10);
      ctx.lineTo(-7, 9);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.strokeStyle = "#ff9a3c";
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.moveTo(-4, -4);
      ctx.lineTo(1, 1);
      ctx.lineTo(-1, 6);
      ctx.moveTo(1, 1);
      ctx.lineTo(7, -2);
      ctx.stroke();
      break;
    }
    case "fruit": {
      ctx.translate(x, y - 10);
      ctx.rotate(Math.sin(t * 6) * 0.25);
      ctx.fillStyle = "#e63946";
      ctx.beginPath();
      ctx.arc(0, 0, 10.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "rgba(255,255,255,0.4)";
      ctx.beginPath();
      ctx.ellipse(-4, -4, 2.6, 3.6, -0.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#4fc25a";
      ctx.beginPath();
      ctx.ellipse(4, -11, 5, 2.6, -0.6, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.strokeStyle = "#5b3418";
      ctx.beginPath();
      ctx.moveTo(0, -10);
      ctx.lineTo(-1, -15);
      ctx.stroke();
      break;
    }
    case "star": {
      // comet tail above
      const g = ctx.createLinearGradient(x, y - 60, x, y - 8);
      g.addColorStop(0, "rgba(255,230,120,0)");
      g.addColorStop(1, "rgba(255,230,120,0.75)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(x - 7, y - 12);
      ctx.lineTo(x, y - 62);
      ctx.lineTo(x + 7, y - 12);
      ctx.closePath();
      ctx.fill();
      ctx.translate(x, y - 11);
      ctx.rotate(t * 4);
      ctx.fillStyle = "#ffe066";
      ctx.beginPath();
      for (let i = 0; i < 10; i++) {
        const a = (i / 10) * Math.PI * 2 - Math.PI / 2;
        const r = i % 2 ? 5.4 : 12;
        ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r);
      }
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      break;
    }
    case "fireball": {
      // tail below (fireballs rise from lava)
      const fl = 16 + 4 * Math.sin(t * 22);
      ctx.fillStyle = "#e0310f";
      ctx.beginPath();
      ctx.moveTo(x - 10, y - 10);
      ctx.quadraticCurveTo(x - 6, y - 4 + fl, x, y + fl + 4);
      ctx.quadraticCurveTo(x + 6, y - 4 + fl, x + 10, y - 10);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = "#ff7a18";
      ctx.beginPath();
      ctx.arc(x, y - 11, 11.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#ffe066";
      ctx.beginPath();
      ctx.arc(x, y - 11, 6, 0, Math.PI * 2);
      ctx.fill();
      break;
    }
    case "bird": {
      ctx.translate(x, y - 12);
      ctx.scale(dir, 1);
      const flap = Math.sin(t * 14);
      // far wing
      ctx.fillStyle = "#3a2418";
      ctx.beginPath();
      ctx.moveTo(-4, -2);
      ctx.lineTo(-14, -14 - flap * 8);
      ctx.lineTo(4, -4);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      // body
      ctx.fillStyle = "#6b4630";
      ctx.beginPath();
      ctx.ellipse(0, 0, 14, 8.5, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      // near wing
      ctx.fillStyle = "#4a2e1e";
      ctx.beginPath();
      ctx.moveTo(-6, 0);
      ctx.lineTo(-16, 12 + flap * 8);
      ctx.lineTo(6, 3);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      // head
      ctx.fillStyle = "#e9c9a0";
      ctx.beginPath();
      ctx.arc(12, -3, 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#ffb703";
      ctx.beginPath();
      ctx.moveTo(16.5, -4);
      ctx.lineTo(23, -1);
      ctx.lineTo(16.5, 0);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#fff";
      ctx.beginPath();
      ctx.arc(13, -5, 1.8, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#e63946";
      ctx.beginPath();
      ctx.arc(13.4, -5, 0.9, 0, Math.PI * 2);
      ctx.fill();
      break;
    }
  }
  ctx.restore();
}

// ---------------------------------------------------------------------------------------------
// Warning marker: rounded triangle with "!" (drawn in screen space)
// ---------------------------------------------------------------------------------------------
export function drawWarning(ctx: CanvasRenderingContext2D, x: number, y: number, color: string, t: number, lane = 0) {
  ctx.save();
  if (lane > 0) {
    ctx.strokeStyle = color;
    ctx.globalAlpha = 0.28 + 0.14 * Math.sin(t * 16);
    ctx.lineWidth = 14;
    ctx.beginPath();
    ctx.moveTo(x, y + 14);
    ctx.lineTo(x, y + lane);
    ctx.stroke();
    ctx.globalAlpha = 1;
  }
  const s = 1 + 0.12 * Math.sin(t * 16);
  ctx.translate(x, y);
  ctx.scale(s, s);
  ctx.lineJoin = "round";
  ctx.lineWidth = 3;
  ctx.strokeStyle = OUT;
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(0, -14);
  ctx.lineTo(14, 11);
  ctx.lineTo(-14, 11);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = OUT;
  ctx.fillRect(-1.8, -6, 3.6, 10);
  ctx.beginPath();
  ctx.arc(0, 7.4, 2, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

// ---------------------------------------------------------------------------------------------
// Platform-mounted hazards. (x, y) = base point on top of the platform.
// ---------------------------------------------------------------------------------------------
export function drawCactus(ctx: CanvasRenderingContext2D, x: number, y: number) {
  ctx.save();
  ctx.translate(x, y);
  ctx.lineJoin = "round";
  ctx.lineWidth = 2.4;
  ctx.strokeStyle = "#0e3a14";
  ctx.fillStyle = "#3fae4b";
  const arm = (side: number) => {
    ctx.beginPath();
    ctx.moveTo(side * 4, -9);
    ctx.lineTo(side * 9, -9);
    ctx.lineTo(side * 9, -17);
    ctx.stroke();
    ctx.lineWidth = 5.5;
    ctx.strokeStyle = "#3fae4b";
    ctx.beginPath();
    ctx.moveTo(side * 4, -9);
    ctx.lineTo(side * 9, -9);
    ctx.lineTo(side * 9, -16);
    ctx.stroke();
    ctx.lineWidth = 2.4;
    ctx.strokeStyle = "#0e3a14";
  };
  arm(-1);
  arm(1);
  rr2(ctx, -5.5, -27, 11, 28, 5.5);
  ctx.fill();
  ctx.stroke();
  ctx.strokeStyle = "rgba(255,255,255,0.85)";
  ctx.lineWidth = 1.4;
  for (const [sx, sy] of [[-3, -20], [3, -14], [-3, -8], [9, -17], [-9, -17]]) {
    ctx.beginPath();
    ctx.moveTo(sx, sy);
    ctx.lineTo(sx + (sx < 0 ? -2.5 : 2.5), sy - 1.5);
    ctx.stroke();
  }
  ctx.fillStyle = "#ff6fa5";
  ctx.beginPath();
  ctx.arc(0, -28, 3, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function rr2(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

/** stage: 0 idle bud (safe), 1 warning (growing, red), 2 snapping (harmful). u = 0..1 progress within stage. */
export function drawPlant(ctx: CanvasRenderingContext2D, x: number, y: number, stage: 0 | 1 | 2, u: number, t: number) {
  ctx.save();
  ctx.translate(x, y);
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  const h = stage === 0 ? 12 + Math.sin(t * 3) * 1.2 : stage === 1 ? 14 + u * 12 : 36;
  const shake = stage === 1 ? Math.sin(t * 50) * 1.6 : 0;
  // leaves at base
  ctx.fillStyle = "#2f9a3c";
  ctx.strokeStyle = "#0e3a14";
  ctx.lineWidth = 2.2;
  ctx.beginPath();
  ctx.ellipse(-6, -2, 6, 3, -0.4, 0, Math.PI * 2);
  ctx.ellipse(6, -2, 6, 3, 0.4, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  // stem
  ctx.strokeStyle = "#0e3a14";
  ctx.lineWidth = 7;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(shake, -h);
  ctx.stroke();
  ctx.strokeStyle = "#3fae4b";
  ctx.lineWidth = 3.4;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(shake, -h);
  ctx.stroke();
  // head
  ctx.translate(shake, -h);
  const open = stage === 2 ? 0.95 : stage === 1 ? 0.15 + u * 0.2 : 0;
  const warn = stage === 1;
  ctx.lineWidth = 2.4;
  ctx.strokeStyle = "#0e3a14";
  const jaw = (dir: number) => {
    ctx.save();
    ctx.rotate(dir * open * 0.9);
    ctx.fillStyle = warn ? (Math.sin(t * 30) > 0 ? "#ff5a5a" : "#d9387a") : "#c2185b";
    ctx.beginPath();
    ctx.arc(0, 0, 11, dir > 0 ? Math.PI : 0, dir > 0 ? 0 : Math.PI);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    if (open > 0.3) {
      ctx.fillStyle = "#fff";
      for (let i = -1; i <= 1; i++) {
        ctx.beginPath();
        ctx.moveTo(i * 6 - 2.4, 0);
        ctx.lineTo(i * 6, dir * -5);
        ctx.lineTo(i * 6 + 2.4, 0);
        ctx.fill();
      }
    }
    ctx.restore();
  };
  jaw(-1);
  jaw(1);
  ctx.restore();
}

// ---------------------------------------------------------------------------------------------
// Power-ups
// ---------------------------------------------------------------------------------------------
export function drawPowerup(ctx: CanvasRenderingContext2D, type: PowerType, x: number, y: number, t: number, scale = 1) {
  const c = POWER_COLOR[type];
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);
  // glow
  const g = ctx.createRadialGradient(0, 0, 4, 0, 0, 30);
  g.addColorStop(0, c + "99");
  g.addColorStop(1, c + "00");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(0, 0, 30 + Math.sin(t * 5) * 2, 0, Math.PI * 2);
  ctx.fill();
  // bubble
  ctx.lineWidth = 2.6;
  ctx.strokeStyle = OUT;
  ctx.fillStyle = "#2b1650";
  ctx.beginPath();
  ctx.arc(0, 0, 16, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.strokeStyle = c;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(0, 0, 13.4, 0, Math.PI * 2);
  ctx.stroke();
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  switch (type) {
    case "shield":
      ctx.fillStyle = c;
      ctx.strokeStyle = "#fff";
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.moveTo(0, -8.5);
      ctx.lineTo(7.5, -5.5);
      ctx.quadraticCurveTo(7.5, 4.5, 0, 9);
      ctx.quadraticCurveTo(-7.5, 4.5, -7.5, -5.5);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#fff";
      ctx.fillRect(-1.2, -4.5, 2.4, 9);
      ctx.fillRect(-4, -1.3, 8, 2.4);
      break;
    case "magnet":
      ctx.lineWidth = 5;
      ctx.strokeStyle = c;
      ctx.beginPath();
      ctx.moveTo(-6, -7);
      ctx.lineTo(-6, 1);
      ctx.arc(0, 1, 6, Math.PI, 0, true);
      ctx.lineTo(6, -7);
      ctx.stroke();
      ctx.strokeStyle = "#fff";
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.moveTo(-6, -8);
      ctx.lineTo(-6, -4);
      ctx.moveTo(6, -8);
      ctx.lineTo(6, -4);
      ctx.stroke();
      break;
    case "double":
      ctx.font = "900 15px 'Luckiest Guy', Arial Black, sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.lineWidth = 3;
      ctx.strokeStyle = "#5a3300";
      ctx.strokeText("x2", 0, 1);
      ctx.fillStyle = c;
      ctx.fillText("x2", 0, 1);
      break;
    case "rocket":
      ctx.rotate(-Math.PI / 4);
      ctx.fillStyle = "#ffcf5a";
      ctx.beginPath();
      ctx.moveTo(-3, 8);
      ctx.lineTo(0, 14 + Math.sin(t * 20) * 2);
      ctx.lineTo(3, 8);
      ctx.fill();
      ctx.fillStyle = "#ff5a5a";
      ctx.beginPath();
      ctx.moveTo(-5, 4);
      ctx.lineTo(-9, 10);
      ctx.lineTo(-3, 7);
      ctx.moveTo(5, 4);
      ctx.lineTo(9, 10);
      ctx.lineTo(3, 7);
      ctx.fill();
      ctx.fillStyle = "#f4f7fb";
      ctx.strokeStyle = OUT;
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.moveTo(0, -11);
      ctx.quadraticCurveTo(7, -3, 4.5, 8);
      ctx.lineTo(-4.5, 8);
      ctx.quadraticCurveTo(-7, -3, 0, -11);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#ff5a5a";
      ctx.beginPath();
      ctx.moveTo(0, -11);
      ctx.quadraticCurveTo(3.5, -8, 4, -5);
      ctx.lineTo(-4, -5);
      ctx.quadraticCurveTo(-3.5, -8, 0, -11);
      ctx.fill();
      ctx.fillStyle = "#3fb7ff";
      ctx.beginPath();
      ctx.arc(0, 0.5, 2.4, 0, Math.PI * 2);
      ctx.fill();
      break;
    case "slow":
      ctx.strokeStyle = c;
      ctx.lineWidth = 2.4;
      for (let i = 0; i < 3; i++) {
        const a = (i * Math.PI) / 3;
        ctx.beginPath();
        ctx.moveTo(Math.cos(a) * 9, Math.sin(a) * 9);
        ctx.lineTo(-Math.cos(a) * 9, -Math.sin(a) * 9);
        ctx.stroke();
      }
      ctx.lineWidth = 1.8;
      ctx.strokeStyle = "#fff";
      ctx.beginPath();
      ctx.arc(0, 0, 3.2, 0, Math.PI * 2);
      ctx.stroke();
      break;
  }
  ctx.restore();
}

const iconCache: Partial<Record<PowerType, string>> = {};
/** Renders a power-up icon to a data URL (single source of truth for HUD icons). */
export function powerIconUrl(type: PowerType): string {
  const hit = iconCache[type];
  if (hit) return hit;
  const c = document.createElement("canvas");
  c.width = c.height = 72;
  const ctx = c.getContext("2d")!;
  drawPowerup(ctx, type, 36, 36, 0, 1.55);
  const url = c.toDataURL("image/png");
  iconCache[type] = url;
  return url;
}
