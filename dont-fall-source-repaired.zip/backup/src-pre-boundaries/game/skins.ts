// Character skins. All skins share the exact same body proportions, hitbox and animation —
// only colours and headgear differ (purely cosmetic, no gameplay advantage).

export type HatStyle =
  | "explorer"
  | "pith"
  | "ninja"
  | "robot"
  | "pirate"
  | "astro"
  | "beanie"
  | "knight"
  | "ranger"
  | "turban"
  | "wizard"
  | "crown";

export interface Skin {
  id: string;
  name: string;
  price: number;
  blurb: string;
  jacketTop: string;
  jacketBot: string;
  belt: string;
  buckle: string;
  scarf: string;
  boots: string;
  pack: string;
  packTrim: string;
  face: string;
  hat: HatStyle;
  hatBrim: string;
  hatMain1: string;
  hatMain2: string;
  hatBand: string;
  accent: string;
}

/** The original adventurer — default, free, drawn exactly as before. */
export const ORIGINAL: Skin = {
  id: "original",
  name: "Original Adventurer",
  price: 0,
  blurb: "Where it all began.",
  jacketTop: "#ff9f43",
  jacketBot: "#e2671c",
  belt: "#4a2a14",
  buckle: "#ffd23f",
  scarf: "#e63946",
  boots: "#5b3418",
  pack: "#8a5a2b",
  packTrim: "#c28a4a",
  face: "#ffd7b0",
  hat: "explorer",
  hatBrim: "#b9803f",
  hatMain1: "#d79a52",
  hatMain2: "#a76f33",
  hatBand: "#e63946",
  accent: "#ffd23f",
};

const base = ORIGINAL;
const mk = (o: Partial<Skin> & Pick<Skin, "id" | "name" | "price" | "blurb" | "hat">): Skin => ({ ...base, ...o });

export const SKINS: Skin[] = [
  ORIGINAL,
  mk({
    id: "ninja", name: "Ninja", price: 300, blurb: "Silent, swift and stylish.", hat: "ninja",
    jacketTop: "#3a3d5c", jacketBot: "#171827", belt: "#e63946", buckle: "#c9d1dc", scarf: "#e63946",
    boots: "#171827", pack: "#2c2f48", packTrim: "#e63946", hatBand: "#e63946", hatBrim: "#171827", hatMain1: "#22243a", hatMain2: "#14151f", accent: "#c9d1dc",
  }),
  mk({
    id: "explorer", name: "Explorer", price: 500, blurb: "Pith helmet, safari vest.", hat: "pith",
    jacketTop: "#d6b66a", jacketBot: "#a98536", belt: "#5b3a1a", scarf: "#3f9d4a", boots: "#6b4423",
    pack: "#4d6b3a", packTrim: "#9ccf6b", hatBrim: "#d9c18a", hatMain1: "#f6ebc5", hatMain2: "#dcc48c", hatBand: "#3f9d4a",
  }),
  mk({
    id: "robot", name: "Robot", price: 750, blurb: "Beep boop. Bounce bounce.", hat: "robot",
    jacketTop: "#9fb3c8", jacketBot: "#62768d", belt: "#2f3b4a", buckle: "#5ff2ff", scarf: "#3fb7ff", boots: "#38465a",
    pack: "#46586f", packTrim: "#5ff2ff", face: "#cfd8e3", hatMain1: "#5ff2ff", accent: "#ff4d4d",
  }),
  mk({
    id: "pirate", name: "Pirate", price: 1000, blurb: "Yarr! Lava be no match.", hat: "pirate",
    jacketTop: "#a3232f", jacketBot: "#661019", belt: "#2a1a10", scarf: "#f5f0e0", boots: "#2a1a10",
    pack: "#5b3a1a", packTrim: "#d8a24a", hatBrim: "#14141a", hatMain1: "#2e2e3a", hatMain2: "#1a1a22", hatBand: "#ffd23f",
  }),
  mk({
    id: "astronaut", name: "Astronaut", price: 1500, blurb: "Low gravity? Not today.", hat: "astro",
    jacketTop: "#f4f7fb", jacketBot: "#c1cbd9", belt: "#ff7a18", scarf: "#ff7a18", boots: "#8b97a8",
    pack: "#b9c2d0", packTrim: "#ff7a18", hatBand: "#ff7a18",
  }),
  mk({
    id: "wizard", name: "Wizard", price: 1250, blurb: "A little magic never hurts.", hat: "wizard",
    jacketTop: "#7a4be0", jacketBot: "#4a24a8", belt: "#ffd23f", buckle: "#fff29a", scarf: "#a58bff", boots: "#2f1a6b",
    pack: "#4a2f9a", packTrim: "#ffd23f", hatBrim: "#4a24a8", hatMain1: "#8456f0", hatMain2: "#4a24a8", hatBand: "#ffd23f",
  }),
  mk({
    id: "snow", name: "Snow Explorer", price: 1800, blurb: "Cozy parka, cold peaks.", hat: "beanie",
    jacketTop: "#66b9f2", jacketBot: "#3a82c4", belt: "#f5f9ff", buckle: "#9edcff", scarf: "#ffffff", boots: "#2f4f7a",
    pack: "#e8f3ff", packTrim: "#7fc4ff", hatMain1: "#ee5468", hatMain2: "#c0293f", hatBand: "#ffffff", hatBrim: "#ffffff",
  }),
  mk({
    id: "fire", name: "Fire Knight", price: 2200, blurb: "Forged in the volcano.", hat: "knight",
    jacketTop: "#c4232f", jacketBot: "#7a1019", belt: "#ffc61f", buckle: "#fff29a", scarf: "#ff7a18", boots: "#4a4f5c",
    pack: "#5a5f6e", packTrim: "#ffc61f", hatMain1: "#d3dae4", hatMain2: "#8f9aaa", hatBand: "#ffc61f", accent: "#ff6a1a",
  }),
  mk({
    id: "ranger", name: "Forest Ranger", price: 2500, blurb: "One with the treetops.", hat: "ranger",
    jacketTop: "#49ac55", jacketBot: "#2a6d34", belt: "#5b3a1a", scarf: "#8b5a2b", boots: "#4a2f18",
    pack: "#6b4423", packTrim: "#d8a24a", hatMain1: "#3a9444", hatMain2: "#256a2f", hatBand: "#e63946", hatBrim: "#256a2f",
  }),
  mk({
    id: "desert", name: "Desert Traveler", price: 3000, blurb: "Sun-proof and sand-ready.", hat: "turban",
    jacketTop: "#ecca84", jacketBot: "#c79a4a", belt: "#7a4a1a", buckle: "#3fb7ff", scarf: "#2a6fd6", boots: "#8b5a2b",
    pack: "#b8864a", packTrim: "#f1d9a0", hatMain1: "#f8f1e2", hatMain2: "#d8cdb0", hatBand: "#3fb7ff",
  }),
  mk({
    id: "royal", name: "Royal Gold", price: 5000, blurb: "For true climbing legends.", hat: "crown",
    jacketTop: "#ffd84a", jacketBot: "#e0a000", belt: "#7a2a2a", buckle: "#ff5a6a", scarf: "#c01f3a", boots: "#7a4a00",
    pack: "#c01f3a", packTrim: "#ffd23f", hatMain1: "#ffd84a", hatMain2: "#e0a000", hatBand: "#ff5a6a", hatBrim: "#e0a000",
  }),
];

export function skinById(id: string): Skin {
  return SKINS.find((s) => s.id === id) ?? ORIGINAL;
}
