// World definitions and parallax backgrounds. World 1 (Cave) is the original purple cave, unchanged.

export const WORLD_LEN = 500; // meters per world
export const WORLD_COUNT = 6;
export const ENDLESS_START = WORLD_LEN * WORLD_COUNT; // 3000 m

export interface WorldDef {
  id: string;
  name: string;
  subtitle: string;
  accent: string;
  ambient: number; // base number of ambient particles
}

export const WORLDS: WorldDef[] = [
  { id: "cave", name: "CAVE", subtitle: "Climb out of the crystal caverns!", accent: "#b48cff", ambient: 10 },
  { id: "snow", name: "SNOW", subtitle: "Slippery ice and falling icicles!", accent: "#7fe3ff", ambient: 46 },
  { id: "volcano", name: "VOLCANO", subtitle: "Fire rocks fall and the lava erupts!", accent: "#ff7a18", ambient: 30 },
  { id: "forest", name: "FOREST", subtitle: "Snapping plants and falling fruit!", accent: "#6fe08a", ambient: 26 },
  { id: "desert", name: "DESERT", subtitle: "Cacti, vultures and sandstorms!", accent: "#ffc61f", ambient: 22 },
  { id: "sky", name: "SKY", subtitle: "Ride the wind above the clouds!", accent: "#8fd3ff", ambient: 22 },
];

const ROMAN = ["", "", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"];

export interface WorldInfo {
  seg: number; // absolute 500 m segment
  index: number; // 0..5 which environment
  loop: number; // 0 for the first pass, 1+ in endless mode
}

export function worldAt(meters: number): WorldInfo {
  const seg = Math.floor(Math.max(0, meters) / WORLD_LEN);
  return { seg, index: seg % WORLD_COUNT, loop: Math.floor(seg / WORLD_COUNT) };
}

export function worldTitle(index: number, loop: number): string {
  const n = WORLDS[index].name;
  return loop === 0 ? n : `${n} ${ROMAN[Math.min(loop + 1, ROMAN.length - 1)] ?? loop + 1}`;
}

export function worldLabel(seg: number, loop: number): string {
  return loop === 0 ? `WORLD ${seg + 1} OF ${WORLD_COUNT}` : `ENDLESS · LEVEL ${loop}`;
}

export function hash(n: number) {
  const s = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return s - Math.floor(s);
}

type Ctx = CanvasRenderingContext2D;

function tiled(off: number, tile: number, H: number, cb: (i: number, y: number) => void) {
  const first = Math.floor(off / tile) - 1;
  const last = Math.ceil((off + H) / tile) + 1;
  for (let i = first; i <= last; i++) cb(i, i * tile - off);
}

function gradient(ctx: Ctx, H: number, stops: [number, string][]) {
  const g = ctx.createLinearGradient(0, 0, 0, H);
  for (const [o, c] of stops) g.addColorStop(o, c);
  return g;
}

function walls(ctx: Ctx, W: number, H: number, wallOff: number, fill: string, rim?: string, inset = 8, amp = 14) {
  const step = 46;
  const a = Math.floor(wallOff / step) - 1;
  const b = Math.ceil((wallOff + H) / step) + 1;
  for (const side of [0, 1]) {
    ctx.fillStyle = fill;
    ctx.beginPath();
    ctx.moveTo(side ? W : 0, -10);
    for (let i = a; i <= b; i++) {
      const o = inset + hash(i + (side ? 99 : 0)) * amp;
      ctx.lineTo(side ? W - o : o, i * step - wallOff);
    }
    ctx.lineTo(side ? W : 0, H + 10);
    ctx.closePath();
    ctx.fill();
    if (rim) {
      ctx.strokeStyle = rim;
      ctx.lineWidth = 2;
      ctx.beginPath();
      for (let i = a; i <= b; i++) {
        const o = inset + hash(i + (side ? 99 : 0)) * amp;
        const px = side ? W - o : o;
        if (i === a) ctx.moveTo(px, i * step - wallOff);
        else ctx.lineTo(px, i * step - wallOff);
      }
      ctx.stroke();
    }
  }
}

function crystals(ctx: Ctx, W: number, H: number, cam: number, c1: string, c2: string, a1: string, a2: string) {
  const tile = 260;
  const off = cam * 0.25;
  tiled(off, tile, H, (i) => {
    for (let k = 0; k < 3; k++) {
      const seed = i * 7 + k * 13;
      const x = hash(seed) * W;
      const y = i * tile + hash(seed + 1) * tile - off;
      const s = 14 + hash(seed + 2) * 26;
      const hue = hash(seed + 3) > 0.5 ? c1 : c2;
      ctx.fillStyle = hue + a1 + ")";
      ctx.beginPath();
      ctx.moveTo(x, y - s * 1.6);
      ctx.lineTo(x + s * 0.5, y);
      ctx.lineTo(x - s * 0.5, y);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = hue + a2 + ")";
      ctx.beginPath();
      ctx.moveTo(x + s * 0.7, y - s);
      ctx.lineTo(x + s * 1.1, y);
      ctx.lineTo(x + s * 0.3, y);
      ctx.closePath();
      ctx.fill();
    }
  });
}

function puff(ctx: Ctx, x: number, y: number, s: number) {
  ctx.beginPath();
  ctx.arc(x, y, s * 0.55, 0, Math.PI * 2);
  ctx.arc(x + s * 0.55, y + s * 0.1, s * 0.42, 0, Math.PI * 2);
  ctx.arc(x - s * 0.55, y + s * 0.12, s * 0.4, 0, Math.PI * 2);
  ctx.arc(x + s * 0.1, y - s * 0.3, s * 0.4, 0, Math.PI * 2);
  ctx.fill();
}

// ---- individual worlds -----------------------------------------------------------------------

function cave(ctx: Ctx, W: number, H: number, cam: number) {
  ctx.fillStyle = gradient(ctx, H, [[0, "#1a0833"], [0.6, "#2e1058"], [1, "#4a1a7c"]]);
  ctx.fillRect(0, 0, W, H);
  crystals(ctx, W, H, cam, "rgba(190,130,255,", "rgba(110,220,255,", "0.16", "0.1");
  walls(ctx, W, H, cam * 0.6, "#150626");
}

function snow(ctx: Ctx, W: number, H: number, cam: number, t: number) {
  ctx.fillStyle = gradient(ctx, H, [[0, "#0c1f45"], [0.55, "#27508c"], [1, "#6fa8d6"]]);
  ctx.fillRect(0, 0, W, H);
  // aurora ribbons
  for (let k = 0; k < 2; k++) {
    const base = 80 + k * 90;
    const g = ctx.createLinearGradient(0, base - 40, 0, base + 60);
    g.addColorStop(0, "rgba(120,255,210,0)");
    g.addColorStop(0.5, k ? "rgba(140,170,255,0.16)" : "rgba(120,255,210,0.16)");
    g.addColorStop(1, "rgba(120,255,210,0)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(0, base + 60);
    for (let x = 0; x <= W; x += 20) ctx.lineTo(x, base + Math.sin(x * 0.02 + t * 0.4 + k * 2) * 22);
    ctx.lineTo(W, base + 60);
    ctx.closePath();
    ctx.fill();
  }
  crystals(ctx, W, H, cam, "rgba(220,245,255,", "rgba(150,220,255,", "0.2", "0.12");
  walls(ctx, W, H, cam * 0.6, "#12305a", "rgba(200,240,255,0.55)");
}

function volcano(ctx: Ctx, W: number, H: number, cam: number, t: number) {
  ctx.fillStyle = gradient(ctx, H, [[0, "#1c0606"], [0.55, "#5c140a"], [1, "#c8400f"]]);
  ctx.fillRect(0, 0, W, H);
  // basalt columns with glowing cracks
  const tile = 230;
  const off = cam * 0.3;
  tiled(off, tile, H, (i, base) => {
    for (let k = 0; k < 2; k++) {
      const seed = i * 5 + k * 11;
      const x = hash(seed) * W;
      const w = 26 + hash(seed + 1) * 22;
      const y = base + hash(seed + 2) * 60;
      ctx.fillStyle = "rgba(42,10,8,0.85)";
      ctx.beginPath();
      ctx.moveTo(x - w / 2, y + tile);
      ctx.lineTo(x - w / 2 + 4, y);
      ctx.lineTo(x + w / 2 - 4, y - 8);
      ctx.lineTo(x + w / 2, y + tile);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = `rgba(255,110,30,${0.3 + 0.25 * Math.sin(t * 3 + seed)})`;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(x - 2, y + 10);
      ctx.lineTo(x + 3, y + 50);
      ctx.lineTo(x - 3, y + 90);
      ctx.stroke();
    }
  });
  const haze = ctx.createLinearGradient(0, H, 0, H - 280);
  haze.addColorStop(0, "rgba(255,70,20,0.28)");
  haze.addColorStop(1, "rgba(255,70,20,0)");
  ctx.fillStyle = haze;
  ctx.fillRect(0, H - 280, W, 280);
  walls(ctx, W, H, cam * 0.6, "#140404", "rgba(255,122,24,0.55)");
}

function forest(ctx: Ctx, W: number, H: number, cam: number, t: number) {
  ctx.fillStyle = gradient(ctx, H, [[0, "#041a0c"], [0.55, "#0d4020"], [1, "#2c7a38"]]);
  ctx.fillRect(0, 0, W, H);
  // far trunks
  ctx.fillStyle = "rgba(6,32,16,0.75)";
  ctx.fillRect(58, 0, 34, H);
  ctx.fillRect(268, 0, 38, H);
  // light shafts
  for (let k = 0; k < 3; k++) {
    const x = 70 + k * 100 + Math.sin(t * 0.3 + k) * 12;
    ctx.fillStyle = "rgba(220,255,160,0.06)";
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x + 34, 0);
    ctx.lineTo(x - 50, H);
    ctx.lineTo(x - 100, H);
    ctx.closePath();
    ctx.fill();
  }
  // near giant trunks (left/right) with bark and branches
  const off = cam * 0.55;
  for (const side of [0, 1]) {
    const tx = side ? W - 44 : -14;
    ctx.fillStyle = "#2b1a0d";
    ctx.fillRect(tx, 0, 58, H);
    ctx.strokeStyle = "#432a16";
    ctx.lineWidth = 2;
    tiled(off, 90, H, (i, y) => {
      for (let k = 0; k < 3; k++) {
        const bx = tx + 8 + hash(i * 3 + k + side * 50) * 42;
        ctx.beginPath();
        ctx.moveTo(bx, y);
        ctx.lineTo(bx + (hash(i + k) - 0.5) * 6, y + 70);
        ctx.stroke();
      }
    });
    ctx.strokeStyle = "#1b0f06";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(side ? tx : tx + 58, 0);
    ctx.lineTo(side ? tx : tx + 58, H);
    ctx.stroke();
    tiled(off, 200, H, (i, y) => {
      const len = 34 + hash(i * 2 + side * 7) * 50;
      const by = y + hash(i + side * 3) * 120;
      const x0 = side ? tx : tx + 58;
      const x1 = side ? x0 - len : x0 + len;
      ctx.strokeStyle = "#2b1a0d";
      ctx.lineWidth = 9;
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(x0, by + 10);
      ctx.lineTo(x1, by - 6);
      ctx.stroke();
      for (let k = 0; k < 3; k++) {
        ctx.fillStyle = k % 2 ? "#2f8a3c" : "#1f6a2c";
        ctx.beginPath();
        ctx.arc(x1 + (side ? -1 : 1) * (k * 8 - 4), by - 10 - (k % 2) * 8, 14 - k * 2, 0, Math.PI * 2);
        ctx.fill();
      }
    });
  }
}

function desert(ctx: Ctx, W: number, H: number, cam: number) {
  ctx.fillStyle = gradient(ctx, H, [[0, "#f08a3c"], [0.5, "#ffbe62"], [1, "#ffe6a3"]]);
  ctx.fillRect(0, 0, W, H);
  // sun
  const sun = ctx.createRadialGradient(278, 100, 6, 278, 100, 120);
  sun.addColorStop(0, "rgba(255,250,200,0.95)");
  sun.addColorStop(0.25, "rgba(255,240,170,0.5)");
  sun.addColorStop(1, "rgba(255,230,150,0)");
  ctx.fillStyle = sun;
  ctx.fillRect(0, 0, W, 260);
  // dunes (two parallax layers)
  const layers: [number, number, string][] = [[0.2, 230, "rgba(214,112,40,0.38)"], [0.45, 190, "rgba(176,82,30,0.34)"]];
  for (const [par, tile, col] of layers) {
    tiled(cam * par, tile, H, (i, y) => {
      const s = i * 3 + par * 10;
      const fade = ctx.createLinearGradient(0, y, 0, y + 150);
      fade.addColorStop(0, col);
      fade.addColorStop(1, col.replace(/[\d.]+\)$/, "0)"));
      ctx.fillStyle = fade;
      ctx.beginPath();
      ctx.moveTo(0, y + 90);
      ctx.quadraticCurveTo(W * 0.25, y - 20 + hash(s) * 50, W * 0.55, y + 40);
      ctx.quadraticCurveTo(W * 0.8, y + 70 - hash(s + 1) * 40, W, y + 20);
      ctx.lineTo(W, y + 150);
      ctx.lineTo(0, y + 150);
      ctx.closePath();
      ctx.fill();
    });
  }
  walls(ctx, W, H, cam * 0.6, "#9a4d1f", "rgba(255,208,138,0.5)", 8, 16);
}

function sky(ctx: Ctx, W: number, H: number, cam: number, t: number) {
  ctx.fillStyle = gradient(ctx, H, [[0, "#2d7fe3"], [0.5, "#6cc0f5"], [1, "#cfeeff"]]);
  ctx.fillRect(0, 0, W, H);
  const sun = ctx.createRadialGradient(70, 110, 4, 70, 110, 100);
  sun.addColorStop(0, "rgba(255,255,220,0.95)");
  sun.addColorStop(0.3, "rgba(255,255,200,0.4)");
  sun.addColorStop(1, "rgba(255,255,200,0)");
  ctx.fillStyle = sun;
  ctx.fillRect(0, 0, W, 240);
  // far floating islands
  tiled(cam * 0.15, 300, H, (i, y) => {
    const x = hash(i * 9) * (W - 60) + 30;
    const yy = y + hash(i * 9 + 1) * 200;
    const s = 22 + hash(i * 9 + 2) * 20;
    ctx.fillStyle = "rgba(90,70,60,0.35)";
    ctx.beginPath();
    ctx.moveTo(x - s, yy);
    ctx.lineTo(x + s, yy);
    ctx.lineTo(x, yy + s * 1.1);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "rgba(90,200,100,0.4)";
    ctx.beginPath();
    ctx.ellipse(x, yy, s, s * 0.28, 0, 0, Math.PI * 2);
    ctx.fill();
  });
  // clouds
  ctx.fillStyle = "rgba(255,255,255,0.5)";
  tiled(cam * 0.3, 190, H, (i, y) => {
    for (let k = 0; k < 2; k++) {
      const x = ((hash(i * 4 + k) * (W + 120) + t * (4 + k * 3)) % (W + 120)) - 60;
      puff(ctx, x, y + hash(i * 4 + k + 7) * 160, 34 + hash(i + k) * 20);
    }
  });
  ctx.fillStyle = "rgba(255,255,255,0.85)";
  tiled(cam * 0.6, 280, H, (i, y) => {
    const x = ((hash(i * 17 + 3) * (W + 160) + t * 9) % (W + 160)) - 80;
    puff(ctx, x, y + hash(i * 17 + 5) * 200, 46 + hash(i) * 22);
  });
}

export function drawWorldBackground(ctx: Ctx, index: number, W: number, H: number, cam: number, t: number) {
  switch (index) {
    case 1: return snow(ctx, W, H, cam, t);
    case 2: return volcano(ctx, W, H, cam, t);
    case 3: return forest(ctx, W, H, cam, t);
    case 4: return desert(ctx, W, H, cam);
    case 5: return sky(ctx, W, H, cam, t);
    default: return cave(ctx, W, H, cam);
  }
}
