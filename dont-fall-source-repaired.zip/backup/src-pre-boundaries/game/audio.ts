// Tiny WebAudio synth: sound effects + looping music with a unique theme and ambience per world.
// Everything is generated in code (no audio files), so it is original and license-free.

export type SfxName =
  | "jump" | "land" | "coin" | "crumble" | "die" | "click" | "reward" | "spring"
  | "powerup" | "warn" | "world" | "buy" | "over" | "near" | "shield" | "error";

interface Theme {
  step: number; // seconds per 16th
  arp: number[]; // 8 notes
  mult: number[]; // per-bar pitch multipliers (4 bars)
  bass: number[]; // per-bar bass note
  arpType: OscillatorType;
  bassType: OscillatorType;
  arpDur: number;
  arpVol: number;
  bassVol: number;
  noise?: { type: BiquadFilterType; freq: number; gain: number; lfo: number };
}

const THEMES: Theme[] = [
  // 0 CAVE — the original theme
  { step: 0.19, arp: [440, 523.25, 659.25, 523.25, 392, 466.16, 587.33, 466.16], mult: [1, 1, 0.794, 0.891], bass: [110, 110, 87.31, 98],
    arpType: "triangle", bassType: "sine", arpDur: 0.16, arpVol: 0.5, bassVol: 0.9 },
  // 1 SNOW — slow, glassy bells and howling wind
  { step: 0.28, arp: [659.25, 783.99, 987.77, 783.99, 587.33, 739.99, 880, 739.99], mult: [1, 0.891, 0.794, 0.891], bass: [82.41, 73.42, 65.41, 73.42],
    arpType: "sine", bassType: "sine", arpDur: 0.4, arpVol: 0.55, bassVol: 0.8, noise: { type: "lowpass", freq: 700, gain: 0.5, lfo: 0.13 } },
  // 2 VOLCANO — driving, low and rumbling
  { step: 0.15, arp: [329.63, 349.23, 415.3, 349.23, 329.63, 392, 415.3, 392], mult: [1, 1.059, 1, 0.891], bass: [82.41, 82.41, 87.31, 73.42],
    arpType: "square", bassType: "sawtooth", arpDur: 0.1, arpVol: 0.22, bassVol: 0.5, noise: { type: "lowpass", freq: 170, gain: 1.1, lfo: 0.4 } },
  // 3 FOREST — playful pentatonic with rustling leaves
  { step: 0.2, arp: [523.25, 587.33, 659.25, 783.99, 659.25, 587.33, 880, 783.99], mult: [1, 0.891, 0.749, 0.891], bass: [130.81, 116.54, 98, 116.54],
    arpType: "triangle", bassType: "sine", arpDur: 0.14, arpVol: 0.55, bassVol: 0.8, noise: { type: "highpass", freq: 3500, gain: 0.1, lfo: 0.25 } },
  // 4 DESERT — phrygian-dominant twang and sand wind
  { step: 0.21, arp: [329.63, 349.23, 415.3, 493.88, 415.3, 349.23, 523.25, 493.88], mult: [1, 1, 0.944, 1], bass: [82.41, 82.41, 87.31, 82.41],
    arpType: "triangle", bassType: "triangle", arpDur: 0.18, arpVol: 0.6, bassVol: 0.8, noise: { type: "bandpass", freq: 900, gain: 0.35, lfo: 0.2 } },
  // 5 SKY — airy major arpeggios
  { step: 0.22, arp: [523.25, 659.25, 783.99, 1046.5, 783.99, 659.25, 987.77, 783.99], mult: [1, 1.122, 0.891, 1], bass: [130.81, 146.83, 116.54, 130.81],
    arpType: "sine", bassType: "sine", arpDur: 0.22, arpVol: 0.5, bassVol: 0.7, noise: { type: "highpass", freq: 1800, gain: 0.16, lfo: 0.1 } },
];

class AudioEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private amb: { src: AudioBufferSourceNode; gain: GainNode; lfo: OscillatorNode } | null = null;
  private musicOn = true;
  private sfxOn = true;
  private musicVol = 0.6;
  private sfxVol = 0.8;
  private timer: number | null = null;
  private step = 0;
  private nextTime = 0;
  private world = 0;
  private lastWarn = 0;

  /** Must be called from a user gesture at least once. */
  unlock() {
    if (!this.ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.9;
      this.master.connect(this.ctx.destination);
      this.musicGain = this.ctx.createGain();
      this.sfxGain = this.ctx.createGain();
      this.musicGain.connect(this.master);
      this.sfxGain.connect(this.master);
      const len = this.ctx.sampleRate * 2;
      this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const d = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      this.applyVolumes();
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
    this.syncMusic();
    this.startAmbience();
  }

  configure(s: { musicOn: boolean; sfxOn: boolean; musicVol: number; sfxVol: number }) {
    this.musicOn = s.musicOn;
    this.sfxOn = s.sfxOn;
    this.musicVol = s.musicVol;
    this.sfxVol = s.sfxVol;
    this.applyVolumes();
    this.syncMusic();
  }

  /** Switch the music theme + ambience to a world (0..5). */
  setWorld(i: number) {
    const w = Math.max(0, Math.min(THEMES.length - 1, i));
    if (w === this.world) return;
    this.world = w;
    this.step = 0;
    this.startAmbience();
  }

  private applyVolumes() {
    if (!this.ctx || !this.musicGain || !this.sfxGain) return;
    this.musicGain.gain.setTargetAtTime(this.musicOn ? this.musicVol * 0.22 : 0, this.ctx.currentTime, 0.05);
    this.sfxGain.gain.setTargetAtTime(this.sfxOn ? this.sfxVol * 0.5 : 0, this.ctx.currentTime, 0.02);
  }

  private startAmbience() {
    if (!this.ctx || !this.musicGain || !this.noiseBuf) return;
    const t = this.ctx.currentTime;
    if (this.amb) {
      const old = this.amb;
      old.gain.gain.cancelScheduledValues(t);
      old.gain.gain.setTargetAtTime(0, t, 0.25);
      window.setTimeout(() => {
        try { old.src.stop(); old.lfo.stop(); } catch { /* already stopped */ }
      }, 1500);
      this.amb = null;
    }
    const cfg = THEMES[this.world].noise;
    if (!cfg) return;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    src.loop = true;
    const filt = this.ctx.createBiquadFilter();
    filt.type = cfg.type;
    filt.frequency.value = cfg.freq;
    const gain = this.ctx.createGain();
    gain.gain.value = 0;
    gain.gain.setTargetAtTime(cfg.gain * 0.5, t, 0.6);
    const lfo = this.ctx.createOscillator();
    lfo.frequency.value = cfg.lfo;
    const depth = this.ctx.createGain();
    depth.gain.value = cfg.gain * 0.3;
    lfo.connect(depth);
    depth.connect(gain.gain);
    src.connect(filt);
    filt.connect(gain);
    gain.connect(this.musicGain);
    src.start();
    lfo.start();
    this.amb = { src, gain, lfo };
  }

  private tone(freq: number, start: number, dur: number, type: OscillatorType, vol: number, dest: AudioNode, slideTo?: number) {
    if (!this.ctx) return;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, start);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, start + dur);
    g.gain.setValueAtTime(0.0001, start);
    g.gain.exponentialRampToValueAtTime(vol, start + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, start + dur);
    o.connect(g);
    g.connect(dest);
    o.start(start);
    o.stop(start + dur + 0.05);
  }

  private noiseHit(start: number, dur: number, freq: number, vol: number, dest: AudioNode) {
    if (!this.ctx || !this.noiseBuf) return;
    const s = this.ctx.createBufferSource();
    s.buffer = this.noiseBuf;
    const f = this.ctx.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = freq;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, start);
    g.gain.exponentialRampToValueAtTime(0.0001, start + dur);
    s.connect(f);
    f.connect(g);
    g.connect(dest);
    s.start(start, Math.random());
    s.stop(start + dur + 0.05);
  }

  sfx(name: SfxName) {
    if (!this.ctx || !this.sfxGain || !this.sfxOn) return;
    const t = this.ctx.currentTime;
    const d = this.sfxGain;
    switch (name) {
      case "jump":
        this.tone(320, t, 0.18, "square", 0.35, d, 640);
        break;
      case "land":
        this.noiseHit(t, 0.07, 420, 0.28, d);
        break;
      case "spring":
        this.tone(260, t, 0.3, "square", 0.35, d, 980);
        break;
      case "coin":
        this.tone(988, t, 0.08, "square", 0.3, d);
        this.tone(1319, t + 0.07, 0.18, "square", 0.3, d);
        break;
      case "crumble":
        this.tone(140, t, 0.25, "sawtooth", 0.35, d, 50);
        this.noiseHit(t, 0.2, 900, 0.3, d);
        break;
      case "die":
        this.tone(440, t, 0.7, "sawtooth", 0.4, d, 70);
        this.tone(330, t + 0.1, 0.7, "square", 0.25, d, 50);
        break;
      case "click":
        this.tone(520, t, 0.07, "triangle", 0.4, d, 700);
        break;
      case "reward":
        [523, 659, 784, 1047].forEach((f, i) => this.tone(f, t + i * 0.09, 0.2, "square", 0.3, d));
        break;
      case "powerup":
        [660, 880, 1175, 1568].forEach((f, i) => this.tone(f, t + i * 0.06, 0.16, "triangle", 0.4, d));
        this.tone(2093, t + 0.24, 0.3, "sine", 0.2, d);
        break;
      case "warn": {
        // throttled so several hazards never stack into noise
        if (t - this.lastWarn < 0.35) return;
        this.lastWarn = t;
        this.tone(880, t, 0.09, "square", 0.2, d);
        this.tone(880, t + 0.14, 0.09, "square", 0.2, d);
        break;
      }
      case "world":
        [261.6, 329.6, 392, 523.3, 659.3].forEach((f, i) => this.tone(f, t + i * 0.12, 0.5, "triangle", 0.4, d));
        this.tone(130.8, t, 1.0, "sine", 0.5, d);
        break;
      case "buy":
        this.tone(1319, t, 0.08, "square", 0.3, d);
        this.tone(1760, t + 0.08, 0.08, "square", 0.3, d);
        this.tone(2093, t + 0.16, 0.3, "triangle", 0.35, d);
        break;
      case "over":
        [392, 349.2, 311.1, 261.6].forEach((f, i) => this.tone(f, t + i * 0.2, 0.35, "triangle", 0.4, d));
        break;
      case "near":
        this.tone(400, t, 0.14, "triangle", 0.35, d, 1400);
        break;
      case "shield":
        this.tone(900, t, 0.25, "square", 0.3, d, 180);
        this.noiseHit(t, 0.2, 2500, 0.3, d);
        break;
      case "error":
        this.tone(170, t, 0.12, "square", 0.3, d);
        this.tone(140, t + 0.14, 0.18, "square", 0.3, d);
        break;
    }
  }

  // --- music scheduler -------------------------------------------------------------------------
  private syncMusic() {
    if (!this.ctx) return;
    if (this.musicOn && this.timer === null) {
      this.nextTime = this.ctx.currentTime + 0.05;
      this.timer = window.setInterval(() => this.schedule(), 100);
    } else if (!this.musicOn && this.timer !== null) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  private schedule() {
    if (!this.ctx || !this.musicGain) return;
    const th = THEMES[this.world];
    while (this.nextTime < this.ctx.currentTime + 0.3) {
      const s = this.step;
      const bar = Math.floor(s / 8) % 4;
      this.tone(th.arp[s % 8] * th.mult[bar], this.nextTime, th.arpDur, th.arpType, th.arpVol, this.musicGain);
      if (s % 4 === 0) this.tone(th.bass[bar], this.nextTime, 0.6, th.bassType, th.bassVol, this.musicGain);
      this.step = (this.step + 1) % 32;
      this.nextTime += th.step;
    }
  }
}

export const audio = new AudioEngine();
