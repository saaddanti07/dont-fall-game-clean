import { useState } from "react";
import { SKINS, skinById } from "../game/skins";
import type { SaveData } from "../game/storage";
import { CoinCounter } from "./CoinCounter";
import { CheckIcon, CoinIcon, LockIcon } from "./Icons";
import { Modal } from "./Modal";
import { SkinPreview } from "./SkinPreview";

interface Props {
  save: SaveData;
  onBuy: (id: string) => void;
  onEquip: (id: string) => void;
  onClose: () => void;
}

type State = "equipped" | "owned" | "locked";

export function ShopModal({ save, onBuy, onEquip, onClose }: Props) {
  const [sel, setSel] = useState(save.equipped);
  const skin = skinById(sel);
  const stateOf = (id: string): State => (save.equipped === id ? "equipped" : save.owned.includes(id) ? "owned" : "locked");
  const state = stateOf(skin.id);
  const afford = save.coins >= skin.price;

  return (
    <Modal title="Character Shop" onClose={onClose} tall noScroll>
      {/* preview + action */}
      <div className="shrink-0 border-b-2 border-white/10 px-3 pb-3 pt-3">
        <div className="mb-1 flex items-center justify-between gap-2">
          <CoinCounter value={save.coins} />
          <span
            className={`rounded-full border-2 px-3 py-1 text-[0.72rem] font-bold uppercase tracking-[0.14em] ${
              state === "equipped" ? "border-emerald-300 bg-emerald-500/30 text-emerald-100" : state === "owned" ? "border-teal-300 bg-teal-500/25 text-teal-100" : "border-white/25 bg-black/40 text-violet-100"
            }`}
            data-testid="skin-state"
          >
            {state === "equipped" ? "Equipped" : state === "owned" ? "Owned" : "Locked"}
          </span>
        </div>
        <div className="relative mx-auto h-[min(24dvh,170px)] w-full max-w-[200px]">
          <SkinPreview skin={skin} animated scene />
        </div>
        <div className="mt-1 text-center">
          <div className="font-display text-[1.45rem] leading-none tracking-wide text-white text-outline" data-testid="skin-name">
            {skin.name}
          </div>
          <div className="mt-1.5 text-[0.88rem] font-medium text-violet-100">{skin.blurb}</div>
        </div>
        <div className="mt-3">
          {state === "equipped" ? (
            <button className="btn btn-muted w-full gap-2 text-[1.2rem]" style={{ minHeight: 54 }} disabled>
              <CheckIcon /> EQUIPPED
            </button>
          ) : state === "owned" ? (
            <button className="btn btn-play w-full text-[1.4rem]" style={{ minHeight: 56, animation: "none" }} onClick={() => onEquip(skin.id)}>
              SELECT
            </button>
          ) : afford ? (
            <button className="btn btn-gold w-full gap-2 text-[1.3rem]" style={{ minHeight: 56 }} onClick={() => onBuy(skin.id)}>
              BUY <CoinIcon className="h-7 w-7" /> {skin.price.toLocaleString()}
            </button>
          ) : (
            <button className="btn btn-muted w-full flex-col gap-0 text-[1.05rem] leading-tight" style={{ minHeight: 56 }} disabled>
              <span className="flex items-center gap-1.5">
                <LockIcon className="h-4 w-4" /> {skin.price.toLocaleString()} <CoinIcon className="h-5 w-5" />
              </span>
              <span className="font-body text-[0.78rem] font-semibold tracking-normal text-violet-200">Need {(skin.price - save.coins).toLocaleString()} more coins</span>
            </button>
          )}
        </div>
      </div>

      {/* character grid */}
      <div className="scroll-thin min-h-0 flex-1 overflow-y-auto p-3">
        <div className="grid grid-cols-3 gap-2.5">
          {SKINS.map((s) => {
            const st = stateOf(s.id);
            return (
              <button
                key={s.id}
                onClick={() => setSel(s.id)}
                aria-pressed={sel === s.id}
                aria-label={`${s.name}, ${st}`}
                data-skin={s.id}
                className={`relative flex flex-col items-center rounded-2xl border-[3px] px-1 pb-1.5 pt-1 transition-colors ${
                  sel === s.id ? "border-[#ffd62e] bg-[#5a2f9e]" : st === "equipped" ? "border-emerald-400/80 bg-[#1d4a46]" : "border-white/15 bg-black/30"
                }`}
              >
                <div className="relative h-[68px] w-[68px]">
                  <SkinPreview skin={s} />
                  {st === "locked" && (
                    <span className="absolute right-0 top-0 flex h-6 w-6 items-center justify-center rounded-full bg-black/70 text-violet-100">
                      <LockIcon className="h-3.5 w-3.5" />
                    </span>
                  )}
                </div>
                <span className="w-full truncate text-center text-[0.72rem] font-bold leading-tight text-white">{s.name}</span>
                <span className="mt-0.5 flex items-center gap-1 text-[0.68rem] font-bold uppercase leading-none tracking-wide">
                  {st === "equipped" ? (
                    <span className="text-emerald-200">Equipped</span>
                  ) : st === "owned" ? (
                    <span className="text-teal-200">Owned</span>
                  ) : (
                    <span className="flex items-center gap-1 text-[#ffd62e]">
                      <CoinIcon className="h-3.5 w-3.5" />
                      {s.price.toLocaleString()}
                    </span>
                  )}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </Modal>
  );
}
