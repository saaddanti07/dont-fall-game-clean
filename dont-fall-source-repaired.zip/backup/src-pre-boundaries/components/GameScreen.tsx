import { useCallback, useEffect, useRef, useState } from "react";
import { Game, type GameOptions, type HudState, type WorldEvent } from "../game/engine";
import { audio } from "../game/audio";
import type { RunStats } from "../game/progression";
import type { Skin } from "../game/skins";
import { CoinCounter } from "./CoinCounter";
import { HomeIcon, PauseIcon, PlayIcon } from "./Icons";
import { PowerChips } from "./PowerChips";
import { StackedTitle } from "./StackedTitle";
import { WorldBanner } from "./WorldBanner";

interface Props {
  skin: Skin;
  debug?: GameOptions | null;
  onCoin: (amount: number) => void;
  onGameOver: (r: RunStats) => void;
  onExit: (r: RunStats) => void;
}

const EMPTY_HUD: HudState = { score: 0, distance: 0, bonus: 0, coins: 0, powers: [] };

export function GameScreen({ skin, debug, onCoin, onGameOver, onExit }: Props) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const cbs = useRef({ onCoin, onGameOver });
  cbs.current = { onCoin, onGameOver };

  const [hud, setHud] = useState<HudState>(EMPTY_HUD);
  const [world, setWorld] = useState<WorldEvent | null>(null);
  const [worldName, setWorldName] = useState("CAVE");
  const [paused, setPaused] = useState(false);
  const pausedRef = useRef(false);

  const setPause = useCallback((p: boolean) => {
    pausedRef.current = p;
    setPaused(p);
    gameRef.current?.setPaused(p);
    if (p) gameRef.current?.setInput(0);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current!;
    const wrap = wrapRef.current!;
    const game = new Game(
      canvas,
      skin,
      {
        onHud: setHud,
        onCoin: (n) => cbs.current.onCoin(n),
        onWorld: (w) => {
          setWorld(w);
          setWorldName(w.name);
        },
        onGameOver: (r) => cbs.current.onGameOver(r),
      },
      debug ?? {},
    );
    gameRef.current = game;
    if (debug) (window as unknown as { __game?: Game }).__game = game;

    const fit = () => {
      const r = wrap.getBoundingClientRect();
      game.resize(r.width, r.height, Math.min(window.devicePixelRatio || 1, 2.5));
    };
    fit();
    const ro = new ResizeObserver(fit);
    ro.observe(wrap);
    game.start();

    // keyboard controls
    const keys = new Set<string>();
    const sync = () => {
      const left = keys.has("ArrowLeft") || keys.has("a") || keys.has("A");
      const right = keys.has("ArrowRight") || keys.has("d") || keys.has("D");
      game.setInput(left === right ? 0 : left ? -1 : 1);
    };
    const down = (e: KeyboardEvent) => {
      if (e.key === "Escape" || e.key === "p") setPause(!pausedRef.current);
      keys.add(e.key);
      sync();
    };
    const up = (e: KeyboardEvent) => {
      keys.delete(e.key);
      sync();
    };
    // pause automatically whenever the page is hidden or loses focus
    const vis = () => {
      if (document.hidden) setPause(true);
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    document.addEventListener("visibilitychange", vis);
    window.addEventListener("blur", vis);

    return () => {
      game.destroy();
      ro.disconnect();
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
      document.removeEventListener("visibilitychange", vis);
      window.removeEventListener("blur", vis);
      gameRef.current = null;
    };
    // the engine is created once per run
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [setPause]);

  // touch / mouse: hold left or right half of the screen
  const steer = (e: React.PointerEvent) => {
    if (pausedRef.current) return;
    const r = wrapRef.current!.getBoundingClientRect();
    gameRef.current?.setInput(e.clientX < r.left + r.width / 2 ? -1 : 1);
  };

  return (
    <div className="relative h-full w-full">
      <div
        ref={wrapRef}
        className="absolute inset-0 touch-none"
        onPointerDown={(e) => {
          audio.unlock();
          (e.target as Element).setPointerCapture?.(e.pointerId);
          steer(e);
        }}
        onPointerMove={(e) => (e.buttons > 0 || e.pointerType === "touch" ? steer(e) : undefined)}
        onPointerUp={() => gameRef.current?.setInput(0)}
        onPointerCancel={() => gameRef.current?.setInput(0)}
        onContextMenu={(e) => e.preventDefault()}
      >
        <canvas ref={canvasRef} className="block h-full w-full" />
      </div>

      {/* HUD — dark translucent panels, kept to the top of the screen */}
      <div
        className="pointer-events-none absolute inset-x-0 top-0 z-10 px-3"
        style={{ paddingTop: "max(12px, calc(env(safe-area-inset-top) + 6px))" }}
      >
        <div className="flex items-start justify-between gap-2">
          <div className="panel flex min-w-[104px] flex-col items-start gap-1 rounded-2xl px-3.5 py-2" role="status" aria-label={`Score ${hud.score}, distance ${hud.distance} meters`}>
            <span className="panel-label">Score</span>
            <span className="value-text text-[1.7rem] leading-none tabular-nums" data-testid="hud-score">{hud.score.toLocaleString()}</span>
            <span className="text-[0.78rem] font-bold leading-none tracking-wide text-violet-100" data-testid="hud-distance">
              {hud.distance.toLocaleString()} m · {worldName}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <CoinCounter value={hud.coins} prefix="+" label="Coins this run" />
            <button className="icon-btn neutral pointer-events-auto" onClick={() => setPause(true)} aria-label="Pause game">
              <PauseIcon />
            </button>
          </div>
        </div>
        <PowerChips powers={hud.powers} />
      </div>

      {world && !paused && <WorldBanner world={world} />}

      {/* control hint */}
      {!paused && hud.distance < 5 && !debug && (
        <div className="pointer-events-none absolute inset-x-0 z-10 flex justify-center px-6" style={{ top: "30%", animation: "hintFade 5s ease forwards" }}>
          <div className="panel px-4 py-2.5 text-center text-[0.95rem] font-semibold leading-snug text-white">
            Hold the <b className="text-[#ffd62e]">left</b> or <b className="text-[#ffd62e]">right</b> side of the screen to move
          </div>
        </div>
      )}

      {paused && (
        <div className="fade-in absolute inset-0 z-20 flex flex-col items-center justify-center gap-6 px-8" style={{ background: "rgba(10,3,22,0.82)" }} role="dialog" aria-label="Paused">
          <StackedTitle lines={["PAUSED"]} />
          <div className="pop-in flex w-full max-w-[300px] flex-col gap-3.5">
            <button
              className="btn btn-play min-h-[68px] gap-2 text-[1.7rem]"
              onClick={() => {
                audio.sfx("click");
                setPause(false);
              }}
            >
              <PlayIcon className="h-7 w-7" /> RESUME
            </button>
            <button
              className="btn btn-purple min-h-[56px] gap-2 text-[1.2rem]"
              onClick={() => {
                audio.sfx("click");
                onExit(gameRef.current!.getRunStats());
              }}
            >
              <HomeIcon className="h-6 w-6" /> MAIN MENU
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
