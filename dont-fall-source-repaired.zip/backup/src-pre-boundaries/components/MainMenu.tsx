import type { Skin } from "../game/skins";
import { AudioToggles } from "./AudioToggles";
import { CaveBackground } from "./CaveBackground";
import { CoinCounter } from "./CoinCounter";
import { CoinIcon, FlameIcon, MissionsIcon, ShopIcon, SlidersIcon, TrophyIcon } from "./Icons";
import { MenuCharacter } from "./MenuCharacter";
import { StackedTitle } from "./StackedTitle";

interface Props {
  coins: number;
  best: number;
  streak: number;
  world: number; // highest world reached, 1-based
  skin: Skin;
  musicOn: boolean;
  sfxOn: boolean;
  dailyReady: boolean;
  onPlay: () => void;
  onDaily: () => void;
  onShop: () => void;
  onMissions: () => void;
  onSettings: () => void;
  onToggleMusic: () => void;
  onToggleSfx: () => void;
}

const tile = "btn flex-col gap-1 px-0.5 font-body text-[0.74rem] font-bold uppercase leading-none tracking-wide";

export function MainMenu(p: Props) {
  return (
    <div className="relative h-full w-full">
      <CaveBackground />

      <div
        className="relative z-10 flex h-full flex-col px-4"
        style={{
          paddingTop: "max(24px, calc(env(safe-area-inset-top) + 10px))",
          paddingBottom: "calc(26px + env(safe-area-inset-bottom) + 8px)",
        }}
      >
        {/* TOP: title + coins + audio */}
        <header className="flex shrink-0 flex-col items-center gap-[min(1.6dvh,12px)]">
          <StackedTitle lines={["DON'T", "FALL!"]} label="DON'T FALL!" />
          <div className="flex w-full items-center justify-between">
            <CoinCounter value={p.coins} />
            <AudioToggles musicOn={p.musicOn} sfxOn={p.sfxOn} onMusic={p.onToggleMusic} onSfx={p.onToggleSfx} />
          </div>
        </header>

        {/* CENTER: hero, subtitle, stats */}
        <main className="flex min-h-0 flex-1 flex-col items-center justify-center gap-[min(1.2dvh,8px)] py-1">
          <div className="relative min-h-[60px] w-full max-w-[300px] flex-1">
            <MenuCharacter skin={p.skin} />
          </div>
          <p className="text-outline shrink-0 text-center text-[clamp(0.9rem,4vw,1.12rem)] font-semibold leading-tight text-white">Climb. Bounce. Outrun the lava!</p>
          <div className="panel grid w-full max-w-[340px] shrink-0 grid-cols-3 divide-x-2 divide-white/10 py-1.5">
            <div className="flex flex-col items-center gap-1 px-1">
              <span className="panel-label flex items-center gap-1">
                <TrophyIcon className="h-4 w-4" /> Best
              </span>
              <span className="value-text text-[1.3rem] leading-none tabular-nums">
                {p.best.toLocaleString()}
                <span className="ml-0.5 font-body text-[0.7rem] font-semibold tracking-normal text-violet-100">m</span>
              </span>
            </div>
            <div className="flex flex-col items-center gap-1 px-1">
              <span className="panel-label flex items-center gap-1">
                <FlameIcon className="h-4 w-4" /> Streak
              </span>
              <span className="value-text text-[1.3rem] leading-none tabular-nums">
                {p.streak}
                <span className="ml-0.5 font-body text-[0.7rem] font-semibold tracking-normal text-violet-100">{p.streak === 1 ? "day" : "days"}</span>
              </span>
            </div>
            <div className="flex flex-col items-center gap-1 px-1">
              <span className="panel-label">World</span>
              <span className="value-text text-[1.3rem] leading-none tabular-nums">
                {p.world}
                <span className="ml-0.5 font-body text-[0.7rem] font-semibold tracking-normal text-violet-100">/ 6</span>
              </span>
            </div>
          </div>
        </main>

        {/* LOWER CENTER: play */}
        <div className="shrink-0 px-2 pb-[min(2dvh,14px)] pt-1">
          <button className="btn btn-play w-full text-[clamp(2rem,10vw,2.8rem)] leading-none" style={{ minHeight: "clamp(60px,9.5dvh,84px)" }} onClick={p.onPlay}>
            PLAY
          </button>
        </div>

        {/* BOTTOM: daily reward, shop, missions, settings */}
        <footer className="panel grid shrink-0 grid-cols-4 gap-2 rounded-3xl p-2">
          <button className={`${tile} btn-gold`} style={{ minHeight: 64 }} onClick={p.onDaily} aria-label="Daily reward">
            <CoinIcon className="h-7 w-7" />
            <span>Daily</span>
            {p.dailyReady && (
              <span
                className="absolute -right-1.5 -top-2 flex h-6 w-6 items-center justify-center rounded-full border-2 border-white bg-red-500 text-sm font-bold text-white"
                style={{ animation: "badgePulse 1.2s ease-in-out infinite" }}
                aria-hidden="true"
              >
                !
              </span>
            )}
          </button>
          <button className={`${tile} btn-purple`} style={{ minHeight: 64 }} onClick={p.onShop} aria-label="Character shop">
            <ShopIcon className="h-7 w-7" />
            <span>Shop</span>
          </button>
          <button className={`${tile} btn-blue`} style={{ minHeight: 64 }} onClick={p.onMissions} aria-label="Missions">
            <MissionsIcon className="h-7 w-7" />
            <span>Missions</span>
          </button>
          <button className={`${tile} btn-dark`} style={{ minHeight: 64 }} onClick={p.onSettings} aria-label="Settings">
            <SlidersIcon className="h-7 w-7" />
            <span>Settings</span>
          </button>
        </footer>
      </div>
    </div>
  );
}
