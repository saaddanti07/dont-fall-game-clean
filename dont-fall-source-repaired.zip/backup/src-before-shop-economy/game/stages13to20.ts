// Stages 13–20: definitions, backgrounds, platform behaviour/art, hazards and ambient effects.
// Kept separate from the original twelve worlds so their rendering and mechanics remain untouched.

import type { WorldDef } from "./worlds";
import type { PlatformKind } from "./sprites";
import type { HazKind } from "./hazards";

type Ctx = CanvasRenderingContext2D;
const OUT = "#1b1028";

export const EXPANSION_FIRST = 12; // zero-based world index = stage 13
export const DRAGON_WORLD = 19; // zero-based world index = stage 20

export const EXTRA_WORLDS: WorldDef[] = [
  { id: "factory", name: "MECHANICAL FACTORY", subtitle: "Ride the pistons. Mind the presses!", accent: "#f2b84b", ambient: 20 },
  { id: "mushroom", name: "MUSHROOM KINGDOM", subtitle: "Time the caps for gigantic bounces!", accent: "#ff8fb3", ambient: 26 },
  { id: "pirate", name: "PIRATE SHIP", subtitle: "Ride the waves. Dodge the cannons!", accent: "#6fd6e8", ambient: 30 },
  { id: "clockwork", name: "CLOCKWORK TOWER", subtitle: "Jump on the tick — not the tock!", accent: "#ffd166", ambient: 18 },
  { id: "toy", name: "TOY DIMENSION", subtitle: "Blocks tumble. Trains don't stop!", accent: "#ff7f7f", ambient: 24 },
  { id: "musical", name: "MUSICAL DIMENSION", subtitle: "Bounce on the beat. Dodge the waves!", accent: "#c59aff", ambient: 24 },
  { id: "library", name: "INFINITE LIBRARY", subtitle: "Ride the flying books. Watch the shelves!", accent: "#8fd3b6", ambient: 22 },
  { id: "dragon", name: "DRAGON'S LAIR", subtitle: "Stomp the Dragon. Claim the final crown!", accent: "#ff7043", ambient: 26 },
];

export const EXPANSION_KINDS = new Set<PlatformKind>(["piston", "mushroom", "ship", "clock", "toyblock", "note", "book", "obsidian"]);
export const EXPANSION_HAZARDS = new Set<HazKind>(["cog", "sporeseed", "cannonball", "toyball", "train", "soundwave", "bookdrop", "dragonfire", "shockwave"]);

export interface ExpPlatform {
  x: number;
  y: number;
  y0: number;
  baseX: number;
  w: number;
  kind: PlatformKind;
  phase: number;
  speed: number;
}

export interface ExpPlatformState {
  x: number;
  y: number;
  alpha: number;
  solid: boolean;
  bounce: number;
}

/** Signature movement/bounce rules. Only called for stages 13–20. */
export function expansionPlatform(p: ExpPlatform, time: number): ExpPlatformState {
  const wave = Math.sin(time * 2 + p.phase);
  switch (p.kind) {
    case "piston": {
      // hydraulic lift: smooth vertical travel, never changes jump gravity
      const travel = Math.sin(time * 1.55 + p.phase) * 27;
      return { x: p.baseX, y: p.y0 + travel, alpha: 1, solid: true, bounce: 1 };
    }
    case "mushroom": {
      const charge = 0.5 + 0.5 * Math.sin(time * 3.1 + p.phase);
      return { x: p.baseX, y: p.y0 + wave * 2.5, alpha: 1, solid: true, bounce: 1.12 + charge * 0.3 };
    }
    case "ship":
      return { x: p.baseX + Math.sin(time * 0.65 + p.phase) * 30, y: p.y0 + Math.sin(time * 1.8 + p.phase) * 9, alpha: 1, solid: true, bounce: 1 };
    case "clock": {
      // globally legible timing: 1.8 s solid, 1.0 s phased out
      const c = (time + p.phase) % 2.8;
      const solid = c < 1.8;
      const alpha = solid ? (c > 1.45 ? 0.45 + 0.55 * Math.abs(Math.sin(time * 18)) : 1) : 0.2;
      return { x: p.baseX, y: p.y0, alpha, solid, bounce: 1 };
    }
    case "toyblock":
      return { x: p.baseX, y: p.y0, alpha: 1, solid: true, bounce: 1.04 };
    case "note": {
      const beat = Math.pow(0.5 + 0.5 * Math.sin(time * Math.PI * 4 + p.phase), 5);
      return { x: p.baseX, y: p.y0 - beat * 9, alpha: 1, solid: true, bounce: 1.06 + beat * 0.38 };
    }
    case "book":
      return { x: p.baseX + Math.sin(time * 0.85 + p.phase) * 30, y: p.y0 + Math.cos(time * 1.15 + p.phase) * 13, alpha: 1, solid: true, bounce: 1.02 };
    default:
      return { x: p.baseX, y: p.y0, alpha: 1, solid: true, bounce: 1 };
  }
}

// -------------------------------------------------------------------------------------------------
// Backgrounds
// -------------------------------------------------------------------------------------------------
function grad(ctx: Ctx, H: number, stops: [number, string][]) {
  const g = ctx.createLinearGradient(0, 0, 0, H);
  stops.forEach(([o, c]) => g.addColorStop(o, c));
  return g;
}
function tile(off: number, step: number, H: number, fn: (i: number, y: number) => void) {
  for (let i = Math.floor(off / step) - 1; i <= Math.ceil((off + H) / step) + 1; i++) fn(i, i * step - off);
}
function gear(ctx: Ctx, x: number, y: number, r: number, rot: number, color: string) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.fillStyle = color;
  ctx.strokeStyle = OUT;
  ctx.lineWidth = Math.max(2, r * 0.08);
  ctx.beginPath();
  for (let i = 0; i < 24; i++) {
    const a = (i / 24) * Math.PI * 2;
    const rr = i % 2 ? r * 0.82 : r;
    const px = Math.cos(a) * rr;
    const py = Math.sin(a) * rr;
    if (!i) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = "#1a1424";
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.28, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}
function mushroom(ctx: Ctx, x: number, y: number, s: number, cap: string, t: number) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s);
  ctx.fillStyle = "#e8d9b8";
  ctx.strokeStyle = OUT;
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(-8, 0);
  ctx.quadraticCurveTo(-6, -38, -4, -48);
  ctx.lineTo(5, -48);
  ctx.quadraticCurveTo(7, -25, 9, 0);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = cap;
  ctx.beginPath();
  ctx.moveTo(-30, -43);
  ctx.quadraticCurveTo(-26, -78 - Math.sin(t) * 3, 0, -80);
  ctx.quadraticCurveTo(27, -78, 31, -43);
  ctx.quadraticCurveTo(0, -31, -30, -43);
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = "rgba(255,255,255,0.75)";
  for (const [dx, dy, r] of [[-13, -58, 5], [8, -67, 6], [17, -50, 4]]) {
    ctx.beginPath();
    ctx.arc(dx, dy, r, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}
function bookShape(ctx: Ctx, x: number, y: number, w: number, color: string, open = true) {
  ctx.save();
  ctx.translate(x, y);
  ctx.fillStyle = color;
  ctx.strokeStyle = OUT;
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.moveTo(-w / 2, 0);
  ctx.lineTo(0, open ? 4 : 0);
  ctx.lineTo(w / 2, 0);
  ctx.lineTo(w / 2, 13);
  ctx.lineTo(0, 17);
  ctx.lineTo(-w / 2, 13);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = "#f5e7bf";
  ctx.beginPath();
  ctx.moveTo(-w / 2 + 3, 0);
  ctx.lineTo(0, 4);
  ctx.lineTo(w / 2 - 3, 0);
  ctx.lineTo(w / 2 - 3, 7);
  ctx.lineTo(0, 11);
  ctx.lineTo(-w / 2 + 3, 7);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

export function drawExpansionBackground(ctx: Ctx, index: number, W: number, H: number, cam: number, t: number) {
  switch (index) {
    case 12: { // Mechanical Factory
      ctx.fillStyle = grad(ctx, H, [[0, "#111827"], [0.55, "#273449"], [1, "#4c4a43"]]);
      ctx.fillRect(0, 0, W, H);
      // pipes + moving belt silhouettes
      ctx.strokeStyle = "#64748b";
      ctx.lineWidth = 10;
      for (const x of [38, W - 42]) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, H);
        ctx.stroke();
      }
      tile(cam * 0.25, 150, H, (i, y) => {
        gear(ctx, 68 + (i % 3) * 104, y + 55, 34 + (i % 2) * 12, t * (i % 2 ? -0.5 : 0.65), "#6b7280");
        gear(ctx, 120 + (i % 2) * 120, y + 118, 22, -t * 0.8, "#a97c3f");
      });
      ctx.fillStyle = "rgba(255,190,70,0.1)";
      for (let x = 0; x < W; x += 36) ctx.fillRect(x + ((t * 30) % 36), H - 34, 20, 5);
      break;
    }
    case 13: { // Mushroom Kingdom
      ctx.fillStyle = grad(ctx, H, [[0, "#24134b"], [0.5, "#5b3180"], [1, "#3f8b70"]]);
      ctx.fillRect(0, 0, W, H);
      tile(cam * 0.25, 190, H, (i, y) => {
        mushroom(ctx, 45 + (i % 3) * 130, y + 150, 1.1 + (i % 2) * 0.4, i % 2 ? "#f472b6" : "#8b5cf6", t + i);
      });
      ctx.fillStyle = "rgba(190,255,210,0.1)";
      ctx.fillRect(0, H - 55, W, 55);
      break;
    }
    case 14: { // Pirate Ship
      ctx.fillStyle = grad(ctx, H, [[0, "#101b3c"], [0.52, "#31547a"], [1, "#15738a"]]);
      ctx.fillRect(0, 0, W, H);
      // storm clouds and rolling ocean layers
      ctx.fillStyle = "rgba(12,20,44,0.65)";
      for (let x = -30; x < W + 60; x += 80) {
        ctx.beginPath();
        ctx.arc(x + Math.sin(t * 0.2 + x) * 8, 60, 48, 0, Math.PI * 2);
        ctx.fill();
      }
      for (let layer = 0; layer < 3; layer++) {
        ctx.strokeStyle = `rgba(160,235,245,${0.16 + layer * 0.08})`;
        ctx.lineWidth = 3;
        ctx.beginPath();
        for (let x = 0; x <= W; x += 8) {
          const y = H * 0.68 + layer * 48 + Math.sin(x * 0.045 + t * (1.2 + layer * 0.3)) * 10;
          if (!x) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();
      }
      // distant ship mast and rigging
      ctx.strokeStyle = "rgba(35,20,18,0.65)";
      ctx.lineWidth = 7;
      ctx.beginPath();
      ctx.moveTo(58, H);
      ctx.lineTo(58, 130);
      ctx.moveTo(24, 190);
      ctx.lineTo(132, 190);
      ctx.moveTo(58, 130);
      ctx.lineTo(140, 350);
      ctx.stroke();
      break;
    }
    case 15: { // Clockwork Tower
      ctx.fillStyle = grad(ctx, H, [[0, "#1c1724"], [0.5, "#493c3c"], [1, "#81643d"]]);
      ctx.fillRect(0, 0, W, H);
      tile(cam * 0.2, 240, H, (i, y) => {
        const x = 65 + (i % 2) * 190;
        ctx.fillStyle = "#dbc07a";
        ctx.strokeStyle = OUT;
        ctx.lineWidth = 5;
        ctx.beginPath();
        ctx.arc(x, y + 100, 62, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = "#292132";
        ctx.beginPath();
        ctx.arc(x, y + 100, 52, 0, Math.PI * 2);
        ctx.fill();
        for (let n = 0; n < 12; n++) {
          const a = (n / 12) * Math.PI * 2;
          ctx.fillStyle = "#f4d98b";
          ctx.fillRect(x + Math.cos(a) * 43 - 1.5, y + 100 + Math.sin(a) * 43 - 1.5, 3, 3);
        }
        ctx.strokeStyle = "#ffdc7a";
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(x, y + 100);
        ctx.lineTo(x + Math.cos(t * 0.5) * 35, y + 100 + Math.sin(t * 0.5) * 35);
        ctx.moveTo(x, y + 100);
        ctx.lineTo(x + Math.cos(t * 0.12) * 25, y + 100 + Math.sin(t * 0.12) * 25);
        ctx.stroke();
      });
      gear(ctx, 20, H - 90, 45, t * 0.35, "#6c5b50");
      gear(ctx, W - 18, H - 155, 54, -t * 0.25, "#766247");
      break;
    }
    case 16: { // Toy Dimension
      ctx.fillStyle = grad(ctx, H, [[0, "#76c8ff"], [0.55, "#c5a7ff"], [1, "#ffb6cf"]]);
      ctx.fillRect(0, 0, W, H);
      tile(cam * 0.25, 160, H, (i, y) => {
        const colors = ["#ff6b6b", "#ffd93d", "#6bcB77", "#4d96ff"];
        for (let k = 0; k < 3; k++) {
          const x = 28 + ((i * 71 + k * 113) % 300);
          const s = 34 + ((i + k) % 2) * 16;
          ctx.fillStyle = colors[(i + k) % 4];
          ctx.strokeStyle = OUT;
          ctx.lineWidth = 3;
          ctx.fillRect(x, y + 30 + k * 28, s, s);
          ctx.strokeRect(x, y + 30 + k * 28, s, s);
          ctx.fillStyle = "rgba(255,255,255,0.7)";
          ctx.beginPath();
          ctx.arc(x + s / 2, y + 30 + k * 28 + s / 2, s * 0.18, 0, Math.PI * 2);
          ctx.fill();
        }
      });
      break;
    }
    case 17: { // Musical Dimension
      ctx.fillStyle = grad(ctx, H, [[0, "#170c3d"], [0.5, "#4b1a78"], [1, "#9b3c91"]]);
      ctx.fillRect(0, 0, W, H);
      // giant brass instruments + equaliser
      ctx.strokeStyle = "rgba(255,211,93,0.35)";
      ctx.lineWidth = 13;
      ctx.beginPath();
      ctx.arc(62, 145, 52, 0.2, Math.PI * 1.7);
      ctx.lineTo(92, 260);
      ctx.stroke();
      ctx.fillStyle = "rgba(255,211,93,0.32)";
      ctx.beginPath();
      ctx.moveTo(68, 240);
      ctx.lineTo(132, 278);
      ctx.lineTo(50, 295);
      ctx.closePath();
      ctx.fill();
      for (let x = 0; x < W; x += 22) {
        const h = 25 + Math.abs(Math.sin(t * 4 + x * 0.09)) * 80;
        ctx.fillStyle = x % 44 ? "rgba(120,240,255,0.14)" : "rgba(255,120,220,0.16)";
        ctx.fillRect(x, H - h, 13, h);
      }
      break;
    }
    case 18: { // Infinite Library
      ctx.fillStyle = grad(ctx, H, [[0, "#101a2c"], [0.5, "#183c45"], [1, "#4b405b"]]);
      ctx.fillRect(0, 0, W, H);
      // endless shelves
      for (const side of [0, 1]) {
        const x = side ? W - 70 : 0;
        ctx.fillStyle = "#271c24";
        ctx.fillRect(x, 0, 70, H);
        tile(cam * 0.4, 74, H, (i, y) => {
          ctx.fillStyle = "#6b452d";
          ctx.fillRect(x, y + 62, 70, 7);
          for (let b = 0; b < 5; b++) {
            ctx.fillStyle = ["#8b5cf6", "#2e8b78", "#a95858", "#c19452"][((i + b) % 4 + 4) % 4];
            ctx.fillRect(x + 5 + b * 12, y + 18 + (b % 2) * 5, 9, 43 - (b % 2) * 5);
          }
        });
      }
      tile(cam * 0.18, 230, H, (i, y) => bookShape(ctx, 130 + (i % 2) * 110, y + 100, 62, "#7c4f85"));
      break;
    }
    default: { // Dragon's Lair
      ctx.fillStyle = grad(ctx, H, [[0, "#09070e"], [0.48, "#241127"], [1, "#6d1b17"]]);
      ctx.fillRect(0, 0, W, H);
      // ancient arches, dramatic lava light
      for (const x of [30, W - 90]) {
        ctx.fillStyle = "#17121e";
        ctx.fillRect(x, 0, 60, H);
        ctx.fillStyle = "#2c2030";
        for (let y = -20; y < H; y += 44) ctx.fillRect(x + 3, y + ((cam * 0.4) % 44), 54, 4);
      }
      tile(cam * 0.22, 210, H, (i, y) => {
        const x = 112 + (i % 2) * 112;
        const glow = ctx.createRadialGradient(x, y + 70, 2, x, y + 70, 58);
        glow.addColorStop(0, `rgba(255,110,45,${0.28 + 0.08 * Math.sin(t * 5 + i)})`);
        glow.addColorStop(1, "rgba(255,70,20,0)");
        ctx.fillStyle = glow;
        ctx.fillRect(x - 60, y + 10, 120, 120);
        ctx.fillStyle = "#08060c";
        ctx.beginPath();
        ctx.moveTo(x - 25, y + 115);
        ctx.lineTo(x - 25, y + 55);
        ctx.arc(x, y + 55, 25, Math.PI, 0);
        ctx.lineTo(x + 25, y + 115);
        ctx.closePath();
        ctx.fill();
      });
      break;
    }
  }
}

// -------------------------------------------------------------------------------------------------
// Platforms + hazards
// -------------------------------------------------------------------------------------------------
function base(ctx: Ctx, x: number, y: number, w: number, h: number, fill: string) {
  ctx.fillStyle = fill;
  ctx.strokeStyle = OUT;
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, 5);
  ctx.fill();
  ctx.stroke();
}

export function drawExpansionPlatform(ctx: Ctx, p: ExpPlatform, x: number, y: number, t: number, alpha = 1, fade = 0) {
  const w = p.w;
  ctx.save();
  ctx.globalAlpha = alpha * Math.max(0, 1 - fade * 0.85);
  if (fade) ctx.translate(0, fade * fade * 18);
  switch (p.kind) {
    case "piston":
      ctx.fillStyle = "#5d6672";
      ctx.strokeStyle = OUT;
      ctx.lineWidth = 3;
      ctx.fillRect(x + w / 2 - 8, y + 12, 16, 34);
      ctx.strokeRect(x + w / 2 - 8, y + 12, 16, 34);
      base(ctx, x, y, w, 14, "#8b98a8");
      ctx.fillStyle = "#f2b84b";
      ctx.fillRect(x + 4, y + 2, w - 8, 4);
      for (const rx of [x + 10, x + w - 10]) {
        ctx.beginPath();
        ctx.arc(rx, y + 9, 2.4, 0, Math.PI * 2);
        ctx.fill();
      }
      break;
    case "mushroom": {
      const pulse = 1 + Math.sin(t * 3.1 + p.phase) * 0.05;
      ctx.save();
      ctx.translate(x + w / 2, y + 6);
      ctx.scale(pulse, 1 / pulse);
      ctx.translate(-(x + w / 2), -(y + 6));
      ctx.fillStyle = "#eadbbd";
      ctx.strokeStyle = OUT;
      ctx.lineWidth = 2.5;
      ctx.fillRect(x + w / 2 - 7, y + 3, 14, 24);
      ctx.strokeRect(x + w / 2 - 7, y + 3, 14, 24);
      ctx.fillStyle = "#f472b6";
      ctx.beginPath();
      ctx.moveTo(x - 2, y + 5);
      ctx.quadraticCurveTo(x + w * 0.12, y - 16, x + w / 2, y - 15);
      ctx.quadraticCurveTo(x + w * 0.9, y - 16, x + w + 2, y + 5);
      ctx.quadraticCurveTo(x + w / 2, y + 13, x - 2, y + 5);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#fff1f7";
      for (const dx of [0.25, 0.53, 0.75]) {
        ctx.beginPath();
        ctx.arc(x + w * dx, y - 5 - (dx === 0.53 ? 4 : 0), 3.5, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
      break;
    }
    case "ship":
      ctx.fillStyle = "#7c4a27";
      ctx.strokeStyle = OUT;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x + w, y);
      ctx.lineTo(x + w - 13, y + 23);
      ctx.quadraticCurveTo(x + w / 2, y + 34, x + 13, y + 23);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#c28a4a";
      ctx.fillRect(x + 3, y, w - 6, 6);
      ctx.strokeStyle = "#d9c49a";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(x + w / 2, y);
      ctx.lineTo(x + w / 2, y - 65);
      ctx.moveTo(x + w / 2, y - 62);
      ctx.lineTo(x + w * 0.12, y);
      ctx.moveTo(x + w / 2, y - 62);
      ctx.lineTo(x + w * 0.88, y);
      ctx.stroke();
      break;
    case "clock":
      base(ctx, x, y, w, 14, "#b08a4a");
      ctx.fillStyle = "#f5dc94";
      for (let i = 0; i < 5; i++) {
        ctx.beginPath();
        ctx.arc(x + 10 + i * ((w - 20) / 4), y + 7, 3.2, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.strokeStyle = "#3a2b28";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(x + w / 2, y + 7);
      ctx.lineTo(x + w / 2 + Math.cos(t * 2) * 9, y + 7 + Math.sin(t * 2) * 4);
      ctx.stroke();
      break;
    case "toyblock": {
      const colors = ["#ff6b6b", "#ffd93d", "#6bcb77", "#4d96ff"];
      const n = Math.max(2, Math.round(w / 28));
      for (let i = 0; i < n; i++) {
        const bw = w / n;
        base(ctx, x + i * bw, y, bw + 0.5, 18, colors[i % 4]);
        ctx.fillStyle = "rgba(255,255,255,0.8)";
        ctx.beginPath();
        ctx.arc(x + i * bw + bw / 2, y + 8, 3.5, 0, Math.PI * 2);
        ctx.fill();
      }
      break;
    }
    case "note":
      base(ctx, x, y, w, 14, "#7950bb");
      ctx.fillStyle = "#c8f6ff";
      ctx.font = "bold 18px sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText("♪", x + w / 2, y + 6);
      ctx.fillStyle = `rgba(255,220,110,${0.25 + 0.45 * Math.abs(Math.sin(t * Math.PI * 4 + p.phase))})`;
      ctx.fillRect(x + 3, y + 1, w - 6, 3);
      break;
    case "book":
      bookShape(ctx, x + w / 2, y - 2, w, "#8b5a87");
      ctx.fillStyle = "#d8b55a";
      ctx.fillRect(x + w / 2 - 1.5, y + 7, 3, 14);
      break;
    default:
      base(ctx, x, y, w, 14, "#352b3e");
      ctx.strokeStyle = "#ff7043";
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.moveTo(x + w * 0.25, y + 3);
      ctx.lineTo(x + w * 0.36, y + 10);
      ctx.lineTo(x + w * 0.48, y + 5);
      ctx.moveTo(x + w * 0.68, y + 2);
      ctx.lineTo(x + w * 0.75, y + 11);
      ctx.stroke();
      break;
  }
  ctx.restore();
}

export function drawExpansionHazard(ctx: Ctx, kind: HazKind, x: number, y: number, t: number, dir: number, vx = 0, vy = 0) {
  ctx.save();
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  switch (kind) {
    case "cog":
      gear(ctx, x, y - 13, 15, t * 4, "#a7afb8");
      break;
    case "sporeseed": {
      ctx.translate(x, y - 12);
      const g = ctx.createRadialGradient(0, 0, 1, 0, 0, 18);
      g.addColorStop(0, "rgba(255,245,180,0.95)");
      g.addColorStop(1, "rgba(255,140,200,0)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(0, 0, 18, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#f9a8d4";
      ctx.strokeStyle = OUT;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.ellipse(0, 0, 8, 11, Math.sin(t * 5) * 0.4, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      break;
    }
    case "cannonball":
      ctx.translate(x, y - 12);
      ctx.fillStyle = "rgba(40,40,45,0.35)";
      for (let i = 1; i <= 3; i++) {
        ctx.beginPath();
        ctx.arc(-dir * i * 12, 0, 8 - i, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.fillStyle = "#2d3340";
      ctx.strokeStyle = "#0a0d14";
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(0, 0, 11, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "rgba(255,255,255,0.3)";
      ctx.beginPath();
      ctx.arc(-3, -4, 3, 0, Math.PI * 2);
      ctx.fill();
      break;
    case "toyball": {
      ctx.translate(x, y - 12);
      ctx.rotate(t * 5);
      for (let i = 0; i < 4; i++) {
        ctx.fillStyle = ["#ff6b6b", "#ffd93d", "#6bcb77", "#4d96ff"][i];
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.arc(0, 0, 12, (i * Math.PI) / 2, ((i + 1) * Math.PI) / 2);
        ctx.fill();
      }
      ctx.strokeStyle = OUT;
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(0, 0, 12, 0, Math.PI * 2);
      ctx.stroke();
      break;
    }
    case "train": {
      ctx.translate(x, y - 15);
      ctx.scale(dir, 1);
      for (const off of [-24, 0, 24]) {
        base(ctx, off - 13, -10, 26, 19, off === 24 ? "#ef5350" : "#4d96ff");
        ctx.fillStyle = "#1b2430";
        ctx.beginPath();
        ctx.arc(off - 7, 11, 4, 0, Math.PI * 2);
        ctx.arc(off + 7, 11, 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "#d8f3ff";
        ctx.fillRect(off - 7, -6, 13, 6);
      }
      ctx.fillStyle = "#ffd93d";
      ctx.fillRect(29, -20, 5, 12);
      break;
    }
    case "soundwave": {
      ctx.translate(x, y - 18);
      ctx.scale(dir, 1);
      for (let i = 0; i < 3; i++) {
        ctx.strokeStyle = `rgba(${150 + i * 35},${220 - i * 25},255,${0.9 - i * 0.22})`;
        ctx.lineWidth = 4 - i * 0.6;
        ctx.beginPath();
        ctx.arc(-i * 8, 0, 13 + i * 8, -Math.PI / 2, Math.PI / 2);
        ctx.stroke();
      }
      break;
    }
    case "bookdrop":
      ctx.save();
      ctx.translate(x, y - 12);
      ctx.rotate(t * 3 + vx * 0.01);
      bookShape(ctx, 0, -8, 32, "#a95858", false);
      ctx.restore();
      break;
    case "dragonfire": {
      const a = Math.atan2(vy, vx);
      ctx.translate(x, y - 10);
      ctx.rotate(a);
      const g = ctx.createLinearGradient(-28, 0, 12, 0);
      g.addColorStop(0, "rgba(255,50,10,0)");
      g.addColorStop(0.6, "#ff6a1a");
      g.addColorStop(1, "#fff3a0");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(-28, -8);
      ctx.quadraticCurveTo(6, -13, 12, 0);
      ctx.quadraticCurveTo(6, 13, -28, 8);
      ctx.closePath();
      ctx.fill();
      break;
    }
    case "shockwave": {
      ctx.translate(x, y);
      ctx.scale(dir, 1);
      ctx.strokeStyle = "#ffd166";
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.moveTo(-12, 0);
      ctx.quadraticCurveTo(-2, -28, 8, -4);
      ctx.quadraticCurveTo(15, -18, 22, 0);
      ctx.stroke();
      ctx.strokeStyle = "#ff7043";
      ctx.lineWidth = 2;
      ctx.stroke();
      break;
    }
    default:
      break;
  }
  ctx.restore();
}

// Mounted trap geometry and rendering share exactly the same math.
export function expansionMountedHit(type: string, hx: number, p: ExpPlatform, time: number, cx: number, cy: number, r: number): boolean {
  if (type === "press") {
    const c = (time + p.phase) % 3.4;
    if (c < 2.45 || c > 3.15) return false;
    const u = c < 2.75 ? (c - 2.45) / 0.3 : 1;
    const top = p.y - 108 + u * 86;
    const nx = Math.max(hx - 24, Math.min(hx + 24, cx));
    const ny = Math.max(top, Math.min(top + 25, cy));
    return Math.hypot(cx - nx, cy - ny) < r;
  }
  if (type === "pendulum") {
    const a = Math.sin(time * 1.75 + p.phase) * 1.12;
    const bx = hx + Math.sin(a) * 62;
    const by = p.y - 78 + Math.cos(a) * 62;
    return Math.hypot(cx - bx, cy - by) < r + 12;
  }
  if (type === "clockhand") {
    const a = time * 1.65 + p.phase;
    const x0 = hx;
    const y0 = p.y - 28;
    const x1 = x0 + Math.cos(a) * 36;
    const y1 = y0 + Math.sin(a) * 36;
    const dx = x1 - x0;
    const dy = y1 - y0;
    const u = Math.max(0, Math.min(1, ((cx - x0) * dx + (cy - y0) * dy) / (dx * dx + dy * dy)));
    return Math.hypot(cx - (x0 + dx * u), cy - (y0 + dy * u)) < r + 5;
  }
  return false;
}

export function drawExpansionMounted(ctx: Ctx, type: string, hx: number, p: ExpPlatform, sy: number, time: number) {
  ctx.save();
  if (type === "press") {
    const c = (time + p.phase) % 3.4;
    const warn = c > 1.85 && c < 2.45;
    const u = c < 2.45 ? 0 : c < 2.75 ? (c - 2.45) / 0.3 : c < 3.15 ? 1 : Math.max(0, 1 - (c - 3.15) / 0.25);
    const top = sy - 108 + u * 86;
    ctx.strokeStyle = "#77818d";
    ctx.lineWidth = 10;
    ctx.beginPath();
    ctx.moveTo(hx, sy - 130);
    ctx.lineTo(hx, top);
    ctx.stroke();
    ctx.fillStyle = warn && Math.sin(time * 25) > 0 ? "#ffdf5a" : "#8994a1";
    ctx.strokeStyle = OUT;
    ctx.lineWidth = 3;
    ctx.fillRect(hx - 24, top, 48, 25);
    ctx.strokeRect(hx - 24, top, 48, 25);
    ctx.fillStyle = "#e74c3c";
    for (let i = -2; i <= 2; i++) ctx.fillRect(hx + i * 9 - 2, top + 21, 4, 7);
  } else if (type === "pendulum") {
    const a = Math.sin(time * 1.75 + p.phase) * 1.12;
    const bx = hx + Math.sin(a) * 62;
    const by = sy - 78 + Math.cos(a) * 62;
    ctx.strokeStyle = "#c4a76a";
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(hx, sy - 78);
    ctx.lineTo(bx, by);
    ctx.stroke();
    ctx.fillStyle = "#a67c3f";
    ctx.strokeStyle = OUT;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(bx, by, 13, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  } else if (type === "clockhand") {
    const a = time * 1.65 + p.phase;
    ctx.strokeStyle = "#ffd166";
    ctx.lineWidth = 7;
    ctx.beginPath();
    ctx.moveTo(hx, sy - 28);
    ctx.lineTo(hx + Math.cos(a) * 36, sy - 28 + Math.sin(a) * 36);
    ctx.stroke();
    ctx.fillStyle = "#493c3c";
    ctx.strokeStyle = OUT;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(hx, sy - 28, 7, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  }
  ctx.restore();
}

export function drawRune(ctx: Ctx, x: number, y: number, t: number) {
  ctx.save();
  ctx.translate(x, y);
  const g = ctx.createRadialGradient(0, 0, 1, 0, 0, 25);
  g.addColorStop(0, "rgba(255,230,120,0.8)");
  g.addColorStop(1, "rgba(255,100,30,0)");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(0, 0, 25, 0, Math.PI * 2);
  ctx.fill();
  ctx.rotate(t * 1.5);
  ctx.fillStyle = "#ffb347";
  ctx.strokeStyle = "#5b1c12";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(0, -13);
  ctx.lineTo(9, 0);
  ctx.lineTo(0, 13);
  ctx.lineTo(-9, 0);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = "#fff3b0";
  ctx.fillRect(-2, -7, 4, 14);
  ctx.restore();
}

// Ambient particles are capped and reuse the engine's fixed pool.
export interface ExpAmb { x: number; y: number; s: number; ph: number; rot: number }
export function updateExpansionAmbient(a: ExpAmb, idx: number, dt: number, time: number, W: number, H: number) {
  let vx = 0;
  let vy = 0;
  if (idx === 12) { vx = Math.sin(time + a.ph) * 14; vy = 55 + a.s * 45; }
  else if (idx === 13) { vx = Math.sin(time * 1.4 + a.ph) * 20; vy = -(15 + a.s * 22); }
  else if (idx === 14) { vx = -45 - a.s * 30; vy = 150 + a.s * 120; }
  else if (idx === 15) { vx = Math.sin(time * 0.6 + a.ph) * 7; vy = 12 + a.s * 15; }
  else if (idx === 16) { vx = Math.sin(time + a.ph) * 15; vy = 35 + a.s * 25; }
  else if (idx === 17) { vx = 25 + a.s * 30; vy = -(12 + a.s * 20); }
  else if (idx === 18) { vx = Math.sin(time * 0.8 + a.ph) * 18; vy = -(8 + a.s * 12); }
  else { vx = Math.sin(time + a.ph) * 12; vy = -(25 + a.s * 35); }
  a.x += vx * dt;
  a.y += vy * dt;
  a.rot += dt * (0.7 + a.s);
  if (a.x < -15) a.x = W + 15;
  if (a.x > W + 15) a.x = -15;
  if (a.y < -15) a.y = H + 15;
  if (a.y > H + 15) a.y = -15;
}

export function drawExpansionAmbient(ctx: Ctx, a: ExpAmb, idx: number, time: number, fade: number) {
  ctx.save();
  if (idx === 12) {
    ctx.fillStyle = `rgba(255,190,70,${0.7 * fade})`;
    ctx.fillRect(a.x, a.y, 2 + a.s * 2, 2 + a.s * 2);
  } else if (idx === 13) {
    ctx.fillStyle = `rgba(255,210,240,${0.65 * fade})`;
    ctx.beginPath();
    ctx.arc(a.x, a.y, 1.5 + a.s * 2.5, 0, Math.PI * 2);
    ctx.fill();
  } else if (idx === 14) {
    ctx.strokeStyle = `rgba(180,225,255,${0.45 * fade})`;
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(a.x - 4, a.y + 12 + a.s * 10);
    ctx.stroke();
  } else if (idx === 15) {
    ctx.fillStyle = `rgba(255,215,140,${0.45 * fade})`;
    ctx.fillRect(a.x, a.y, 2, 2);
  } else if (idx === 16) {
    ctx.translate(a.x, a.y);
    ctx.rotate(a.rot);
    ctx.fillStyle = ["#ff6b6b", "#ffd93d", "#6bcb77", "#4d96ff"][Math.floor(a.s * 4) % 4];
    ctx.globalAlpha = 0.75 * fade;
    ctx.fillRect(-3, -2, 6, 4);
  } else if (idx === 17) {
    ctx.fillStyle = `rgba(210,190,255,${0.7 * fade})`;
    ctx.font = `${10 + a.s * 8}px sans-serif`;
    ctx.fillText(a.s > 0.5 ? "♪" : "♫", a.x, a.y);
  } else if (idx === 18) {
    ctx.translate(a.x, a.y);
    ctx.rotate(a.rot);
    ctx.fillStyle = `rgba(245,230,190,${0.65 * fade})`;
    ctx.fillRect(-4, -3, 8, 6);
    ctx.strokeStyle = "rgba(80,55,45,0.4)";
    ctx.lineWidth = 0.8;
    ctx.beginPath();
    ctx.moveTo(-2, -1);
    ctx.lineTo(2, -1);
    ctx.stroke();
  } else {
    ctx.fillStyle = `rgba(255,${100 + Math.floor(a.s * 100)},40,${(0.4 + 0.3 * Math.sin(time * 5 + a.ph)) * fade})`;
    ctx.fillRect(a.x, a.y, 2 + a.s * 2, 2 + a.s * 2);
  }
  ctx.restore();
}
