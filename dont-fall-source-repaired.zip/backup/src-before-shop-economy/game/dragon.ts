// Stage 20 final boss: the Dragon of the Lair.
// Independent from the stage-12 Warden (which remains an out-climb survival encounter).

export type DragonAttackKind = "breath" | "fireballs" | "shockwave" | "platform";
export interface DragonAttack {
  kind: DragonAttackKind;
  count: number;
  speed: number;
  spread: number;
}
export interface DragonFrame {
  px: number;
  py: number;
  camY: number;
}

const MAX_HP = 120;

export class DragonFight {
  readonly maxHp = MAX_HP;
  hp = MAX_HP;
  x = 180;
  y = 0;
  t = 0;
  hurt = 0;
  dead = false;
  deadT = 0;
  attackT = 2.2;
  attack: DragonAttackKind = "breath";
  warning = false;
  warnFrac = 0;
  private attackIndex = 0;

  get phase(): 1 | 2 | 3 {
    const ratio = this.hp / this.maxHp;
    return ratio <= 0.25 ? 3 : ratio <= 0.6 ? 2 : 1;
  }

  get mouthGlow(): number {
    return this.warning && (this.attack === "breath" || this.attack === "fireballs") ? this.warnFrac : 0;
  }

  /** Apply genuine player damage (head stomp or arena rune). Returns true on the killing blow. */
  damage(amount: number): boolean {
    if (this.dead) return false;
    this.hp = Math.max(0, this.hp - Math.max(0, amount));
    this.hurt = 1;
    if (this.hp <= 0) {
      this.dead = true;
      this.deadT = 0;
      this.warning = false;
      return true;
    }
    return false;
  }

  update(dt: number, frame: DragonFrame): DragonAttack | null {
    this.t += dt;
    this.hurt = Math.max(0, this.hurt - dt * 3.5);
    if (this.dead) {
      this.deadT += dt;
      this.y += 170 * dt;
      return null;
    }

    // The head hovers above the player but inside normal jump apex, making stomps possible.
    const targetX = 180 + Math.sin(this.t * (0.45 + this.phase * 0.08)) * 102;
    this.x += (targetX - this.x) * Math.min(1, dt * 1.5);
    // Keep the weak point below the HUD while remaining within a normal jump on every aspect ratio.
    // Vertical tracking is smoothed: an upward camera step must not teleport the head away
    // from a player who is already falling toward a stomp.
    const targetY = Math.max(frame.camY + 245, frame.py - 100) + Math.sin(this.t * 1.35) * 8;
    if (this.t <= dt + 0.0001) this.y = targetY;
    else this.y += (targetY - this.y) * Math.min(1, dt * 3.2);

    this.attackT -= dt;
    const warnDuration = this.phase === 1 ? 0.85 : this.phase === 2 ? 0.65 : 0.48;
    this.warning = this.attackT <= warnDuration;
    this.warnFrac = this.warning ? Math.min(1, Math.max(0, 1 - this.attackT / warnDuration)) : 0;
    if (this.attackT > 0) return null;

    const kinds: DragonAttackKind[] = ["breath", "fireballs", "shockwave", "platform"];
    const kind = kinds[this.attackIndex % kinds.length];
    this.attackIndex++;
    this.attack = kind;
    this.attackT = this.phase === 1 ? 2.55 : this.phase === 2 ? 1.8 : 1.22;
    this.warning = false;
    return {
      kind,
      count: kind === "breath" ? 2 + this.phase : kind === "fireballs" ? 1 + this.phase : this.phase >= 2 ? 2 : 1,
      speed: 235 + this.phase * 35,
      spread: kind === "breath" ? 0.17 : 0.32,
    };
  }
}

/** Large animated cartoon dragon, using the same outlined style as the original game. */
export function drawDragon(ctx: CanvasRenderingContext2D, d: DragonFight, screenY: number, time: number) {
  const phase = d.phase;
  ctx.save();
  ctx.translate(d.x, screenY);
  if (d.dead) {
    ctx.globalAlpha = Math.max(0, 1 - d.deadT / 1.8);
    ctx.rotate(d.deadT * 1.1);
    ctx.scale(Math.max(0.35, 1 - d.deadT * 0.25), Math.max(0.35, 1 - d.deadT * 0.25));
  }
  const flash = d.hurt > 0 && Math.floor(time * 24) % 2 === 0;
  const scale = 1 + Math.sin(time * 2.4) * 0.025;
  ctx.scale(scale, scale);
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  ctx.strokeStyle = "#1b0b16";
  ctx.lineWidth = 3.5;

  // heat aura, intensifying with each phase
  const aura = ctx.createRadialGradient(0, 0, 8, 0, 0, 105);
  aura.addColorStop(0, phase === 3 ? "rgba(255,60,25,0.38)" : "rgba(255,120,50,0.24)");
  aura.addColorStop(1, "rgba(255,60,20,0)");
  ctx.fillStyle = aura;
  ctx.beginPath();
  ctx.arc(0, 0, 105, 0, Math.PI * 2);
  ctx.fill();

  // wings
  const flap = Math.sin(time * (4 + phase)) * 10;
  for (const side of [-1, 1]) {
    ctx.fillStyle = flash ? "#fff0d0" : phase === 3 ? "#8d1f2d" : "#5b2745";
    ctx.beginPath();
    ctx.moveTo(side * 28, 8);
    ctx.lineTo(side * 86, -35 - flap);
    ctx.lineTo(side * 70, 2);
    ctx.lineTo(side * 91, 20 + flap * 0.4);
    ctx.lineTo(side * 48, 27);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }
  // tail
  ctx.strokeStyle = "#1b0b16";
  ctx.lineWidth = 18;
  ctx.beginPath();
  ctx.moveTo(28, 24);
  ctx.quadraticCurveTo(72, 42, 64 + Math.sin(time * 3) * 12, 74);
  ctx.stroke();
  ctx.strokeStyle = flash ? "#fff0d0" : "#8d3541";
  ctx.lineWidth = 11;
  ctx.stroke();

  // body and belly
  ctx.fillStyle = flash ? "#fff0d0" : phase === 3 ? "#a82932" : "#783449";
  ctx.strokeStyle = "#1b0b16";
  ctx.lineWidth = 3.5;
  ctx.beginPath();
  ctx.ellipse(0, 20, 39, 43, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = "#d69a62";
  ctx.beginPath();
  ctx.ellipse(0, 29, 22, 29, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.strokeStyle = "rgba(80,35,25,0.55)";
  ctx.lineWidth = 2;
  for (let y = 14; y < 48; y += 9) {
    ctx.beginPath();
    ctx.moveTo(-16, y);
    ctx.quadraticCurveTo(0, y + 5, 16, y);
    ctx.stroke();
  }

  // horns
  ctx.strokeStyle = "#1b0b16";
  ctx.lineWidth = 3.5;
  for (const side of [-1, 1]) {
    ctx.fillStyle = "#ead9b0";
    ctx.beginPath();
    ctx.moveTo(side * 20, -33);
    ctx.quadraticCurveTo(side * 39, -57, side * 28, -76);
    ctx.quadraticCurveTo(side * 13, -57, side * 8, -39);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }
  // head (the stompable weak point)
  ctx.fillStyle = flash ? "#fff7df" : phase === 3 ? "#b52c36" : "#8d3c4d";
  ctx.beginPath();
  ctx.moveTo(-43, -20);
  ctx.quadraticCurveTo(-42, -51, 0, -51);
  ctx.quadraticCurveTo(42, -51, 43, -20);
  ctx.quadraticCurveTo(31, 3, 0, 2);
  ctx.quadraticCurveTo(-31, 3, -43, -20);
  ctx.fill();
  ctx.stroke();
  // snout
  ctx.fillStyle = "#bb6c58";
  ctx.beginPath();
  ctx.ellipse(0, -10, 34, 18, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = "#33121b";
  for (const side of [-1, 1]) {
    ctx.beginPath();
    ctx.arc(side * 13, -14, 3.2, 0, Math.PI * 2);
    ctx.fill();
  }
  // eyes
  for (const side of [-1, 1]) {
    ctx.fillStyle = "#fff2a8";
    ctx.beginPath();
    ctx.ellipse(side * 18, -32, 9, 7, side * 0.15, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = phase === 3 ? "#ff2d20" : "#34121b";
    ctx.beginPath();
    ctx.ellipse(side * 18, -32, 2.8, 6, 0, 0, Math.PI * 2);
    ctx.fill();
  }
  // mouth + charging fire
  ctx.fillStyle = "#2b0b12";
  ctx.beginPath();
  ctx.moveTo(-24, -2);
  ctx.quadraticCurveTo(0, 17 + d.mouthGlow * 9, 24, -2);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = "#fff3d0";
  for (const side of [-1, 1]) {
    ctx.beginPath();
    ctx.moveTo(side * 16, 0);
    ctx.lineTo(side * 11, 10);
    ctx.lineTo(side * 7, 1);
    ctx.closePath();
    ctx.fill();
  }
  if (d.mouthGlow > 0) {
    const g = ctx.createRadialGradient(0, 7, 1, 0, 7, 34);
    g.addColorStop(0, "#fff7b0");
    g.addColorStop(0.5, "#ff8a25");
    g.addColorStop(1, "rgba(255,50,10,0)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(0, 7, 34 * d.mouthGlow, 0, Math.PI * 2);
    ctx.fill();
  }
  // weak-point marker, readable without changing the character sprite
  if (!d.dead) {
    ctx.strokeStyle = `rgba(255,225,100,${0.35 + 0.35 * Math.sin(time * 5)})`;
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.ellipse(0, -47, 47, 10, 0, Math.PI, 0);
    ctx.stroke();
  }
  ctx.restore();

  // universal attack warning
  if (d.warning && !d.dead) {
    ctx.save();
    ctx.translate(d.x, screenY - 100);
    const pulse = 1 + Math.sin(time * 18) * 0.12;
    ctx.scale(pulse, pulse);
    ctx.fillStyle = "#ffd166";
    ctx.strokeStyle = "#2a0d18";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(0, -18);
    ctx.lineTo(17, 13);
    ctx.lineTo(-17, 13);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = "#2a0d18";
    ctx.font = "900 23px sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("!", 0, 4);
    ctx.restore();
  }
}
