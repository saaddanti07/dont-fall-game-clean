// Drawing for hazards, warning markers and power-ups (same outlined cartoon style as the rest of the game).

export type HazKind =
  | "icicle" | "rock" | "firerock" | "fruit" | "star" | "fireball" | "bird"
  /* worlds 7-12 */
  | "jellyfish" | "fish" | "spore" | "ghost" | "drone" | "meteor" | "candy" | "skull" | "bossfire"
  /* stages 13-20 */
  | "cog" | "sporeseed" | "cannonball" | "toyball" | "train" | "soundwave" | "bookdrop" | "dragonfire" | "shockwave";
export type PowerType = "shield" | "magnet" | "double" | "rocket" | "slow";

const OUT = "#26102f";

export const POWER_COLOR: Record<PowerType, string> = {
  shield: "#3fb7ff",
  magnet: "#ff5a5a",
  double: "#ffc61f",
  rocket: "#ff7a18",
  slow: "#7fe3ff",
};

export const POWER_NAME: Record<PowerType, string> = {
  shield: "SHIELD",
  magnet: "MAGNET",
  double: "2x COINS",
  rocket: "ROCKET!",
  slow: "SLOW LAVA",
};

export const WARN_COLOR: Record<HazKind, string> = {
  icicle: "#7fe3ff",
  rock: "#c9a6ff",
  firerock: "#ff7a18",
  fruit: "#ff5a5a",
  star: "#ffe066",
  fireball: "#ff7a18",
  bird: "#ff5a5a",
  jellyfish: "#ff8ad0",
  fish: "#ffd166",
  spore: "#a6ff8f",
  ghost: "#c8f0ff",
  drone: "#ff5ad6",
  meteor: "#ffb27f",
  candy: "#ff6ab8",
  skull: "#e0dcff",
  bossfire: "#ff6a4d",
  cog: "#f2b84b",
  sporeseed: "#ff8fb3",
  cannonball: "#d9c49a",
  toyball: "#ffd93d",
  train: "#ff6b6b",
  soundwave: "#c59aff",
  bookdrop: "#8fd3b6",
  dragonfire: "#ff7043",
  shockwave: "#ffd166",
};

// ---------------------------------------------------------------------------------------------
// Falling / flying hazards. (x, y) is the lower-centre point of the hazard.
// ---------------------------------------------------------------------------------------------
export function drawHazard(ctx: CanvasRenderingContext2D, kind: HazKind, x: number, y: number, t: number, dir = 1, vx = 0, vy = 400) {
  ctx.save();
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  ctx.lineWidth = 2.4;
  ctx.strokeStyle = OUT;
  switch (kind) {
    case "icicle": {
      const g = ctx.createLinearGradient(x - 7, 0, x + 7, 0);
      g.addColorStop(0, "#eafcff");
      g.addColorStop(1, "#6fc9ee");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(x - 7.5, y - 32);
      ctx.lineTo(x + 7.5, y - 32);
      ctx.lineTo(x, y + 2);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.strokeStyle = "rgba(255,255,255,0.9)";
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.moveTo(x - 3.5, y - 28);
      ctx.lineTo(x - 1.5, y - 10);
      ctx.stroke();
      break;
    }
    case "rock": {
      ctx.fillStyle = "#8b7bb0";
      ctx.beginPath();
      ctx.moveTo(x - 9, y - 24);
      ctx.lineTo(x + 9, y - 24);
      ctx.lineTo(x + 2, y + 2);
      ctx.lineTo(x - 2, y + 2);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "rgba(255,255,255,0.25)";
      ctx.fillRect(x - 6, y - 21, 3, 12);
      break;
    }
    case "firerock": {
      // flame tail (above, because it falls)
      const fl = 14 + 4 * Math.sin(t * 20);
      ctx.fillStyle = "#ff7a18";
      ctx.beginPath();
      ctx.moveTo(x - 9, y - 10);
      ctx.quadraticCurveTo(x - 7, y - 10 - fl, x, y - 14 - fl * 1.6);
      ctx.quadraticCurveTo(x + 7, y - 10 - fl, x + 9, y - 10);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = "#ffe066";
      ctx.beginPath();
      ctx.moveTo(x - 4, y - 10);
      ctx.quadraticCurveTo(x - 3, y - 10 - fl * 0.6, x, y - 10 - fl);
      ctx.quadraticCurveTo(x + 3, y - 10 - fl * 0.6, x + 4, y - 10);
      ctx.fill();
      ctx.translate(x, y - 11);
      ctx.rotate(t * 3);
      ctx.fillStyle = "#4a1a14";
      ctx.beginPath();
      ctx.moveTo(-11, -3);
      ctx.lineTo(-4, -11);
      ctx.lineTo(7, -9);
      ctx.lineTo(11, 1);
      ctx.lineTo(4, 10);
      ctx.lineTo(-7, 9);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.strokeStyle = "#ff9a3c";
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.moveTo(-4, -4);
      ctx.lineTo(1, 1);
      ctx.lineTo(-1, 6);
      ctx.moveTo(1, 1);
      ctx.lineTo(7, -2);
      ctx.stroke();
      break;
    }
    case "fruit": {
      ctx.translate(x, y - 10);
      ctx.rotate(Math.sin(t * 6) * 0.25);
      ctx.fillStyle = "#e63946";
      ctx.beginPath();
      ctx.arc(0, 0, 10.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "rgba(255,255,255,0.4)";
      ctx.beginPath();
      ctx.ellipse(-4, -4, 2.6, 3.6, -0.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#4fc25a";
      ctx.beginPath();
      ctx.ellipse(4, -11, 5, 2.6, -0.6, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.strokeStyle = "#5b3418";
      ctx.beginPath();
      ctx.moveTo(0, -10);
      ctx.lineTo(-1, -15);
      ctx.stroke();
      break;
    }
    case "star": {
      // comet tail above
      const g = ctx.createLinearGradient(x, y - 60, x, y - 8);
      g.addColorStop(0, "rgba(255,230,120,0)");
      g.addColorStop(1, "rgba(255,230,120,0.75)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(x - 7, y - 12);
      ctx.lineTo(x, y - 62);
      ctx.lineTo(x + 7, y - 12);
      ctx.closePath();
      ctx.fill();
      ctx.translate(x, y - 11);
      ctx.rotate(t * 4);
      ctx.fillStyle = "#ffe066";
      ctx.beginPath();
      for (let i = 0; i < 10; i++) {
        const a = (i / 10) * Math.PI * 2 - Math.PI / 2;
        const r = i % 2 ? 5.4 : 12;
        ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r);
      }
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      break;
    }
    case "jellyfish": {
      const pulse = 1 + Math.sin(t * 6) * 0.12;
      ctx.save();
      ctx.translate(x, y - 16);
      ctx.scale(pulse, 2 - pulse);
      const g = ctx.createLinearGradient(0, -14, 0, 6);
      g.addColorStop(0, "rgba(255,255,255,0.95)");
      g.addColorStop(1, "rgba(255,120,200,0.85)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(0, 0, 13, Math.PI, 0);
      ctx.quadraticCurveTo(0, 7, -13, 0);
      ctx.fill();
      ctx.stroke();
      ctx.restore();
      ctx.strokeStyle = "rgba(255,150,215,0.9)";
      ctx.lineWidth = 2.2;
      for (let i = -2; i <= 2; i++) {
        ctx.beginPath();
        ctx.moveTo(x + i * 5, y - 14);
        ctx.quadraticCurveTo(x + i * 5 + Math.sin(t * 5 + i) * 4, y - 5, x + i * 6 + Math.sin(t * 4 + i) * 6, y + 4);
        ctx.stroke();
      }
      break;
    }
    case "fish": {
      ctx.translate(x, y - 12);
      ctx.scale(dir, 1);
      ctx.fillStyle = "#ffb347";
      ctx.strokeStyle = OUT;
      ctx.beginPath();
      ctx.ellipse(0, 0, 15, 9.5, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#ff7a18";
      ctx.beginPath();
      ctx.moveTo(-13, 0);
      ctx.lineTo(-24, -8);
      ctx.lineTo(-24, 8);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "rgba(255,255,255,0.5)";
      ctx.beginPath();
      ctx.ellipse(3, -3, 6, 2.6, -0.4, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#fff";
      ctx.beginPath();
      ctx.arc(8, -2.5, 3, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = OUT;
      ctx.beginPath();
      ctx.arc(9, -2.5, 1.5, 0, Math.PI * 2);
      ctx.fill();
      // spines (hazard cue)
      ctx.strokeStyle = "#ffe066";
      ctx.lineWidth = 2;
      for (let i = -1; i <= 1; i++) {
        ctx.beginPath();
        ctx.moveTo(i * 7, -9);
        ctx.lineTo(i * 7, -14);
        ctx.stroke();
      }
      break;
    }
    case "spore": {
      ctx.translate(x, y - 12);
      const p2 = 0.6 + 0.4 * Math.sin(t * 7);
      const g = ctx.createRadialGradient(0, 0, 2, 0, 0, 20);
      g.addColorStop(0, `rgba(190,255,150,${0.9 * p2})`);
      g.addColorStop(1, "rgba(120,255,160,0)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(0, 0, 20, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#8fe07a";
      ctx.strokeStyle = OUT;
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      ctx.ellipse(0, 0, 9, 11, Math.sin(t * 3) * 0.3, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "rgba(255,255,255,0.8)";
      ctx.beginPath();
      ctx.arc(-3, -4, 2.2, 0, Math.PI * 2);
      ctx.fill();
      break;
    }
    case "ghost": {
      const bob = Math.sin(t * 3) * 2;
      ctx.save();
      ctx.translate(x, y - 16 + bob);
      ctx.globalAlpha = 0.86;
      const g = ctx.createLinearGradient(0, -16, 0, 14);
      g.addColorStop(0, "#f2fff8");
      g.addColorStop(1, "rgba(150,240,190,0.55)");
      ctx.fillStyle = g;
      ctx.strokeStyle = "rgba(60,140,110,0.9)";
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      ctx.arc(0, -3, 13, Math.PI, 0);
      ctx.lineTo(13, 8);
      for (let i = 0; i < 3; i++) ctx.quadraticCurveTo(13 - (i * 2 + 1) * (13 / 3) - 4, 8 + (i % 2 ? 7 : -2), 13 - (i + 1) * (26 / 3), 8);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#26102f";
      ctx.beginPath();
      ctx.ellipse(-4.5 * dir, -4, 2.4, 3.4, 0, 0, Math.PI * 2);
      ctx.ellipse(4.5 * dir, -4, 2.4, 3.4, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(0, 3.5, 3.2, 2.4, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
      break;
    }
    case "drone": {
      ctx.translate(x, y - 12);
      ctx.scale(dir, 1);
      // thruster glow
      ctx.fillStyle = `rgba(95,242,255,${0.5 + 0.4 * Math.sin(t * 22)})`;
      ctx.beginPath();
      ctx.ellipse(-15, 1, 8, 4, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#2b2a4a";
      ctx.strokeStyle = "#5ff2ff";
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      ctx.moveTo(-12, -7);
      ctx.lineTo(9, -7);
      ctx.lineTo(14, 0);
      ctx.lineTo(9, 7);
      ctx.lineTo(-12, 7);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#ff3b6b";
      ctx.beginPath();
      ctx.arc(6, 0, 3.4, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "#ff5ad6";
      ctx.beginPath();
      ctx.moveTo(-6, -7);
      ctx.lineTo(-6, -13);
      ctx.stroke();
      ctx.fillStyle = "#ff5ad6";
      ctx.beginPath();
      ctx.arc(-6, -14.5, 2.2, 0, Math.PI * 2);
      ctx.fill();
      break;
    }
    case "meteor": {
      ctx.save();
      const ang = Math.atan2(vy, vx);
      ctx.translate(x, y - 12);
      ctx.rotate(ang + Math.PI / 2);
      const g = ctx.createLinearGradient(0, -60, 0, 0);
      g.addColorStop(0, "rgba(255,190,120,0)");
      g.addColorStop(1, "rgba(255,200,140,0.8)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(-7, -4);
      ctx.lineTo(0, -66);
      ctx.lineTo(7, -4);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = "#6b5a7a";
      ctx.strokeStyle = OUT;
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      ctx.moveTo(-11, -4);
      ctx.lineTo(-5, -13);
      ctx.lineTo(6, -11);
      ctx.lineTo(11, -1);
      ctx.lineTo(4, 9);
      ctx.lineTo(-7, 8);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "rgba(255,140,60,0.85)";
      ctx.beginPath();
      ctx.arc(-2, -2, 3.2, 0, Math.PI * 2);
      ctx.arc(5, 3, 2, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
      break;
    }
    case "candy": {
      ctx.translate(x, y - 11);
      ctx.rotate(Math.sin(t * 5) * 0.4);
      for (const s2 of [-1, 1]) {
        ctx.fillStyle = "#fff6fb";
        ctx.beginPath();
        ctx.moveTo(s2 * 8, 0);
        ctx.lineTo(s2 * 15, -6);
        ctx.lineTo(s2 * 15, 6);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      }
      const g = ctx.createLinearGradient(0, -9, 0, 9);
      g.addColorStop(0, "#ffd6ef");
      g.addColorStop(1, "#ff5aa8");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(0, 0, 9.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.strokeStyle = "rgba(255,255,255,0.9)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(0, 0, 5, 0.5, 2.3);
      ctx.stroke();
      break;
    }
    case "skull": {
      ctx.translate(x, y - 13);
      ctx.scale(dir, 1);
      ctx.fillStyle = "#efeaff";
      ctx.strokeStyle = OUT;
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      ctx.arc(-1, -3, 10, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(-8, 4);
      ctx.lineTo(7, 4);
      ctx.lineTo(5, 11);
      ctx.lineTo(-6, 11);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#1a0830";
      ctx.beginPath();
      ctx.ellipse(-4.5, -4, 3.2, 4, 0, 0, Math.PI * 2);
      ctx.ellipse(4.5, -4, 3.2, 4, 0, 0, Math.PI * 2);
      ctx.fill();
      // ember eyes
      ctx.fillStyle = `rgba(255,110,70,${0.6 + 0.4 * Math.sin(t * 8)})`;
      ctx.beginPath();
      ctx.arc(-4.5, -4, 1.6, 0, Math.PI * 2);
      ctx.arc(4.5, -4, 1.6, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "#1a0830";
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.moveTo(-2, 7.5);
      ctx.lineTo(-2, 11);
      ctx.moveTo(1.5, 7.5);
      ctx.lineTo(1.5, 11);
      ctx.stroke();
      break;
    }
    case "bossfire": {
      ctx.save();
      ctx.translate(x, y - 10);
      const ang = Math.atan2(vy, vx);
      ctx.rotate(ang);
      const g = ctx.createLinearGradient(-34, 0, 8, 0);
      g.addColorStop(0, "rgba(255,90,30,0)");
      g.addColorStop(1, "rgba(255,170,60,0.9)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(-32, -7);
      ctx.lineTo(2, 0);
      ctx.lineTo(-32, 7);
      ctx.closePath();
      ctx.fill();
      const rg = ctx.createRadialGradient(0, 0, 1, 0, 0, 12);
      rg.addColorStop(0, "#fff2b0");
      rg.addColorStop(0.5, "#ff9a3c");
      rg.addColorStop(1, "#e0310f");
      ctx.fillStyle = rg;
      ctx.beginPath();
      ctx.arc(0, 0, 10 + Math.sin(t * 20) * 1.4, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "rgba(80,20,0,0.9)";
      ctx.lineWidth = 1.6;
      ctx.stroke();
      ctx.restore();
      break;
    }

    case "fireball": {
      // tail below (fireballs rise from lava)
      const fl = 16 + 4 * Math.sin(t * 22);
      ctx.fillStyle = "#e0310f";
      ctx.beginPath();
      ctx.moveTo(x - 10, y - 10);
      ctx.quadraticCurveTo(x - 6, y - 4 + fl, x, y + fl + 4);
      ctx.quadraticCurveTo(x + 6, y - 4 + fl, x + 10, y - 10);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = "#ff7a18";
      ctx.beginPath();
      ctx.arc(x, y - 11, 11.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#ffe066";
      ctx.beginPath();
      ctx.arc(x, y - 11, 6, 0, Math.PI * 2);
      ctx.fill();
      break;
    }
    case "bird": {
      ctx.translate(x, y - 12);
      ctx.scale(dir, 1);
      const flap = Math.sin(t * 14);
      // far wing
      ctx.fillStyle = "#3a2418";
      ctx.beginPath();
      ctx.moveTo(-4, -2);
      ctx.lineTo(-14, -14 - flap * 8);
      ctx.lineTo(4, -4);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      // body
      ctx.fillStyle = "#6b4630";
      ctx.beginPath();
      ctx.ellipse(0, 0, 14, 8.5, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      // near wing
      ctx.fillStyle = "#4a2e1e";
      ctx.beginPath();
      ctx.moveTo(-6, 0);
      ctx.lineTo(-16, 12 + flap * 8);
      ctx.lineTo(6, 3);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      // head
      ctx.fillStyle = "#e9c9a0";
      ctx.beginPath();
      ctx.arc(12, -3, 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#ffb703";
      ctx.beginPath();
      ctx.moveTo(16.5, -4);
      ctx.lineTo(23, -1);
      ctx.lineTo(16.5, 0);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#fff";
      ctx.beginPath();
      ctx.arc(13, -5, 1.8, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#e63946";
      ctx.beginPath();
      ctx.arc(13.4, -5, 0.9, 0, Math.PI * 2);
      ctx.fill();
      break;
    }
  }
  ctx.restore();
}

// ---------------------------------------------------------------------------------------------
// Warning marker: rounded triangle with "!" (drawn in screen space)
// ---------------------------------------------------------------------------------------------
export function drawWarning(ctx: CanvasRenderingContext2D, x: number, y: number, color: string, t: number, lane = 0) {
  ctx.save();
  if (lane > 0) {
    ctx.strokeStyle = color;
    ctx.globalAlpha = 0.28 + 0.14 * Math.sin(t * 16);
    ctx.lineWidth = 14;
    ctx.beginPath();
    ctx.moveTo(x, y + 14);
    ctx.lineTo(x, y + lane);
    ctx.stroke();
    ctx.globalAlpha = 1;
  }
  const s = 1 + 0.12 * Math.sin(t * 16);
  ctx.translate(x, y);
  ctx.scale(s, s);
  ctx.lineJoin = "round";
  ctx.lineWidth = 3;
  ctx.strokeStyle = OUT;
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(0, -14);
  ctx.lineTo(14, 11);
  ctx.lineTo(-14, 11);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = OUT;
  ctx.fillRect(-1.8, -6, 3.6, 10);
  ctx.beginPath();
  ctx.arc(0, 7.4, 2, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

// ---------------------------------------------------------------------------------------------
// Platform-mounted hazards. (x, y) = base point on top of the platform.
// ---------------------------------------------------------------------------------------------
export function drawCactus(ctx: CanvasRenderingContext2D, x: number, y: number) {
  ctx.save();
  ctx.translate(x, y);
  ctx.lineJoin = "round";
  ctx.lineWidth = 2.4;
  ctx.strokeStyle = "#0e3a14";
  ctx.fillStyle = "#3fae4b";
  const arm = (side: number) => {
    ctx.beginPath();
    ctx.moveTo(side * 4, -9);
    ctx.lineTo(side * 9, -9);
    ctx.lineTo(side * 9, -17);
    ctx.stroke();
    ctx.lineWidth = 5.5;
    ctx.strokeStyle = "#3fae4b";
    ctx.beginPath();
    ctx.moveTo(side * 4, -9);
    ctx.lineTo(side * 9, -9);
    ctx.lineTo(side * 9, -16);
    ctx.stroke();
    ctx.lineWidth = 2.4;
    ctx.strokeStyle = "#0e3a14";
  };
  arm(-1);
  arm(1);
  rr2(ctx, -5.5, -27, 11, 28, 5.5);
  ctx.fill();
  ctx.stroke();
  ctx.strokeStyle = "rgba(255,255,255,0.85)";
  ctx.lineWidth = 1.4;
  for (const [sx, sy] of [[-3, -20], [3, -14], [-3, -8], [9, -17], [-9, -17]]) {
    ctx.beginPath();
    ctx.moveTo(sx, sy);
    ctx.lineTo(sx + (sx < 0 ? -2.5 : 2.5), sy - 1.5);
    ctx.stroke();
  }
  ctx.fillStyle = "#ff6fa5";
  ctx.beginPath();
  ctx.arc(0, -28, 3, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function rr2(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

/** stage: 0 idle bud (safe), 1 warning (growing, red), 2 snapping (harmful). u = 0..1 progress within stage. */
export function drawPlant(ctx: CanvasRenderingContext2D, x: number, y: number, stage: 0 | 1 | 2, u: number, t: number) {
  ctx.save();
  ctx.translate(x, y);
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  const h = stage === 0 ? 12 + Math.sin(t * 3) * 1.2 : stage === 1 ? 14 + u * 12 : 36;
  const shake = stage === 1 ? Math.sin(t * 50) * 1.6 : 0;
  // leaves at base
  ctx.fillStyle = "#2f9a3c";
  ctx.strokeStyle = "#0e3a14";
  ctx.lineWidth = 2.2;
  ctx.beginPath();
  ctx.ellipse(-6, -2, 6, 3, -0.4, 0, Math.PI * 2);
  ctx.ellipse(6, -2, 6, 3, 0.4, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  // stem
  ctx.strokeStyle = "#0e3a14";
  ctx.lineWidth = 7;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(shake, -h);
  ctx.stroke();
  ctx.strokeStyle = "#3fae4b";
  ctx.lineWidth = 3.4;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(shake, -h);
  ctx.stroke();
  // head
  ctx.translate(shake, -h);
  const open = stage === 2 ? 0.95 : stage === 1 ? 0.15 + u * 0.2 : 0;
  const warn = stage === 1;
  ctx.lineWidth = 2.4;
  ctx.strokeStyle = "#0e3a14";
  const jaw = (dir: number) => {
    ctx.save();
    ctx.rotate(dir * open * 0.9);
    ctx.fillStyle = warn ? (Math.sin(t * 30) > 0 ? "#ff5a5a" : "#d9387a") : "#c2185b";
    ctx.beginPath();
    ctx.arc(0, 0, 11, dir > 0 ? Math.PI : 0, dir > 0 ? 0 : Math.PI);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    if (open > 0.3) {
      ctx.fillStyle = "#fff";
      for (let i = -1; i <= 1; i++) {
        ctx.beginPath();
        ctx.moveTo(i * 6 - 2.4, 0);
        ctx.lineTo(i * 6, dir * -5);
        ctx.lineTo(i * 6 + 2.4, 0);
        ctx.fill();
      }
    }
    ctx.restore();
  };
  jaw(-1);
  jaw(1);
  ctx.restore();
}

// ---------------------------------------------------------------------------------------------
// Power-ups
// ---------------------------------------------------------------------------------------------
export function drawPowerup(ctx: CanvasRenderingContext2D, type: PowerType, x: number, y: number, t: number, scale = 1) {
  const c = POWER_COLOR[type];
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);
  // glow
  const g = ctx.createRadialGradient(0, 0, 4, 0, 0, 30);
  g.addColorStop(0, c + "99");
  g.addColorStop(1, c + "00");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(0, 0, 30 + Math.sin(t * 5) * 2, 0, Math.PI * 2);
  ctx.fill();
  // bubble
  ctx.lineWidth = 2.6;
  ctx.strokeStyle = OUT;
  ctx.fillStyle = "#2b1650";
  ctx.beginPath();
  ctx.arc(0, 0, 16, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.strokeStyle = c;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(0, 0, 13.4, 0, Math.PI * 2);
  ctx.stroke();
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  switch (type) {
    case "shield":
      ctx.fillStyle = c;
      ctx.strokeStyle = "#fff";
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.moveTo(0, -8.5);
      ctx.lineTo(7.5, -5.5);
      ctx.quadraticCurveTo(7.5, 4.5, 0, 9);
      ctx.quadraticCurveTo(-7.5, 4.5, -7.5, -5.5);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#fff";
      ctx.fillRect(-1.2, -4.5, 2.4, 9);
      ctx.fillRect(-4, -1.3, 8, 2.4);
      break;
    case "magnet":
      ctx.lineWidth = 5;
      ctx.strokeStyle = c;
      ctx.beginPath();
      ctx.moveTo(-6, -7);
      ctx.lineTo(-6, 1);
      ctx.arc(0, 1, 6, Math.PI, 0, true);
      ctx.lineTo(6, -7);
      ctx.stroke();
      ctx.strokeStyle = "#fff";
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.moveTo(-6, -8);
      ctx.lineTo(-6, -4);
      ctx.moveTo(6, -8);
      ctx.lineTo(6, -4);
      ctx.stroke();
      break;
    case "double":
      ctx.font = "900 15px 'Luckiest Guy', Arial Black, sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.lineWidth = 3;
      ctx.strokeStyle = "#5a3300";
      ctx.strokeText("x2", 0, 1);
      ctx.fillStyle = c;
      ctx.fillText("x2", 0, 1);
      break;
    case "rocket":
      ctx.rotate(-Math.PI / 4);
      ctx.fillStyle = "#ffcf5a";
      ctx.beginPath();
      ctx.moveTo(-3, 8);
      ctx.lineTo(0, 14 + Math.sin(t * 20) * 2);
      ctx.lineTo(3, 8);
      ctx.fill();
      ctx.fillStyle = "#ff5a5a";
      ctx.beginPath();
      ctx.moveTo(-5, 4);
      ctx.lineTo(-9, 10);
      ctx.lineTo(-3, 7);
      ctx.moveTo(5, 4);
      ctx.lineTo(9, 10);
      ctx.lineTo(3, 7);
      ctx.fill();
      ctx.fillStyle = "#f4f7fb";
      ctx.strokeStyle = OUT;
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.moveTo(0, -11);
      ctx.quadraticCurveTo(7, -3, 4.5, 8);
      ctx.lineTo(-4.5, 8);
      ctx.quadraticCurveTo(-7, -3, 0, -11);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#ff5a5a";
      ctx.beginPath();
      ctx.moveTo(0, -11);
      ctx.quadraticCurveTo(3.5, -8, 4, -5);
      ctx.lineTo(-4, -5);
      ctx.quadraticCurveTo(-3.5, -8, 0, -11);
      ctx.fill();
      ctx.fillStyle = "#3fb7ff";
      ctx.beginPath();
      ctx.arc(0, 0.5, 2.4, 0, Math.PI * 2);
      ctx.fill();
      break;
    case "slow":
      ctx.strokeStyle = c;
      ctx.lineWidth = 2.4;
      for (let i = 0; i < 3; i++) {
        const a = (i * Math.PI) / 3;
        ctx.beginPath();
        ctx.moveTo(Math.cos(a) * 9, Math.sin(a) * 9);
        ctx.lineTo(-Math.cos(a) * 9, -Math.sin(a) * 9);
        ctx.stroke();
      }
      ctx.lineWidth = 1.8;
      ctx.strokeStyle = "#fff";
      ctx.beginPath();
      ctx.arc(0, 0, 3.2, 0, Math.PI * 2);
      ctx.stroke();
      break;
  }
  ctx.restore();
}

const iconCache: Partial<Record<PowerType, string>> = {};
/** Renders a power-up icon to a data URL (single source of truth for HUD icons). */
export function powerIconUrl(type: PowerType): string {
  const hit = iconCache[type];
  if (hit) return hit;
  const c = document.createElement("canvas");
  c.width = c.height = 72;
  const ctx = c.getContext("2d")!;
  drawPowerup(ctx, type, 36, 36, 0, 1.55);
  const url = c.toDataURL("image/png");
  iconCache[type] = url;
  return url;
}

// ---------------------------------------------------------------------------------------------
// World 9 (Cyber City) laser beam, world 12 traps, and the Warden boss.
// ---------------------------------------------------------------------------------------------
/** state: 0 = charging (thin blinking line), 1 = firing (solid beam). */
export function drawLaser(ctx: CanvasRenderingContext2D, x0: number, x1: number, y: number, state: 0 | 1, u: number, t: number) {
  ctx.save();
  const w = x1 - x0;
  if (state === 0) {
    ctx.globalAlpha = 0.35 + 0.45 * Math.abs(Math.sin(t * 14));
    ctx.strokeStyle = "#ff5ad6";
    ctx.lineWidth = 2;
    ctx.setLineDash([10, 8]);
    ctx.lineDashOffset = -t * 60;
    ctx.beginPath();
    ctx.moveTo(x0, y);
    ctx.lineTo(x1, y);
    ctx.stroke();
    ctx.setLineDash([]);
  } else {
    const h = 7 + 5 * Math.sin(t * 30) * 0.4 + u * 2;
    const g = ctx.createLinearGradient(0, y - h, 0, y + h);
    g.addColorStop(0, "rgba(255,90,214,0)");
    g.addColorStop(0.5, "rgba(255,240,255,0.95)");
    g.addColorStop(1, "rgba(255,90,214,0)");
    ctx.fillStyle = g;
    ctx.fillRect(x0, y - h, w, h * 2);
    ctx.fillStyle = "rgba(95,242,255,0.75)";
    ctx.fillRect(x0, y - h * 0.35, w, h * 0.7);
  }
  // emitters on both ends
  for (const ex of [x0, x1]) {
    ctx.fillStyle = "#2b2a4a";
    ctx.strokeStyle = "#5ff2ff";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(ex, y, 8, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = state === 1 ? "#ff3b6b" : "rgba(255,59,107,0.5)";
    ctx.beginPath();
    ctx.arc(ex, y, 3.2, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

/** Static castle spike strip (always visible, never timed). */
export function drawSpikes(ctx: CanvasRenderingContext2D, x: number, y: number, w: number) {
  ctx.save();
  ctx.lineJoin = "round";
  ctx.lineWidth = 2;
  ctx.strokeStyle = "#0d0a18";
  const n = Math.max(2, Math.round(w / 9));
  for (let i = 0; i < n; i++) {
    const sx = x + (i * w) / n;
    const g = ctx.createLinearGradient(sx, y, sx + w / n, y - 16);
    g.addColorStop(0, "#8e93ad");
    g.addColorStop(1, "#e8ecff");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(sx, y);
    ctx.lineTo(sx + w / n / 2, y - 15 - (i % 2) * 2);
    ctx.lineTo(sx + w / n, y);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }
  ctx.restore();
}

/** Swinging blade trap: pivot at (x, y), a = current angle, len = rope length. */
export function drawBlade(ctx: CanvasRenderingContext2D, x: number, y: number, a: number, len: number) {
  ctx.save();
  ctx.translate(x, y);
  ctx.strokeStyle = "rgba(220,210,240,0.85)";
  ctx.lineWidth = 2.4;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(Math.sin(a) * len, Math.cos(a) * len);
  ctx.stroke();
  ctx.fillStyle = "#4a4560";
  ctx.beginPath();
  ctx.arc(0, 0, 5, 0, Math.PI * 2);
  ctx.fill();
  ctx.translate(Math.sin(a) * len, Math.cos(a) * len);
  ctx.rotate(a);
  ctx.fillStyle = "#dfe6ff";
  ctx.strokeStyle = "#0d0a18";
  ctx.lineWidth = 2.2;
  ctx.beginPath();
  ctx.moveTo(-13, -3);
  ctx.lineTo(13, -3);
  ctx.quadraticCurveTo(17, 6, 0, 11);
  ctx.quadraticCurveTo(-17, 6, -13, -3);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = "#ff6a4d";
  ctx.beginPath();
  ctx.arc(0, -1, 2.6, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

/** The Warden: final-world boss that rises from the lava. open = jaw 0..1, hurt = flash 0..1. */
export function drawBoss(ctx: CanvasRenderingContext2D, x: number, y: number, t: number, open: number, hurt: number) {
  ctx.save();
  ctx.translate(x, y + Math.sin(t * 1.6) * 4);
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  // heat aura
  const aura = ctx.createRadialGradient(0, -26, 8, 0, -26, 84);
  aura.addColorStop(0, `rgba(255,110,40,${0.42 + 0.1 * Math.sin(t * 4)})`);
  aura.addColorStop(1, "rgba(255,60,20,0)");
  ctx.fillStyle = aura;
  ctx.beginPath();
  ctx.arc(0, -26, 84, 0, Math.PI * 2);
  ctx.fill();
  const S = 1 + hurt * 0.08;
  ctx.scale(S, S);
  ctx.lineWidth = 3;
  ctx.strokeStyle = "#12040f";
  // horns
  for (const side of [-1, 1]) {
    ctx.fillStyle = "#3a2a3f";
    ctx.beginPath();
    ctx.moveTo(side * 22, -46);
    ctx.quadraticCurveTo(side * 46, -60, side * 40, -84);
    ctx.quadraticCurveTo(side * 26, -66, side * 12, -52);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }
  // skull
  const g = ctx.createLinearGradient(0, -66, 0, 6);
  g.addColorStop(0, hurt > 0 ? "#fff3d0" : "#6b5a72");
  g.addColorStop(1, hurt > 0 ? "#ffd08a" : "#2f2438");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.moveTo(-30, -20);
  ctx.quadraticCurveTo(-34, -58, 0, -62);
  ctx.quadraticCurveTo(34, -58, 30, -20);
  ctx.quadraticCurveTo(20, -6, 0, -8);
  ctx.quadraticCurveTo(-20, -6, -30, -20);
  ctx.fill();
  ctx.stroke();
  // eyes
  for (const side of [-1, 1]) {
    ctx.fillStyle = "#0d0510";
    ctx.beginPath();
    ctx.ellipse(side * 14, -38, 8, 9.5, side * 0.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    const eg = ctx.createRadialGradient(side * 14, -38, 1, side * 14, -38, 7);
    eg.addColorStop(0, "#fff2b0");
    eg.addColorStop(0.4, "#ff9a3c");
    eg.addColorStop(1, "rgba(224,49,15,0)");
    ctx.fillStyle = eg;
    ctx.beginPath();
    ctx.arc(side * 14, -38, 7 + open * 2, 0, Math.PI * 2);
    ctx.fill();
  }
  // snout
  ctx.fillStyle = "#22162b";
  ctx.beginPath();
  ctx.moveTo(-8, -26);
  ctx.lineTo(8, -26);
  ctx.lineTo(4, -16);
  ctx.lineTo(-4, -16);
  ctx.closePath();
  ctx.fill();
  // jaw (opens when it charges a breath)
  ctx.save();
  ctx.translate(0, -10);
  ctx.rotate(open * 0.5);
  ctx.fillStyle = "#4a3550";
  ctx.strokeStyle = "#12040f";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(-26, 0);
  ctx.lineTo(26, 0);
  ctx.lineTo(20, 16);
  ctx.quadraticCurveTo(0, 24, -20, 16);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = "#efe6ff";
  for (let i = -2; i <= 2; i++) {
    ctx.beginPath();
    ctx.moveTo(i * 9 - 3, 1);
    ctx.lineTo(i * 9, -6);
    ctx.lineTo(i * 9 + 3, 1);
    ctx.closePath();
    ctx.fill();
  }
  // throat fire
  if (open > 0.25) {
    const fg = ctx.createRadialGradient(0, 4, 1, 0, 4, 20);
    fg.addColorStop(0, "#fff6c0");
    fg.addColorStop(0.5, "#ff9a3c");
    fg.addColorStop(1, "rgba(224,49,15,0)");
    ctx.fillStyle = fg;
    ctx.beginPath();
    ctx.arc(0, 4, 20 * open, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
  ctx.restore();
}
