import type { ReactNode } from "react";

interface IconProps {
  className?: string;
}

const base = {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2.4,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
};

export function CoinIcon({ className = "h-6 w-6" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
      <defs>
        <linearGradient id="coinG" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#fff08a" />
          <stop offset="1" stopColor="#f59e0b" />
        </linearGradient>
      </defs>
      <circle cx="12" cy="12" r="10" fill="url(#coinG)" stroke="#5a3300" strokeWidth="2" />
      <circle cx="12" cy="12" r="6" fill="none" stroke="#b36b00" strokeWidth="1.6" />
      <path d="M12 8.5v7M10.2 10.2h2.8a1.2 1.2 0 010 2.4h-2a1.2 1.2 0 000 2.4h2.8" stroke="#b36b00" strokeWidth="1.2" fill="none" strokeLinecap="round" />
    </svg>
  );
}

function Slash() {
  return (
    <>
      <line x1="3" y1="21" x2="21" y2="3" stroke="#1b0a3d" strokeWidth="5.5" />
      <line x1="3" y1="21" x2="21" y2="3" stroke="#ff5a6a" strokeWidth="2.6" />
    </>
  );
}

export function MusicIcon({ muted = false, className = "h-6 w-6" }: IconProps & { muted?: boolean }) {
  return (
    <svg {...base} className={className} aria-hidden="true">
      <path d="M9 18V5l11-2v13" />
      <circle cx="6" cy="18" r="3" fill="currentColor" />
      <circle cx="17" cy="16" r="3" fill="currentColor" />
      {muted && <Slash />}
    </svg>
  );
}

export function SoundIcon({ muted = false, className = "h-6 w-6" }: IconProps & { muted?: boolean }) {
  return (
    <svg {...base} className={className} aria-hidden="true">
      <path d="M4 9.5v5h3.5L12 18.5v-13L7.5 9.5z" fill="currentColor" />
      {!muted && (
        <>
          <path d="M15.5 9a4 4 0 010 6" />
          <path d="M18.3 6.3a8 8 0 010 11.4" />
        </>
      )}
      {muted && <Slash />}
    </svg>
  );
}

export function SlidersIcon({ className = "h-6 w-6" }: IconProps) {
  return (
    <svg {...base} className={className} aria-hidden="true">
      <path d="M4 7h9M17 7h3M4 17h3M11 17h9" />
      <circle cx="15" cy="7" r="2.5" fill="currentColor" />
      <circle cx="9" cy="17" r="2.5" fill="currentColor" />
    </svg>
  );
}

export function PauseIcon({ className = "h-6 w-6" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden="true">
      <rect x="5.5" y="4.5" width="4.5" height="15" rx="1.5" />
      <rect x="14" y="4.5" width="4.5" height="15" rx="1.5" />
    </svg>
  );
}

export function HomeIcon({ className = "h-6 w-6" }: IconProps) {
  return (
    <svg {...base} className={className} aria-hidden="true">
      <path d="M3.5 11L12 4l8.5 7" />
      <path d="M6 10v9.5h4.5v-5h3v5H18V10" fill="currentColor" />
    </svg>
  );
}

export function RestartIcon({ className = "h-6 w-6" }: IconProps) {
  return (
    <svg {...base} strokeWidth={3} className={className} aria-hidden="true">
      <path d="M20 12a8 8 0 11-2.6-5.9" />
      <path d="M20 3.5v5h-5" />
    </svg>
  );
}

export function PlayIcon({ className = "h-6 w-6" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" aria-hidden="true">
      <path d="M7 4.5v15l12-7.5z" />
    </svg>
  );
}

export function TrophyIcon({ className = "h-6 w-6" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" fill="none" strokeLinecap="round" strokeLinejoin="round">
      <path d="M7 4h10v5a5 5 0 01-10 0z" fill="#ffc61f" stroke="#5a2f00" strokeWidth="2" />
      <path d="M7 6H4v1.5A3.5 3.5 0 007.5 11M17 6h3v1.5a3.5 3.5 0 01-3.5 3.5" stroke="#ffc61f" strokeWidth="2" />
      <path d="M12 14v3.5M8.5 20h7M9.5 17.5h5" stroke="#ffc61f" strokeWidth="2.4" />
    </svg>
  );
}

export function FlameIcon({ className = "h-6 w-6" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
      <path
        d="M12 2.5c.6 3.2 4.8 5.3 4.8 10A4.8 4.8 0 0112 17.3a4.8 4.8 0 01-4.8-4.8c0-1.9.9-3 1.7-4 .3 1.4 1 2.1 1.6 2.4C10.2 8 10.6 5 12 2.5z"
        fill="#ff7a18"
        stroke="#5a1a00"
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      <path d="M12 11.5c.4 1.4 1.9 2 1.9 3.4a1.9 1.9 0 01-3.8 0c0-1 .8-1.5 1.1-2.3.3.4.6.5.8.5z" fill="#ffd23f" />
    </svg>
  );
}

export function GiftIcon({ className = "h-6 w-6" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" fill="none" strokeLinejoin="round" strokeLinecap="round">
      <rect x="3.5" y="9" width="17" height="11" rx="2" fill="#e63946" stroke="#4a0a12" strokeWidth="2" />
      <rect x="2.5" y="6.5" width="19" height="4" rx="1.5" fill="#ff5a66" stroke="#4a0a12" strokeWidth="2" />
      <path d="M12 6.5V20" stroke="#ffd23f" strokeWidth="3" />
      <path d="M12 6.5C10 2.5 6.5 3.5 7.5 5.5c.6 1.2 2.8 1 4.5 1zM12 6.5c2-4 5.5-3 4.5-1-.6 1.2-2.8 1-4.5 1z" fill="#ffd23f" stroke="#4a0a12" strokeWidth="1.6" />
    </svg>
  );
}

export function CloseIcon({ className = "h-5 w-5" }: IconProps) {
  return (
    <svg {...base} strokeWidth={3.2} className={className} aria-hidden="true">
      <path d="M6 6l12 12M18 6L6 18" />
    </svg>
  );
}

export function CheckIcon({ className = "h-5 w-5" }: IconProps) {
  return (
    <svg {...base} strokeWidth={4} className={className} aria-hidden="true">
      <path d="M5 12.5l4.5 4.5L19 7.5" />
    </svg>
  );
}

export function IconWrap({ children }: { children: ReactNode }) {
  return <span className="inline-flex items-center justify-center">{children}</span>;
}

export function ShopIcon({ className = "h-6 w-6" }: IconProps) {
  return (
    <svg {...base} className={className} aria-hidden="true">
      <path d="M5 8h14l-1 12H6z" fill="currentColor" fillOpacity="0.25" />
      <path d="M9 11V7a3 3 0 016 0v4" />
    </svg>
  );
}

export function MissionsIcon({ className = "h-6 w-6" }: IconProps) {
  return (
    <svg {...base} className={className} aria-hidden="true">
      <rect x="5" y="4.5" width="14" height="16.5" rx="2.5" fill="currentColor" fillOpacity="0.25" />
      <path d="M9 4.5V3.5h6v1" />
      <path d="M8.5 12.5l2.2 2.2 4.3-4.6" />
      <path d="M9 18h6" />
    </svg>
  );
}

export function LockIcon({ className = "h-5 w-5" }: IconProps) {
  return (
    <svg {...base} strokeWidth={2.6} className={className} aria-hidden="true">
      <rect x="5" y="10.5" width="14" height="10" rx="2.5" fill="currentColor" />
      <path d="M8 10.5V8a4 4 0 018 0v2.5" />
    </svg>
  );
}

export function StarIcon({ className = "h-5 w-5" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
      <path d="M12 2.8l2.8 5.9 6.4.8-4.7 4.4 1.2 6.4L12 17.2l-5.7 3.1 1.2-6.4-4.7-4.4 6.4-.8z" fill="#ffd62e" stroke="#5a2f00" strokeWidth="1.8" strokeLinejoin="round" />
    </svg>
  );
}

export function GlobeIcon({ className = "h-6 w-6" }: IconProps) {
  return (
    <svg {...base} className={className} aria-hidden="true">
      <circle cx="12" cy="12" r="8.5" fill="currentColor" fillOpacity="0.2" />
      <path d="M3.5 12h17" />
      <path d="M12 3.5c2.6 2.4 3.9 5.3 3.9 8.5S14.6 18.6 12 20.5c-2.6-1.9-3.9-5.3-3.9-8.5S9.4 5.9 12 3.5z" />
    </svg>
  );
}
