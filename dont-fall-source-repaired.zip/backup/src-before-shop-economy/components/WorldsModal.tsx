import { WORLDS, WORLD_COUNT, WORLD_LEN } from "../game/worlds";
import type { SaveData } from "../game/storage";
import { CheckIcon, CoinIcon, FlameIcon, LockIcon, PlayIcon, StarIcon } from "./Icons";
import { Modal } from "./Modal";

interface Props {
  save: SaveData;
  onPlayAt: (meters: number) => void;
  onClose: () => void;
}

/** All twelve worlds: how to unlock each one, how far you got, and a fast-start for unlocked ones. */
export function WorldsModal({ save, onPlayAt, onClose }: Props) {
  const best = save.best;
  const reached = save.stats.highestWorld;
  const current = Math.min(WORLD_COUNT - 1, Math.floor(best / WORLD_LEN)); // where the last best run ended

  return (
    <Modal title={`Worlds · ${Math.min(WORLD_COUNT, reached + 1)}/${WORLD_COUNT}`} onClose={onClose} tall noScroll>
      <div className="shrink-0 border-b-2 border-white/10 px-3 py-2">
        <p className="text-center text-[0.84rem] font-medium leading-snug text-violet-100">
          Every world is {WORLD_LEN} m tall. Climb into a world to unlock it — then start from it here.
        </p>
      </div>
      <div className="scroll-thin min-h-0 flex-1 overflow-y-auto p-2.5">
        <ul className="flex flex-col gap-2">
          {WORLDS.map((w, i) => {
            const start = i * WORLD_LEN;
            const end = start + WORLD_LEN;
            const unlocked = i === 0 || best >= start || reached >= i;
            const complete = best >= end;
            const prog = Math.max(0, Math.min(1, (best - start) / WORLD_LEN));
            const isCurrent = i === current;
            return (
              <li
                key={w.id}
                data-world={w.id}
                className={`flex items-center gap-2 rounded-2xl border-2 p-2 transition-[transform,filter] duration-150 ${
                  unlocked ? "border-white/15 bg-black/35 hover:brightness-125" : "border-white/10 bg-black/20"
                } ${i === current ? "ring-2 ring-[#ffd62e]/70" : ""}`}
                style={unlocked ? { borderColor: w.accent + "66", animation: i === current ? "herePulse 2.2s ease-in-out infinite" : undefined } : undefined}
              >
                {/* world badge */}
                <span
                  className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border-2 border-[#1b0a3d] font-display text-[1.15rem] text-white"
                  style={{ background: unlocked ? `linear-gradient(180deg,${w.accent},${w.accent}55)` : "#31244a", color: unlocked ? "#1b0a3d" : "#a698c4" }}
                >
                  {i + 1}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <span className="truncate font-display text-[clamp(0.92rem,4.4vw,1.05rem)] leading-none tracking-wide text-white">{w.name}</span>
                    {isCurrent && <span className="shrink-0 rounded-full bg-[#ffd62e] px-1.5 py-0.5 text-[0.55rem] font-bold uppercase tracking-wider text-[#3b1a00]">here</span>}
                    {i === WORLD_COUNT - 1 && (
                      <span className="flex shrink-0 items-center gap-0.5 rounded-full bg-[#8c1f1f] px-1.5 py-0.5 text-[0.58rem] font-bold uppercase tracking-wider text-white">
                        <FlameIcon className="h-3 w-3" /> Boss
                      </span>
                    )}
                    {complete && <CheckIcon className="h-4 w-4 shrink-0 text-emerald-300" />}
                  </div>
                  <div className="mt-1 truncate text-[0.76rem] font-medium text-violet-100">{unlocked ? w.subtitle : `Unlock: climb to ${(start + 1).toLocaleString()} m`}</div>
                  <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-black/50">
                    <div className="h-full rounded-full" style={{ width: `${prog * 100}%`, background: unlocked ? w.accent : "#5a4a7a" }} />
                  </div>
                  <div className="mt-1 flex items-center justify-between gap-1.5 text-[0.66rem] font-semibold tabular-nums text-violet-200" data-prog>
                  <span className="whitespace-nowrap">{(start + 1).toLocaleString()}–{end.toLocaleString()} m</span>
                  <span className="truncate text-right">{complete ? "Cleared" : unlocked ? `Best ${best.toLocaleString()} m` : `Locked · ${Math.round(prog * 100)}%`}</span>
                  </div>
                  </div>
                {/* action */}
                {!unlocked ? (
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-black/45 text-violet-300">
                    <LockIcon className="h-5 w-5" />
                  </span>
                ) : (
                  <button
                    className="btn btn-play btn-sm shrink-0 gap-1 px-2.5 text-[0.9rem]"
                    style={{ minWidth: 66 }}
                    onClick={() => onPlayAt(start)}
                    aria-label={`Start climbing in ${w.name}`}
                  >
                    {i === 0 ? <PlayIcon className="h-4 w-4" /> : <StarIcon className="h-4 w-4" />}
                    {i === 0 ? "PLAY" : "HERE"}
                  </button>
                )}
              </li>
            );
          })}
        </ul>
        <div className="mt-3 flex items-center justify-center gap-1.5 text-[0.78rem] font-semibold text-violet-200">
          <CoinIcon className="h-4 w-4" /> Coins, characters and achievements are never reset by world unlocks.
        </div>
      </div>
    </Modal>
  );
}
