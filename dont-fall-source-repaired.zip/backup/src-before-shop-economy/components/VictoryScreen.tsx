import type { Completed } from "../game/progression";
import { SECRET_SKIN } from "../game/skins";
import { CoinIcon, HomeIcon, PlayIcon, RestartIcon, StarIcon, TrophyIcon } from "./Icons";
import { SkinPreview } from "./SkinPreview";
import { StackedTitle } from "./StackedTitle";

export interface VictoryResult {
  distance: number;
  score: number;
  coins: number;
  fightTime: number;
  reward: number;
  firstVictory: boolean;
  completed: Completed[];
}

export function VictoryScreen({ result: r, onReplay, onEndless, onMenu }: { result: VictoryResult; onReplay: () => void; onEndless: () => void; onMenu: () => void }) {
  return (
    <div
      className="fade-in absolute inset-0 z-20 flex flex-col overflow-y-auto px-5"
      style={{
        background: "radial-gradient(ellipse at 50% 35%, rgba(135,55,20,0.9), rgba(20,5,35,0.96))",
        paddingTop: "max(14px, env(safe-area-inset-top))",
        paddingBottom: "max(16px, env(safe-area-inset-bottom))",
      }}
      role="dialog"
      aria-label="You win"
    >
      <div className="m-auto flex w-full max-w-[350px] flex-col items-center gap-[min(1.8dvh,14px)]">
        <StackedTitle lines={["YOU", "WIN!"]} label="You Win" />
        <div className="pop-in panel flex w-full flex-col items-center gap-2.5 rounded-3xl border-[#ffd166]/70 px-3.5 py-3">
          <div className="flex items-center gap-2 font-display text-[1.15rem] tracking-wide text-[#ffd166] text-outline">
            <TrophyIcon className="h-7 w-7" /> DRAGON DEFEATED
          </div>
          <div className="grid w-full grid-cols-3 gap-2">
            <div className="flex flex-col items-center gap-1 rounded-2xl bg-black/30 py-2">
              <span className="panel-label">Distance</span>
              <span className="value-text text-[1.15rem] leading-none tabular-nums">{r.distance.toLocaleString()} m</span>
            </div>
            <div className="flex flex-col items-center gap-1 rounded-2xl bg-black/30 py-2">
              <span className="panel-label">Fight</span>
              <span className="value-text text-[1.15rem] leading-none tabular-nums">{r.fightTime.toFixed(1)}s</span>
            </div>
            <div className="flex flex-col items-center gap-1 rounded-2xl bg-black/30 py-2">
              <span className="panel-label">Score</span>
              <span className="value-text text-[1.15rem] leading-none tabular-nums">{r.score.toLocaleString()}</span>
            </div>
          </div>
          <div className="flex items-center gap-2 rounded-2xl border-2 border-[#5a2f00] bg-gradient-to-b from-[#fff29a] to-[#ffb300] px-4 py-2 font-display text-[1.25rem] text-[#3b1a00]">
            <CoinIcon className="h-8 w-8" /> FINAL REWARD +{r.reward.toLocaleString()}
          </div>
          {r.firstVictory && (
            <div className="flex w-full items-center gap-3 rounded-2xl border-2 border-[#ffd166]/70 bg-[#3c1a35] p-2.5" data-testid="secret-unlock">
              <div className="h-[82px] w-[82px] shrink-0">
                <SkinPreview skin={SECRET_SKIN} animated scene />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 font-display text-[1.05rem] leading-tight text-[#ffd166]">
                  <StarIcon className="h-5 w-5" /> SECRET CHARACTER
                </div>
                <div className="mt-1 font-display text-[1.3rem] leading-none text-white">{SECRET_SKIN.name}</div>
                <div className="mt-1 text-[0.78rem] font-semibold text-violet-100">Unlocked forever — select it in the shop.</div>
              </div>
            </div>
          )}
          {r.completed.length > 0 && (
            <div className="text-center text-[0.82rem] font-semibold text-violet-100">
              {r.completed.length} mission / achievement reward{r.completed.length === 1 ? "" : "s"} also earned
            </div>
          )}
        </div>
        <div className="pop-in flex w-full flex-col gap-3">
          <button className="btn btn-play min-h-[64px] gap-2.5 text-[1.65rem]" onClick={onReplay}>
            <RestartIcon className="h-7 w-7" /> FIGHT AGAIN
          </button>
          <button className="btn btn-blue min-h-[50px] gap-2 text-[1.05rem]" onClick={onEndless} aria-label="Start endless mode">
            <PlayIcon className="h-5 w-5" /> ENDLESS MODE
          </button>
          <button className="btn btn-purple min-h-[54px] gap-2 text-[1.2rem]" onClick={onMenu}>
            <HomeIcon className="h-6 w-6" /> MAIN MENU
          </button>
        </div>
      </div>
    </div>
  );
}
