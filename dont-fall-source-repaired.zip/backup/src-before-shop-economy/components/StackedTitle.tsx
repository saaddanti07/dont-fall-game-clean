interface Props {
  lines: string[];
  label?: string;
  small?: boolean;
  className?: string;
}

/** Big cartoon title: yellow/orange gradient fill, dark outline and soft shadow. Last line is larger. */
export function StackedTitle({ lines, label, small, className = "" }: Props) {
  return (
    <h1 className={`title ${small ? "sm" : ""} ${className}`} aria-label={label ?? lines.join(" ")}>
      {lines.map((line, i) => (
        <span key={line} className={`title-word ${i === lines.length - 1 && lines.length > 1 ? "big" : ""}`} aria-hidden="true">
          <span className="title-back">{line}</span>
          <span className="title-front">{line}</span>
        </span>
      ))}
    </h1>
  );
}
