import { useEffect, useRef } from "react";
import { drawCoin, drawPlatform, drawPlayer } from "../game/sprites";
import type { Skin } from "../game/skins";

interface Props {
  skin: Skin;
  animated?: boolean;
  /** draw a ledge + glow behind the hero (shop preview / menu) */
  scene?: boolean;
  className?: string;
  label?: string;
  /** render as a dark mystery silhouette (same character, same pose, no colours) */
  silhouette?: boolean;
}

const S = 220;

function draw(ctx: CanvasRenderingContext2D, skin: Skin, t: number, animated: boolean, scene: boolean) {
  ctx.clearRect(0, 0, S, S);
  const groundY = scene ? 178 : 190;
  if (scene) {
    const glow = ctx.createRadialGradient(S / 2, 110, 8, S / 2, 110, 110);
    glow.addColorStop(0, "rgba(190,130,255,0.55)");
    glow.addColorStop(1, "rgba(190,130,255,0)");
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, S, S);
    ctx.save();
    ctx.translate(S / 2, groundY);
    ctx.scale(1.7, 1.7);
    drawPlatform(ctx, -38, 0, 76, "normal");
    ctx.restore();
  }
  const ph = animated ? (t * 1.5) % 1 : 0;
  const h = animated ? Math.sin(ph * Math.PI) * 26 : 0;
  const stretch = animated ? (ph < 0.08 || ph > 0.92 ? 0.84 : 1 + Math.sin(ph * Math.PI) * 0.08) : 1;
  if (scene) {
    ctx.fillStyle = "rgba(20,5,40,0.35)";
    ctx.beginPath();
    ctx.ellipse(S / 2, groundY + 2, 30 - h * 0.3, 5, 0, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.save();
  ctx.translate(S / 2, groundY - h);
  ctx.scale(2.35, 2.35);
  drawPlayer(ctx, 0, 0, 1, stretch, animated ? t * 2 : 0, skin);
  ctx.restore();
  if (scene && animated) {
    drawCoin(ctx, 34, 90 + Math.sin(t * 2.2) * 6, 11, t * 3);
    drawCoin(ctx, 188, 70 + Math.sin(t * 2.2 + 2) * 6, 11, t * 3 + 1.5);
  }
}

export function SkinPreview({ skin, animated = false, scene = false, className = "", label, silhouette = false }: Props) {
  const ref = useRef<HTMLCanvasElement>(null);
  const offRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = ref.current!;
    const ctx = canvas.getContext("2d")!;
    canvas.width = S;
    canvas.height = S;

    if (silhouette) {
      // draw the ORIGINAL character offscreen, then recolour its exact shape to a dark fill
      if (!offRef.current) {
        offRef.current = document.createElement("canvas");
        offRef.current.width = S;
        offRef.current.height = S;
      }
      const off = offRef.current;
      const octx = off.getContext("2d")!;
      const paint = (t: number) => {
        octx.clearRect(0, 0, S, S);
        draw(octx, skin, t, animated, false);
        octx.globalCompositeOperation = "source-in";
        const g = octx.createLinearGradient(0, 0, 0, S);
        g.addColorStop(0, "#342154");
        g.addColorStop(1, "#140a24");
        octx.fillStyle = g;
        octx.fillRect(0, 0, S, S);
        octx.globalCompositeOperation = "source-over";
        ctx.clearRect(0, 0, S, S);
        ctx.drawImage(off, 0, 0);
      };
      if (!animated) {
        paint(0);
        return;
      }
      let raf = 0;
      const start = performance.now();
      const loop = (now: number) => {
        paint((now - start) / 1000);
        raf = requestAnimationFrame(loop);
      };
      raf = requestAnimationFrame(loop);
      return () => cancelAnimationFrame(raf);
    }

    if (!animated) {
      draw(ctx, skin, 0, false, scene);
      return;
    }
    let raf = 0;
    const start = performance.now();
    const loop = (now: number) => {
      draw(ctx, skin, (now - start) / 1000, true, scene);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [skin, animated, scene, silhouette]);

  return <canvas ref={ref} className={`block h-full w-full object-contain ${className}`} role="img" aria-label={label ?? skin.name} />;
}
