import { CoinIcon } from "./Icons";

export function CoinCounter({ value, prefix = "", label = "Coins" }: { value: number; prefix?: string; label?: string }) {
  return (
    <div className="panel flex h-[46px] items-center gap-2 rounded-2xl py-1 pl-1.5 pr-4" role="status" aria-label={`${label}: ${value}`}>
      <CoinIcon className="h-8 w-8 shrink-0" />
      <span className="value-text text-[1.35rem] leading-none tabular-nums">
        {prefix}
        {value.toLocaleString()}
      </span>
    </div>
  );
}
