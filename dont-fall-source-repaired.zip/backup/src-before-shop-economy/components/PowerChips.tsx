import type { HudPower } from "../game/engine";
import { POWER_COLOR, POWER_NAME, powerIconUrl } from "../game/hazards";

/** Active power-up indicators: icon + shrinking timer bar. */
export function PowerChips({ powers }: { powers: HudPower[] }) {
  if (!powers.length) return null;
  return (
    <div className="mt-2 flex flex-wrap gap-1.5" aria-label="Active power-ups">
      {powers.map((p) => (
        <div key={p.type} className="panel flex items-center gap-1.5 rounded-xl py-1 pl-1 pr-2.5" title={POWER_NAME[p.type]} style={{ borderColor: POWER_COLOR[p.type] + "99" }}>
          <img src={powerIconUrl(p.type)} alt={POWER_NAME[p.type]} className="h-8 w-8 shrink-0" draggable={false} />
          <div className="flex flex-col gap-1">
            <span className="text-[0.62rem] font-bold uppercase leading-none tracking-wider text-white">{POWER_NAME[p.type]}</span>
            <div className="h-1.5 w-[58px] overflow-hidden rounded-full bg-black/60">
              <div className="h-full rounded-full" style={{ width: `${Math.max(0, Math.min(1, p.frac)) * 100}%`, background: POWER_COLOR[p.type] }} />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
