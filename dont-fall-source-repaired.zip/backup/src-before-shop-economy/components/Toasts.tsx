import { CoinIcon, StarIcon } from "./Icons";

export interface Toast {
  id: number;
  title: string;
  sub: string;
  reward?: number;
}

export function Toasts({ items }: { items: Toast[] }) {
  return (
    <div className="pointer-events-none absolute inset-x-0 z-50 flex flex-col items-center gap-2 px-4" style={{ top: "max(12px, calc(env(safe-area-inset-top) + 6px))" }} aria-live="polite">
      {items.map((t) => (
        <div
          key={t.id}
          className="panel flex w-full max-w-[340px] items-center gap-3 rounded-2xl border-[#ffd62e]/60 px-3 py-2"
          style={{ animation: "toastIn 3.6s ease forwards", background: "rgba(40,16,80,0.95)" }}
        >
          <StarIcon className="h-8 w-8 shrink-0" />
          <div className="min-w-0 flex-1">
            <div className="truncate font-display text-[1.05rem] leading-tight text-[#ffd62e]">{t.title}</div>
            <div className="truncate text-[0.82rem] font-medium text-violet-100">{t.sub}</div>
          </div>
          {t.reward ? (
            <span className="flex shrink-0 items-center gap-1 font-display text-[1.05rem] text-white">
              <CoinIcon className="h-5 w-5" />+{t.reward}
            </span>
          ) : null}
        </div>
      ))}
    </div>
  );
}
