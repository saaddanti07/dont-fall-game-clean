import type { ReactNode } from "react";
import { CloseIcon } from "./Icons";

interface Props {
  title: string;
  onClose: () => void;
  children: ReactNode;
  tall?: boolean;
  noScroll?: boolean;
}

export function Modal({ title, onClose, children, tall, noScroll }: Props) {
  return (
    <div
      className="fade-in absolute inset-0 z-30 flex items-center justify-center p-4"
      style={{ background: "rgba(8,2,18,0.78)", paddingTop: "max(16px, env(safe-area-inset-top))", paddingBottom: "max(16px, env(safe-area-inset-bottom))" }}
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label={title}
    >
      <div
        className={`pop-in relative flex w-full flex-col overflow-hidden rounded-3xl border-4 border-[#1b0a3d] ${tall ? "h-full max-h-[740px]" : "max-h-full"}`}
        style={{ background: "linear-gradient(180deg,#3d1b78 0%,#26104c 100%)", boxShadow: "0 8px 0 #12041f, 0 0 40px rgba(150,90,255,0.35)" }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between gap-3 border-b-2 border-white/10 px-4 py-3">
          <h2 className="font-display text-[1.6rem] leading-none tracking-wide text-[#ffd62e] text-outline">{title}</h2>
          <button
            onClick={onClose}
            aria-label="Close"
            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border-[3px] border-[#1b0a3d] bg-gradient-to-b from-[#ff7a85] to-[#d62839] text-white shadow-[0_3px_0_#4a0a12] active:translate-y-0.5"
          >
            <CloseIcon />
          </button>
        </div>
        <div className={noScroll ? "flex min-h-0 flex-1 flex-col overflow-hidden" : "min-h-0 overflow-y-auto p-4"}>{children}</div>
      </div>
    </div>
  );
}
