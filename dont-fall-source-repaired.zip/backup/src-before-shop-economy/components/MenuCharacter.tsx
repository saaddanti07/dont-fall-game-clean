import { useEffect, useRef } from "react";
import { drawCoin, drawPlatform, drawPlayer } from "../game/sprites";
import type { Skin } from "../game/skins";

/** The equipped adventurer bouncing on a stone ledge (same drawing code as the game; default = original hero). */
export function MenuCharacter({ skin }: { skin: Skin }) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current!;
    const ctx = canvas.getContext("2d")!;
    let raf = 0;
    const start = performance.now();
    const S = 400;
    canvas.width = S;
    canvas.height = S;

    const loop = (now: number) => {
      const t = (now - start) / 1000;
      ctx.clearRect(0, 0, S, S);

      // glow behind the hero
      const glow = ctx.createRadialGradient(200, 190, 10, 200, 190, 190);
      glow.addColorStop(0, "rgba(190,130,255,0.5)");
      glow.addColorStop(1, "rgba(190,130,255,0)");
      ctx.fillStyle = glow;
      ctx.fillRect(0, 0, S, S);

      const groundY = 335;
      // ledge
      ctx.save();
      ctx.translate(200, groundY);
      ctx.scale(2.6, 2.6);
      drawPlatform(ctx, -40, 0, 80, "normal");
      ctx.restore();

      // bounce
      const ph = (t * 1.5) % 1; // 0..1
      const h = Math.sin(ph * Math.PI) * 55;
      const stretch = ph < 0.08 || ph > 0.92 ? 0.82 : 1 + Math.sin(ph * Math.PI) * 0.08;

      // shadow
      ctx.fillStyle = "rgba(20,5,40,0.35)";
      ctx.beginPath();
      ctx.ellipse(200, groundY + 2, 46 - h * 0.25, 7 - h * 0.05, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.save();
      ctx.translate(200, groundY - h);
      ctx.scale(4.2, 4.2);
      drawPlayer(ctx, 0, 0, 1, stretch, t * 2, skin);
      ctx.restore();

      // floating coins
      drawCoin(ctx, 70, 170 + Math.sin(t * 2.2) * 8, 15, t * 3);
      drawCoin(ctx, 336, 130 + Math.sin(t * 2.2 + 2) * 8, 15, t * 3 + 1.5);
      drawCoin(ctx, 322, 250 + Math.sin(t * 2.2 + 4) * 8, 11, t * 3 + 3);

      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [skin]);

  return <canvas ref={ref} className="absolute inset-0 h-full w-full object-contain" aria-label="Adventurer hero" role="img" />;
}
