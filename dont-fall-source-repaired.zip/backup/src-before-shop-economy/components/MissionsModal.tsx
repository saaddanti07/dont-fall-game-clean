import { useState } from "react";
import { ACHIEVEMENTS, defOf, formatProgress } from "../game/progression";
import { ALL_SKINS } from "../game/skins";
import type { MissionState, SaveData } from "../game/storage";
import { msUntilTomorrow } from "../game/storage";
import { WORLDS } from "../game/worlds";
import { CheckIcon, CoinIcon, LockIcon, TrophyIcon } from "./Icons";
import { Modal } from "./Modal";

type Tab = "daily" | "weekly" | "awards" | "records";
const TABS: { id: Tab; label: string }[] = [
  { id: "daily", label: "Daily" },
  { id: "weekly", label: "Weekly" },
  { id: "awards", label: "Awards" },
  { id: "records", label: "Records" },
];

function MissionRow({ m }: { m: MissionState }) {
  const def = defOf(m.id);
  if (!def) return null;
  const pct = Math.min(100, (m.progress / def.target) * 100);
  return (
    <div className={`rounded-2xl border-2 p-3 ${m.done ? "border-emerald-400/70 bg-[#1d4a46]" : "border-white/12 bg-black/30"}`}>
      <div className="flex items-start justify-between gap-2">
        <span className="text-[1rem] font-semibold leading-snug text-white">{def.title}</span>
        <span className={`flex shrink-0 items-center gap-1 rounded-full px-2 py-0.5 font-display text-[0.95rem] ${m.done ? "bg-emerald-400 text-[#06361b]" : "bg-black/40 text-white"}`}>
          {m.done ? <CheckIcon className="h-4 w-4" /> : <CoinIcon className="h-5 w-5" />}
          {m.done ? "DONE" : `+${def.reward}`}
        </span>
      </div>
      <div className="mt-2.5 h-3 overflow-hidden rounded-full bg-black/50">
        <div className={`h-full rounded-full ${m.done ? "bg-emerald-400" : "bg-gradient-to-r from-[#ffd62e] to-[#ff9f1c]"}`} style={{ width: `${pct}%` }} />
      </div>
      <div className="mt-1.5 text-[0.8rem] font-semibold tabular-nums text-violet-100">{formatProgress(def, m.progress)}</div>
    </div>
  );
}

function resetText(tab: "daily" | "weekly"): string {
  const ms = msUntilTomorrow();
  if (tab === "daily") {
    const h = Math.floor(ms / 3600000);
    const m = Math.floor((ms % 3600000) / 60000);
    return `New missions in ${h}h ${m}m`;
  }
  const dow = (new Date().getDay() + 6) % 7; // Mon=0
  const days = 6 - dow;
  return days === 0 ? `New challenges in ${Math.floor(ms / 3600000)}h` : `New challenges in ${days}d ${Math.floor(ms / 3600000)}h`;
}

export function MissionsModal({ save, onClose }: { save: SaveData; onClose: () => void }) {
  const [tab, setTab] = useState<Tab>("daily");
  const unlocked = Object.keys(save.achievements).length;
  const hrs = Math.floor(save.stats.totalTime / 3600);
  const mins = Math.floor((save.stats.totalTime % 3600) / 60);

  const records: [string, string][] = [
    ["Best distance", `${save.best.toLocaleString()} m`],
    ["Total distance", `${save.stats.totalDistance.toLocaleString()} m`],
    ["Best score", save.stats.bestScore.toLocaleString()],
    ["Total games played", save.stats.games.toLocaleString()],
    ["Total coins collected", save.stats.totalCoins.toLocaleString()],
    ["Highest world reached", `${save.stats.highestWorld + 1}. ${WORLDS[save.stats.highestWorld].name}`],
    ["Total time played", hrs ? `${hrs}h ${mins}m` : `${mins}m ${Math.floor(save.stats.totalTime % 60)}s`],
    ["Platforms landed on", save.stats.totalPlatforms.toLocaleString()],
    ["Power-ups collected", save.stats.totalPowerups.toLocaleString()],
    ["Near misses", save.stats.totalNear.toLocaleString()],
    ["Characters owned", `${save.owned.length} / ${ALL_SKINS.length}`],
    ["Achievements", `${unlocked} / ${ACHIEVEMENTS.length}`],
    ["Dragon victories", save.dragon.wins.toLocaleString()],
    ["Best Dragon fight", save.dragon.bestTime > 0 ? `${save.dragon.bestTime.toFixed(1)}s` : "—"],
  ];

  return (
    <Modal title="Missions" onClose={onClose} tall noScroll>
      <div className="shrink-0 border-b-2 border-white/10 p-2.5">
        <div className="grid grid-cols-4 gap-1.5" role="tablist">
          {TABS.map((t) => (
            <button
              key={t.id}
              role="tab"
              aria-selected={tab === t.id}
              onClick={() => setTab(t.id)}
              className={`min-h-[44px] rounded-xl border-[3px] px-1 text-[0.82rem] font-bold uppercase tracking-wide ${
                tab === t.id ? "border-[#5a2f00] bg-gradient-to-b from-[#fff29a] to-[#ffb300] text-[#3b1a00]" : "border-[#1b0a3d] bg-[#43336a] text-white"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <div className="scroll-thin min-h-0 flex-1 overflow-y-auto p-3" role="tabpanel">
        {(tab === "daily" || tab === "weekly") && (
          <div className="flex flex-col gap-2.5">
            <p className="text-center text-[0.85rem] font-medium text-violet-100">{tab === "daily" ? "Daily missions" : "Weekly challenges"} · {resetText(tab)}</p>
            {(tab === "daily" ? save.daily.items : save.weekly.items).map((m) => (
              <MissionRow key={m.id} m={m} />
            ))}
            <p className="text-center text-[0.78rem] text-violet-200">Coins are awarded automatically when a mission is completed.</p>
          </div>
        )}

        {tab === "awards" && (
          <div className="flex flex-col gap-2">
            {ACHIEVEMENTS.map((a) => {
              const got = !!save.achievements[a.id];
              return (
                <div key={a.id} className={`flex items-center gap-3 rounded-2xl border-2 p-2.5 ${got ? "border-[#ffd62e]/70 bg-[#4a3a1c]" : "border-white/12 bg-black/30"}`}>
                  <span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${got ? "bg-[#2b1650]" : "bg-black/40 text-violet-300"}`}>{got ? <TrophyIcon className="h-7 w-7" /> : <LockIcon className="h-5 w-5" />}</span>
                  <div className="min-w-0 flex-1">
                    <div className={`text-[0.98rem] font-bold leading-tight ${got ? "text-[#ffd62e]" : "text-white"}`}>{a.title}</div>
                    <div className="text-[0.8rem] font-medium leading-snug text-violet-100">{a.desc}</div>
                  </div>
                  <span className={`flex shrink-0 items-center gap-1 font-display text-[0.95rem] ${got ? "text-emerald-300" : "text-white"}`}>
                    {got ? <CheckIcon className="h-4 w-4" /> : <CoinIcon className="h-5 w-5" />}
                    {got ? "" : `+${a.reward}`}
                  </span>
                </div>
              );
            })}
          </div>
        )}

        {tab === "records" && (
          <div className="flex flex-col gap-1.5">
            {records.map(([k, v]) => (
              <div key={k} className="flex items-center justify-between gap-3 rounded-xl bg-black/30 px-3 py-2.5">
                <span className="text-[0.92rem] font-medium text-violet-100">{k}</span>
                <span className="font-display text-[1.05rem] tabular-nums text-white">{v}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </Modal>
  );
}
