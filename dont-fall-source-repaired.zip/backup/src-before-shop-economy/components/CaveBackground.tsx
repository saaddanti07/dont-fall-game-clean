// Purple cave backdrop used by the menu. Lava is confined to a thin strip at the very bottom
// so no UI text ever sits on top of it.

const EMBERS = [8, 22, 35, 48, 61, 74, 86, 94];

export function CaveBackground() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
      <div className="absolute inset-0" style={{ background: "linear-gradient(180deg,#160629 0%,#2a0f52 45%,#43197a 100%)" }} />

      {/* soft crystal glows */}
      <div className="absolute -left-10 top-[30%] h-56 w-56 rounded-full bg-fuchsia-500/20 blur-3xl" />
      <div className="absolute -right-12 top-[48%] h-60 w-60 rounded-full bg-cyan-400/15 blur-3xl" />

      {/* stalactites */}
      <svg className="absolute left-0 top-0 h-12 w-full" viewBox="0 0 360 48" preserveAspectRatio="none">
        <path
          d="M0 0H360V10L346 8 338 34 328 6 312 4 302 26 292 5 270 3 258 40 246 6 224 4 212 24 200 5 176 3 164 30 152 5 128 3 116 36 104 6 82 4 70 22 58 5 36 3 24 32 12 7 0 9Z"
          fill="#0f0420"
        />
      </svg>

      {/* side rock walls */}
      <div className="absolute inset-y-0 left-0 w-3" style={{ background: "linear-gradient(90deg,#0f0420,transparent)" }} />
      <div className="absolute inset-y-0 right-0 w-3" style={{ background: "linear-gradient(270deg,#0f0420,transparent)" }} />

      {/* rising embers */}
      {EMBERS.map((left, i) => (
        <span
          key={left}
          className="ember absolute bottom-6 h-1.5 w-1.5 rounded-full bg-orange-300"
          style={{
            left: `${left}%`,
            animation: `ember ${6 + (i % 4) * 1.6}s linear ${i * 0.9}s infinite`,
            boxShadow: "0 0 8px 2px rgba(255,140,40,0.7)",
          }}
        />
      ))}

      {/* lava strip */}
      <div className="absolute inset-x-0 bottom-0" style={{ height: "calc(26px + env(safe-area-inset-bottom))" }}>
        <div className="absolute inset-x-0 -top-6 h-6" style={{ background: "linear-gradient(0deg,rgba(255,110,30,0.45),transparent)" }} />
        <div className="absolute inset-0" style={{ background: "linear-gradient(180deg,#ff8a1f 0%,#e0310f 55%,#8c0f08 100%)" }} />
        <div className="lava-wave absolute -top-2 left-0 flex w-[200%]" style={{ animation: "lavaScroll 5s linear infinite" }}>
          {[0, 1].map((k) => (
            <svg key={k} className="h-3 w-1/2" viewBox="0 0 360 12" preserveAspectRatio="none">
              <path d="M0 12V6Q22 0 45 6T90 6T135 6T180 6T225 6T270 6T315 6T360 6V12Z" fill="#ff8a1f" />
              <path d="M0 6Q22 0 45 6T90 6T135 6T180 6T225 6T270 6T315 6T360 6" fill="none" stroke="#ffe28a" strokeWidth="2" />
            </svg>
          ))}
        </div>
      </div>
    </div>
  );
}
