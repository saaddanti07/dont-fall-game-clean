import { MusicIcon, SoundIcon } from "./Icons";

interface Props {
  musicOn: boolean;
  sfxOn: boolean;
  onMusic: () => void;
  onSfx: () => void;
}

/** Two small icon buttons. ON = bright teal; OFF = dark with a red slash through the icon. */
export function AudioToggles({ musicOn, sfxOn, onMusic, onSfx }: Props) {
  return (
    <div className="flex items-center gap-2">
      <button className="icon-btn" data-on={musicOn} onClick={onMusic} aria-pressed={musicOn} aria-label={musicOn ? "Mute music" : "Unmute music"}>
        <MusicIcon muted={!musicOn} />
      </button>
      <button className="icon-btn" data-on={sfxOn} onClick={onSfx} aria-pressed={sfxOn} aria-label={sfxOn ? "Mute sound effects" : "Unmute sound effects"}>
        <SoundIcon muted={!sfxOn} />
      </button>
    </div>
  );
}
