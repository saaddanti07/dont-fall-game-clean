import type { CapacitorConfig } from "@capacitor/cli";

/**
 * Capacitor configuration for DON'T FALL.
 *
 * IMPORTANT: the native fullscreen setup lives in `native-android/` and the
 * GitHub Actions workflow (`.github/workflows/android-apk.yml`) re-applies it
 * every time `cap add android` regenerates the Android project. Keep the
 * appId in sync with the package name in `native-android/MainActivity.kt`.
 */
const config: CapacitorConfig = {
  appId: "com.dontfall.game",
  appName: "DON'T FALL",
  webDir: "dist",
  backgroundColor: "#160629",
  android: {
    allowMixedContent: false,
  },
  server: {
    androidScheme: "https",
  },
};

export default config;
