import type { WorldEvent } from "../game/engine";
import { StackedTitle } from "./StackedTitle";

/** Non-blocking "entering a new world" banner + colour flash. Re-mounts (and re-animates) per world. */
export function WorldBanner({ world }: { world: WorldEvent }) {
  return (
    <>
      <div
        key={`f${world.seg}`}
        className="pointer-events-none absolute inset-0 z-[5]"
        style={{ background: `radial-gradient(circle at 50% 42%, ${world.accent}aa, transparent 72%)`, animation: "worldFlash 1.1s ease-out forwards" }}
      />
      <div
        key={`b${world.seg}`}
        className="pointer-events-none absolute inset-x-0 z-10 flex flex-col items-center gap-1 px-5"
        style={{ top: "max(168px, 27%)", animation: "bannerLife 3s ease forwards" }}
        role="status"
      >
        <span className="rounded-full border-2 border-white/20 bg-black/60 px-3.5 py-1 text-[0.72rem] font-bold uppercase tracking-[0.16em]" style={{ color: world.accent }}>
          {world.label}
        </span>
        <StackedTitle lines={[world.name]} small />
        <div className="text-outline max-w-[320px] text-center text-[0.95rem] font-semibold leading-tight text-white" style={{ textShadow: "0 2px 0 #12041f, 0 0 10px #12041f, 0 0 4px #12041f" }}>{world.subtitle}</div>
      </div>
    </>
  );
}
