// Daily missions, weekly challenges, achievements and end-of-run bookkeeping.

import { WORLDS } from "./worlds";
import { dayKey, weekKey, type MissionState, type SaveData } from "./storage";

export interface RunStats {
  distance: number; // meters
  score: number; // distance + near-miss bonus
  bonus: number;
  coins: number;
  platforms: number;
  time: number; // seconds actually played
  powerups: number;
  nearMisses: number;
  bosses: number; // Warden duels survived
  candies: number; // candy bonuses eaten
  worldSeg: number; // absolute 500 m segment reached
}

export type Metric = "coins" | "distance" | "platforms" | "games" | "time" | "powerups" | "candies";

export interface MissionDef {
  id: string;
  title: string;
  target: number;
  metric: Metric;
  mode: "sum" | "max"; // sum across runs, or best single run
  reward: number;
}

export const DAILY_POOL: MissionDef[] = [
  { id: "d_coins", title: "Collect 30 coins", target: 30, metric: "coins", mode: "sum", reward: 40 },
  { id: "d_dist", title: "Reach 300 meters", target: 300, metric: "distance", mode: "max", reward: 40 },
  { id: "d_plat", title: "Land on 50 platforms", target: 50, metric: "platforms", mode: "sum", reward: 30 },
  { id: "d_games", title: "Play 3 rounds", target: 3, metric: "games", mode: "sum", reward: 30 },
  { id: "d_time", title: "Survive for 2 minutes in total", target: 120, metric: "time", mode: "sum", reward: 50 },
  { id: "d_power", title: "Collect 3 power-ups", target: 3, metric: "powerups", mode: "sum", reward: 40 },
  { id: "d_dist2", title: "Reach 600 meters", target: 600, metric: "distance", mode: "max", reward: 70 },
  { id: "d_candy", title: "Eat 10 candies in the Candy Kingdom", target: 10, metric: "candies", mode: "sum", reward: 60 },
  { id: "d_power2", title: "Collect 6 power-ups", target: 6, metric: "powerups", mode: "sum", reward: 70 },
];

export const WEEKLY_LIST: MissionDef[] = [
  { id: "w_dist", title: "Reach 1000 meters", target: 1000, metric: "distance", mode: "max", reward: 150 },
  { id: "w_coins", title: "Collect 500 coins", target: 500, metric: "coins", mode: "sum", reward: 250 },
  { id: "w_games", title: "Complete 10 games", target: 10, metric: "games", mode: "sum", reward: 100 },
  { id: "w_power", title: "Collect 10 power-ups", target: 10, metric: "powerups", mode: "sum", reward: 120 },
  { id: "w_height", title: "Climb 3,000 meters in total", target: 3000, metric: "distance", mode: "sum", reward: 300 },
];

export interface AchievementDef {
  id: string;
  title: string;
  desc: string;
  reward: number;
  test: (s: SaveData) => boolean;
}

export const ACHIEVEMENTS: AchievementDef[] = [
  { id: "first_jump", title: "First Jump", desc: "Land on your first platform", reward: 10, test: (s) => s.stats.totalPlatforms >= 1 },
  { id: "coin_collector", title: "Coin Collector", desc: "Collect 100 coins in total", reward: 30, test: (s) => s.stats.totalCoins >= 100 },
  { id: "treasure", title: "Treasure Hunter", desc: "Collect 1,000 coins in total", reward: 100, test: (s) => s.stats.totalCoins >= 1000 },
  { id: "cave", title: "Cave Explorer", desc: "Reach 400 m", reward: 25, test: (s) => s.best >= 400 },
  { id: "snow", title: "Snow Survivor", desc: "Reach 900 m", reward: 40, test: (s) => s.best >= 900 },
  { id: "km", title: "Kilometer Club", desc: "Reach 1000 meters", reward: 50, test: (s) => s.best >= 1000 },
  { id: "volcano", title: "Volcano Master", desc: "Reach 1400 m", reward: 60, test: (s) => s.best >= 1400 },
  { id: "forest", title: "Forest Climber", desc: "Reach 1900 m", reward: 80, test: (s) => s.best >= 1900 },
  { id: "desert", title: "Desert Champion", desc: "Reach 2400 m", reward: 100, test: (s) => s.best >= 2400 },
  { id: "sky", title: "Sky Legend", desc: "Reach 2900 m", reward: 150, test: (s) => s.best >= 2900 },
  { id: "endless", title: "Endless Climber", desc: "Reach 3000 meters", reward: 200, test: (s) => s.best >= 3000 },
  { id: "ocean", title: "Depth Diver", desc: "Reach the Underwater Kingdom (3,000 m)", reward: 120, test: (s) => s.best >= 3100 },
  { id: "enchanted", title: "Fairy Friend", desc: "Reach the Enchanted Forest (3,500 m)", reward: 140, test: (s) => s.best >= 3600 },
  { id: "cyber", title: "Netrunner", desc: "Reach Cyber City (4,000 m)", reward: 160, test: (s) => s.best >= 4100 },
  { id: "space", title: "Star Hopper", desc: "Reach Outer Space (4,500 m)", reward: 180, test: (s) => s.best >= 4600 },
  { id: "candy", title: "Sweet Tooth", desc: "Reach the Candy Kingdom (5,000 m)", reward: 200, test: (s) => s.best >= 5100 },
  { id: "sweets", title: "Sugar Rush", desc: "Eat 100 candies in total", reward: 120, test: (s) => s.stats.candies >= 100 },
  { id: "castle", title: "Castle Siege", desc: "Reach the Dark Castle (5,500 m)", reward: 260, test: (s) => s.best >= 5600 },
  { id: "warden", title: "Wardenlayer", desc: "Survive the Warden's duel", reward: 400, test: (s) => s.stats.bosses >= 1 },
  { id: "summit", title: "Summit of the Twelve", desc: "Reach 6000 meters", reward: 300, test: (s) => s.best >= 6000 },
  { id: "regular", title: "Regular", desc: "Play 25 games", reward: 40, test: (s) => s.stats.games >= 25 },
  { id: "power", title: "Power Player", desc: "Collect 10 power-ups", reward: 40, test: (s) => s.stats.totalPowerups >= 10 },
  { id: "near", title: "Close Call", desc: "Make 5 near misses", reward: 40, test: (s) => s.stats.totalNear >= 5 },
  { id: "newlook", title: "New Look", desc: "Own 2 characters", reward: 30, test: (s) => s.owned.length >= 2 },
  { id: "wardrobe", title: "Wardrobe", desc: "Own 5 characters", reward: 100, test: (s) => s.owned.length >= 5 },
  { id: "habit", title: "Daily Habit", desc: "Reach a 3-day reward streak", reward: 50, test: (s) => s.streak >= 3 },
  { id: "time", title: "Time Flies", desc: "Play for 10 minutes in total", reward: 50, test: (s) => s.stats.totalTime >= 600 },
];

export interface Completed {
  kind: "daily" | "weekly" | "achievement";
  title: string;
  reward: number;
}

// ---- seeded selection so the daily set is identical after a refresh ----------
function seedFrom(str: string): number {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
function rng(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function pickDaily(day: string): MissionState[] {
  const r = rng(seedFrom("daily" + day));
  const pool = [...DAILY_POOL];
  const out: MissionState[] = [];
  while (out.length < 3 && pool.length) {
    const i = Math.floor(r() * pool.length);
    const [m] = pool.splice(i, 1);
    // avoid two distance missions on the same day
    if (m.metric === "distance" && out.some((o) => defOf(o.id)?.metric === "distance")) continue;
    out.push({ id: m.id, progress: 0, done: false });
  }
  return out;
}

export function defOf(id: string): MissionDef | undefined {
  return DAILY_POOL.find((m) => m.id === id) ?? WEEKLY_LIST.find((m) => m.id === id);
}

/** Roll daily/weekly missions over when the date changes. Pure: returns the same object if nothing changed. */
export function refreshPeriods(save: SaveData): SaveData {
  const day = dayKey();
  const week = weekKey();
  let s = save;
  if (s.daily.day !== day || s.daily.items.length === 0) s = { ...s, daily: { day, items: pickDaily(day) } };
  if (s.weekly.week !== week || s.weekly.items.length === 0) s = { ...s, weekly: { week, items: WEEKLY_LIST.map((m) => ({ id: m.id, progress: 0, done: false })) } };
  return s;
}

function advance(items: MissionState[], run: RunStats, kind: Completed["kind"], completed: Completed[]): { items: MissionState[]; reward: number } {
  let reward = 0;
  const value: Record<Metric, number> = {
    // "bosses" has no mission of its own; the Warden is an achievement
    coins: run.coins,
    distance: run.distance,
    platforms: run.platforms,
    games: 1,
    time: run.time,
    powerups: run.powerups,
    candies: run.candies,
  };
  const next = items.map((it) => {
    const def = defOf(it.id);
    if (!def || it.done) return it;
    const v = value[def.metric];
    const progress = def.mode === "sum" ? it.progress + v : Math.max(it.progress, v);
    if (progress >= def.target) {
      reward += def.reward;
      completed.push({ kind, title: def.title, reward: def.reward });
      return { ...it, progress: def.target, done: true };
    }
    return { ...it, progress };
  });
  return { items: next, reward };
}

/** Unlock any achievements whose condition is now met (coins are granted immediately, once). */
export function evaluateAchievements(save: SaveData): { save: SaveData; completed: Completed[] } {
  const completed: Completed[] = [];
  let s = save;
  for (const a of ACHIEVEMENTS) {
    if (s.achievements[a.id]) continue;
    if (a.test(s)) {
      s = { ...s, coins: s.coins + a.reward, achievements: { ...s.achievements, [a.id]: dayKey() } };
      completed.push({ kind: "achievement", title: a.title, reward: a.reward });
    }
  }
  return { save: s, completed };
}

/** Fold a finished run into the save: records, missions, challenges, achievements. */
export function applyRun(save: SaveData, run: RunStats): { save: SaveData; completed: Completed[]; newBest: boolean } {
  const completed: Completed[] = [];
  let s = refreshPeriods(save);
  const newBest = run.distance > s.best;
  // TOTAL DISTANCE: the metres actually climbed in this run (already guarded against NaN/negative
  // values in RunStats). This function is called exactly once per run — by the engine's death
  // callback OR by quitting from the pause menu — so a run can never be added twice, and the
  // total never resets on restart, game over or world changes.
  const runDistance = Math.max(0, Math.floor(Number.isFinite(run.distance) ? run.distance : 0));
  s = {
    ...s,
    best: Math.max(s.best, run.distance),
    stats: {
      ...s.stats,
      games: s.stats.games + 1,
      totalCoins: s.stats.totalCoins + run.coins,
      totalDistance: s.stats.totalDistance + runDistance,
      totalTime: s.stats.totalTime + run.time,
      totalPlatforms: s.stats.totalPlatforms + run.platforms,
      totalPowerups: s.stats.totalPowerups + run.powerups,
      totalNear: s.stats.totalNear + run.nearMisses,
      bosses: s.stats.bosses + run.bosses,
      candies: s.stats.candies + run.candies,
      highestWorld: Math.max(s.stats.highestWorld, Math.min(WORLDS.length - 1, run.worldSeg)),
      bestScore: Math.max(s.stats.bestScore, run.score),
    },
  };
  const d = advance(s.daily.items, run, "daily", completed);
  const w = advance(s.weekly.items, run, "weekly", completed);
  s = { ...s, coins: s.coins + d.reward + w.reward, daily: { ...s.daily, items: d.items }, weekly: { ...s.weekly, items: w.items } };
  const a = evaluateAchievements(s);
  return { save: a.save, completed: [...completed, ...a.completed], newBest };
}

export function formatProgress(def: MissionDef, progress: number): string {
  if (def.metric === "time") {
    const f = (n: number) => `${Math.floor(n / 60)}:${String(Math.floor(n % 60)).padStart(2, "0")}`;
    return `${f(progress)} / ${f(def.target)}`;
  }
  return `${Math.floor(progress).toLocaleString()} / ${def.target.toLocaleString()}`;
}
