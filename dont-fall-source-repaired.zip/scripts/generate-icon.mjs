#!/usr/bin/env node
/**
 * DON'T FALL — launcher icon generator.
 *
 * The icon is NOT new artwork. Every element is produced by the *same functions
 * the game itself calls at runtime:
 *
 *   src/game/sprites.ts -> drawPlayer (ORIGINAL skin from src/game/skins.ts),
 *                          drawPlatform, drawCoin
 *   src/game/worlds.ts  -> drawWorldBackground(ctx, 0, ...)   [World 1: Cave]
 *   src/game/engine.ts  -> Game.prototype.drawLava            [the real lava renderer]
 *
 * Those modules are bundled with esbuild and executed in a headless Chromium
 * canvas — the exact rendering path the game uses — then composed and resized
 * into every Android launcher density plus adaptive-icon layers.
 *
 * Run:  node scripts/generate-icon.mjs      (needs devDependency: playwright)
 * Out:  native-android/icon/**   (copied into android/ by native-android/apply-icons.sh)
 */
import { buildSync } from "esbuild";
import { mkdirSync, writeFileSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const GAME_DIR = join(ROOT, "src/game");
const WORLD = 360; // the game's own world width — identical units to gameplay

/** Scene layout in world units (the same coordinate system the engine renders in). */
const SCENE = {
  cam: 96, // camera offset into the cave parallax
  t: 0.85, // animation time, frozen for a crisp still
  lavaY: 302, // lava surface for the full-bleed square icon
  lavaYAdaptive: 272, // raised so lava stays inside the adaptive mask's safe zone
  ledge: { x: 102, y: 250, w: 156 },
  ledge2: { x: 14, y: 150, w: 66 },
  ledge3: { x: 288, y: 178, w: 60 },
  hero: { x: 180, y: 250, scale: 3.15, stretch: 1.05, leg: 0.22 },
  coins: [
    { x: 66, y: 118, r: 10, spin: 0.4 },
    { x: 300, y: 104, r: 10, spin: 1.7 },
    { x: 252, y: 206, r: 9, spin: 2.9 },
  ],
  // same colours + square shape as the engine's lava burst particles
  embers: [[58, 288], [126, 296], [214, 292], [268, 286], [322, 297]],
};

const BG_SRC = `
  G_worlds.drawWorldBackground(ctx, 0, W, H, SC.cam, SC.t);
  // the engine's own lava renderer, executed verbatim with a minimal state object
  G_engine.Game.prototype.drawLava.call({ time: SC.t, slowT: 0 }, ctx, W, H, lavaY);
`;

const FG_SRC = `
  const { drawPlayer, drawPlatform, drawCoin } = G_sprites;
  drawPlatform(ctx, SC.ledge2.x, SC.ledge2.y, SC.ledge2.w, "normal", 0, 0, SC.t);
  drawPlatform(ctx, SC.ledge3.x, SC.ledge3.y, SC.ledge3.w, "normal", 0, 0, SC.t);
  drawPlatform(ctx, SC.ledge.x, SC.ledge.y, SC.ledge.w, "normal", 0, 0, SC.t);
  for (const c of SC.coins) drawCoin(ctx, c.x, c.y, c.r, c.spin);
  for (const [ex, ey] of SC.embers) {
    ctx.fillStyle = (ex + ey) % 2 ? "#ffd23f" : "#ff7a18";
    ctx.fillRect(ex - 2, ey - 2, 4, 4);
  }
  ctx.save();
  ctx.translate(SC.hero.x, SC.hero.y);
  ctx.scale(SC.hero.scale, SC.hero.scale);
  drawPlayer(ctx, 0, 0, 1, SC.hero.stretch, SC.hero.leg, G_skins.ORIGINAL);
  ctx.restore();
`;

/** Bundle a game module for the browser, exposing it as window.__G. */
function bundle(entry) {
  return buildSync({
    stdin: { contents: `module.exports = require(${JSON.stringify(entry)});`, resolveDir: GAME_DIR, loader: "js" },
    bundle: true,
    write: false,
    platform: "browser",
    format: "iife",
    globalName: "__G",
    logLevel: "silent",
  }).outputFiles[0].text;
}

async function main() {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1024, height: 1024 } });
  await page.setContent("<canvas id=c width=1024 height=1024></canvas>");
  for (const [name, entry] of [["G_sprites", "./sprites.ts"], ["G_worlds", "./worlds.ts"], ["G_skins", "./skins.ts"], ["G_engine", "./engine.ts"]]) {
    await page.addScriptTag({ content: bundle(entry) + `;window.${name}=__G;` });
  }

  const render = (which, size, { scale = 1, lavaY = SCENE.lavaY } = {}) =>
    page.evaluate(
      ({ which, size, scale, lavaY, SC, WORLD, BG_SRC, FG_SRC }) => {
        const c = document.getElementById("c");
        c.width = size;
        c.height = size;
        const ctx = c.getContext("2d");
        ctx.clearRect(0, 0, size, size);
        ctx.save();
        if (scale !== 1) {
          // adaptive foreground: shrink content into the 66dp safe zone
          ctx.translate(size / 2, size / 2);
          ctx.scale(scale, scale);
          ctx.translate(-size / 2, -size / 2);
        }
        ctx.scale(size / WORLD, size / WORLD);
        const W = WORLD;
        const H = WORLD;
        if (which !== "fg") new Function("ctx", "W", "H", "SC", "lavaY", BG_SRC)(ctx, W, H, SC, lavaY);
        if (which !== "bg") new Function("ctx", "W", "H", "SC", FG_SRC)(ctx, W, H, SC);
        ctx.restore();
        return c.toDataURL("image/png");
      },
      { which, size, scale, lavaY, SC: SCENE, WORLD, BG_SRC, FG_SRC },
    );

  const written = [];
  const put = (rel, dataUrl) => {
    const file = join(ROOT, "native-android/icon", rel);
    mkdirSync(dirname(file), { recursive: true });
    writeFileSync(file, Buffer.from(dataUrl.split(",")[1], "base64"));
    written.push(file);
  };

  // Master still + Play Store listing icon.
  put("preview/icon-master-1024.png", await render("both", 1024));
  put("playstore-icon.png", await render("both", 512));

  const legacy = { mdpi: 48, hdpi: 72, xhdpi: 96, xxhdpi: 144, xxxhdpi: 192 };
  for (const [dpi, px] of Object.entries(legacy)) {
    put(`res/mipmap-${dpi}/ic_launcher.png`, await render("both", px));
  }

  // Round legacy icons: circular alpha mask over the identical scene.
  for (const [dpi, px] of Object.entries(legacy)) {
    const src = await render("both", px);
    const url = await page.evaluate(
      async ({ px, src }) => {
        const img = new Image();
        img.src = src;
        await img.decode();
        const c = document.getElementById("c");
        c.width = px;
        c.height = px;
        const ctx = c.getContext("2d");
        ctx.clearRect(0, 0, px, px);
        ctx.save();
        ctx.beginPath();
        ctx.arc(px / 2, px / 2, px / 2, 0, Math.PI * 2);
        ctx.clip();
        ctx.drawImage(img, 0, 0, px, px);
        ctx.restore();
        return c.toDataURL("image/png");
      },
      { px, src },
    );
    put(`res/mipmap-${dpi}/ic_launcher_round.png`, url);
  }

  // Adaptive layers (108dp canvas; foreground content inside the 66dp safe zone).
  const adaptive = { mdpi: 108, hdpi: 162, xhdpi: 216, xxhdpi: 324, xxxhdpi: 432 };
  for (const [dpi, px] of Object.entries(adaptive)) {
    put(`res/mipmap-${dpi}/ic_launcher_foreground.png`, await render("fg", px, { scale: 0.62 }));
  }
  put("res/drawable-nodpi/ic_launcher_background.png", await render("bg", 432, { lavaY: SCENE.lavaYAdaptive }));

  const adaptiveXml = `<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_launcher_background" />
    <foreground android:drawable="@mipmap/ic_launcher_foreground" />
    <monochrome android:drawable="@mipmap/ic_launcher_foreground" />
</adaptive-icon>
`;
  for (const name of ["ic_launcher.xml", "ic_launcher_round.xml"]) {
    const file = join(ROOT, "native-android/icon/res/mipmap-anydpi-v26", name);
    mkdirSync(dirname(file), { recursive: true });
    writeFileSync(file, adaptiveXml);
    written.push(file);
  }

  await browser.close();

  // Sanity: real, square PNGs at the expected sizes.
  const expect = { ...legacy };
  for (const f of written) {
    if (!f.endsWith(".png")) continue;
    const b = readFileSync(f);
    if (b.readUInt32BE(0) !== 0x89504e47) throw new Error("not a PNG: " + f);
    const w = b.readUInt32BE(16);
    const h = b.readUInt32BE(20);
    if (w !== h) throw new Error(`non-square icon ${f}: ${w}x${h}`);
    const dpi = /mipmap-(\w+)\//.exec(f)?.[1];
    if (dpi && expect[dpi] && !f.includes("foreground") && w !== expect[dpi]) {
      throw new Error(`wrong size for ${dpi}: ${w} != ${expect[dpi]} (${f})`);
    }
  }

  console.log(`Generated ${written.length} icon assets from the game's own renderers:`);
  for (const f of written) console.log("  " + f.replace(ROOT + "/", ""));
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
