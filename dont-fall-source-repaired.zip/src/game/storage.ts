// Persistent save data (versioned). v1 saves (coins, best, daily streak, audio) are migrated, never discarded.

import { ALL_SKINS } from "./skins";
import { ABILITIES, ABILITY_MAP } from "./abilities";

export interface Stats {
  games: number;
  totalCoins: number; // lifetime coins collected while playing
  totalDistance: number; // lifetime metres climbed, summed once per finished/abandoned run
  totalTime: number; // seconds
  totalPlatforms: number;
  totalPowerups: number;
  totalNear: number;
  bosses: number; // Warden duels survived
  candies: number; // candy bonuses eaten
  highestWorld: number; // 0..19 (index of the furthest world reached)
  bestScore: number;
}

export interface MissionState {
  id: string;
  progress: number;
  done: boolean;
}

export interface SaveData {
  version: 2;
  coins: number;
  best: number; // best distance in meters
  streak: number; // consecutive days a daily reward was claimed
  lastClaim: string | null; // YYYY-MM-DD (local)
  musicOn: boolean;
  sfxOn: boolean;
  musicVol: number;
  sfxVol: number;
  owned: string[];
  equipped: string;
  stats: Stats;
  daily: { day: string; items: MissionState[] };
  weekly: { week: string; items: MissionState[] };
  achievements: Record<string, string>; // id -> date unlocked
  /** Stage-20 victory is permanent and independent of best distance. */
  dragon: { defeated: boolean; wins: number; bestTime: number };
  /** Ability shop: purchased ability ids, plus which ability is enabled per character. */
  abilities: { owned: string[]; equipped: Record<string, string> };
  /** Completed ordinary (non-boss, non-abandoned) rounds for interstitial cadence. */
  adRounds: number;
  /** Highest adRounds milestone (3, 6, 9, ...) that has already triggered an interstitial. */
  lastInterstitialMilestone: number;
}

const KEY_V1 = "dontfall.save.v1";
const KEY_V2 = "dontfall.save.v2";

export const DAILY_REWARDS = [10, 20, 30, 40, 50, 75, 100];

function defaults(): SaveData {
  return {
    version: 2,
    coins: 0,
    best: 0,
    streak: 0,
    lastClaim: null,
    musicOn: true,
    sfxOn: true,
    musicVol: 0.6,
    sfxVol: 0.8,
    owned: ["original"],
    equipped: "original",
    stats: { games: 0, totalCoins: 0, totalDistance: 0, totalTime: 0, totalPlatforms: 0, totalPowerups: 0, totalNear: 0, bosses: 0, candies: 0, highestWorld: 0, bestScore: 0 },
    daily: { day: "", items: [] },
    weekly: { week: "", items: [] },
    achievements: {},
    dragon: { defeated: false, wins: 0, bestTime: 0 },
    abilities: { owned: [], equipped: {} },
    adRounds: 0,
    lastInterstitialMilestone: 0,
  };
}

const num = (v: unknown, d: number, min = 0) => (typeof v === "number" && isFinite(v) ? Math.max(min, v) : d);
const bool = (v: unknown, d: boolean) => (typeof v === "boolean" ? v : d);

/** Merge any (old or partial) save object into a valid v2 structure. */
function normalize(raw: Record<string, unknown>): SaveData {
  const d = defaults();
  const st = (raw.stats ?? {}) as Record<string, unknown>;
  // keep real purchases (never revoked), drop unknown ids and duplicates so the
  // sequential rule is validated against a trustworthy purchase history
  // Valid ids come from the skin catalog (19 shop characters + the Dragon Slayer reward),
  // so new characters are recognised automatically while unknown ids are still dropped.
  const known = new Set(ALL_SKINS.map((sk) => sk.id));
  const owned = Array.isArray(raw.owned) ? [...new Set((raw.owned as unknown[]).filter((x): x is string => typeof x === "string" && known.has(x)))] : [];
  if (!owned.includes("original")) owned.unshift("original");
  const equipped = typeof raw.equipped === "string" && owned.includes(raw.equipped) ? raw.equipped : "original";
  const items = (arr: unknown): MissionState[] =>
    Array.isArray(arr)
      ? (arr as Record<string, unknown>[])
          .filter((m) => m && typeof m.id === "string")
          .map((m) => ({ id: m.id as string, progress: num(m.progress, 0), done: bool(m.done, false) }))
      : [];
  const daily = (raw.daily ?? {}) as Record<string, unknown>;
  const weekly = (raw.weekly ?? {}) as Record<string, unknown>;
  return {
    version: 2,
    coins: Math.floor(num(raw.coins, d.coins)),
    best: Math.floor(num(raw.best, d.best)),
    streak: Math.floor(num(raw.streak, d.streak)),
    lastClaim: typeof raw.lastClaim === "string" ? raw.lastClaim : null,
    musicOn: bool(raw.musicOn, d.musicOn),
    sfxOn: bool(raw.sfxOn, d.sfxOn),
    musicVol: Math.min(1, num(raw.musicVol, d.musicVol)),
    sfxVol: Math.min(1, num(raw.sfxVol, d.sfxVol)),
    owned,
    equipped,
    stats: {
      games: Math.floor(num(st.games, 0)),
      totalCoins: Math.floor(num(st.totalCoins, 0)),
      totalDistance: Math.floor(num(st.totalDistance, 0)),
      totalTime: num(st.totalTime, 0),
      totalPlatforms: Math.floor(num(st.totalPlatforms, 0)),
      totalPowerups: Math.floor(num(st.totalPowerups, 0)),
      totalNear: Math.floor(num(st.totalNear, 0)),
      bosses: Math.floor(num(st.bosses, 0)),
      candies: Math.floor(num(st.candies, 0)),
      highestWorld: Math.min(19, Math.floor(num(st.highestWorld, 0))),
      bestScore: Math.floor(num(st.bestScore, 0)),
    },
    daily: { day: typeof daily.day === "string" ? daily.day : "", items: items(daily.items) },
    weekly: { week: typeof weekly.week === "string" ? weekly.week : "", items: items(weekly.items) },
    achievements: raw.achievements && typeof raw.achievements === "object" ? { ...(raw.achievements as Record<string, string>) } : {},
    dragon: (() => {
      const dr = (raw.dragon ?? {}) as Record<string, unknown>;
      return {
        defeated: bool(dr.defeated, false),
        wins: Math.floor(num(dr.wins, 0)),
        bestTime: num(dr.bestTime, 0),
      };
    })(),
    abilities: (() => {
      // Safe migration: pre-ability saves simply start with no abilities owned.
      const ab = (raw.abilities ?? {}) as Record<string, unknown>;
      const ownedIds = new Set(ABILITIES.map((x) => x.id));
      const abilityOwned = Array.isArray(ab.owned)
        ? [...new Set((ab.owned as unknown[]).filter((x): x is string => typeof x === "string" && ownedIds.has(x)))]
        : [];
      const equippedIn = (ab.equipped ?? {}) as Record<string, unknown>;
      const equipped: Record<string, string> = {};
      for (const [charId, abilityId] of Object.entries(equippedIn)) {
        // keep an entry only when the ability is real+owned and still bound to an owned character
        if (typeof abilityId !== "string" || !ownedIds.has(abilityId)) continue;
        if (!abilityOwned.includes(abilityId)) continue;
        const def = ABILITY_MAP[abilityId];
        if (def && def.character === charId && owned.includes(charId)) equipped[charId] = abilityId;
      }
      return { owned: abilityOwned, equipped };
    })(),
    adRounds: Math.floor(num(raw.adRounds, 0)),
    lastInterstitialMilestone: Math.floor(num(raw.lastInterstitialMilestone, 0)),
  };
}

export function loadSave(): SaveData {
  try {
    const v2 = localStorage.getItem(KEY_V2);
    if (v2) return normalize(JSON.parse(v2));
    const v1 = localStorage.getItem(KEY_V1);
    if (v1) {
      // Migrate old save. The v1 entry is left untouched as a backup.
      const migrated = normalize(JSON.parse(v1));
      persist(migrated);
      return migrated;
    }
  } catch {
    /* corrupted storage: fall through to defaults */
  }
  return defaults();
}

export function persist(data: SaveData) {
  try {
    localStorage.setItem(KEY_V2, JSON.stringify(data));
  } catch {
    /* storage unavailable */
  }
}

export function dayKey(d = new Date()): string {
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${m}-${day}`;
}

/** Key of the Monday that starts the current week (local time). */
export function weekKey(d = new Date()): string {
  const x = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const dow = (x.getDay() + 6) % 7; // Monday = 0
  x.setDate(x.getDate() - dow);
  return dayKey(x);
}

function yesterdayKey(): string {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return dayKey(d);
}

export function canClaimDaily(save: SaveData): boolean {
  return save.lastClaim !== dayKey();
}

/** Streak that is still alive (claimed today or yesterday). */
export function activeStreak(save: SaveData): number {
  if (!save.lastClaim) return 0;
  if (save.lastClaim === dayKey() || save.lastClaim === yesterdayKey()) return save.streak;
  return 0;
}

/** Streak value the next claim would produce. */
export function nextStreak(save: SaveData): number {
  return activeStreak(save) + 1;
}

export function rewardForStreak(streak: number): number {
  return DAILY_REWARDS[(Math.max(1, streak) - 1) % DAILY_REWARDS.length];
}

/** Milliseconds until local midnight (next daily reward). */
export function msUntilTomorrow(): number {
  const n = new Date();
  const t = new Date(n.getFullYear(), n.getMonth(), n.getDate() + 1);
  return t.getTime() - n.getTime();
}
