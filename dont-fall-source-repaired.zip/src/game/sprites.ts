// Canvas drawing helpers shared by the game, the menu and the shop.

import { ORIGINAL, type Skin } from "./skins";

const OUT = "#26102f";

export function rr(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

// ---------------------------------------------------------------------------------------------
// Headgear. The "explorer" style is the original hat, untouched. Others only change colours/shapes
// inside roughly the same area — body, head and hitbox never change.
// ---------------------------------------------------------------------------------------------
function drawHat(ctx: CanvasRenderingContext2D, s: Skin) {
  ctx.lineWidth = 2.5;
  ctx.strokeStyle = OUT;
  switch (s.hat) {
    case "explorer": {
      ctx.fillStyle = s.hatBrim;
      ctx.beginPath();
      ctx.ellipse(0, -42, 15, 4.5, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      const hg = ctx.createLinearGradient(0, -53, 0, -42);
      hg.addColorStop(0, s.hatMain1);
      hg.addColorStop(1, s.hatMain2);
      ctx.fillStyle = hg;
      ctx.beginPath();
      ctx.moveTo(-9, -42);
      ctx.quadraticCurveTo(-9, -54, 0, -54);
      ctx.quadraticCurveTo(9, -54, 9, -42);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = s.hatBand;
      ctx.fillRect(-8.6, -46, 17.2, 3.4);
      break;
    }
    case "pith": {
      ctx.fillStyle = s.hatBrim;
      ctx.beginPath();
      ctx.ellipse(0, -42, 16, 4.8, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      const g = ctx.createLinearGradient(0, -56, 0, -42);
      g.addColorStop(0, s.hatMain1);
      g.addColorStop(1, s.hatMain2);
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(-10, -42);
      ctx.quadraticCurveTo(-11, -57, 0, -57);
      ctx.quadraticCurveTo(11, -57, 10, -42);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = s.hatBand;
      ctx.fillRect(-9.6, -47, 19.2, 3.6);
      ctx.fillStyle = "rgba(0,0,0,0.25)";
      ctx.beginPath();
      ctx.arc(0, -52, 1.3, 0, Math.PI * 2);
      ctx.fill();
      break;
    }
    case "ninja": {
      ctx.save();
      ctx.beginPath();
      ctx.arc(0, -36, 10.4, 0, Math.PI * 2);
      ctx.clip();
      ctx.fillStyle = s.hatMain1;
      ctx.fillRect(-12, -48, 24, 8); // hood over forehead
      ctx.fillRect(-12, -32.6, 24, 9); // mask over mouth
      ctx.restore();
      ctx.beginPath();
      ctx.arc(0, -36, 10, 0, Math.PI * 2);
      ctx.stroke();
      // headband + tails
      ctx.fillStyle = s.hatBand;
      rr(ctx, -10.8, -43.4, 21.6, 4.6, 2);
      ctx.fill();
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(-9, -41);
      ctx.lineTo(-20, -37);
      ctx.lineTo(-17, -42);
      ctx.lineTo(-21, -46);
      ctx.lineTo(-9, -43);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = s.accent;
      rr(ctx, -3.5, -42.8, 7, 3.4, 1);
      ctx.fill();
      break;
    }
    case "robot": {
      ctx.fillStyle = s.face;
      rr(ctx, -11.5, -47.5, 23, 21, 6);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#0e2a3a";
      rr(ctx, -8.6, -42.6, 17.2, 9, 3.5);
      ctx.fill();
      ctx.fillStyle = s.hatMain1;
      ctx.beginPath();
      ctx.arc(3.4, -38, 2.4, 0, Math.PI * 2);
      ctx.arc(-3.4, -38, 2.4, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#6b7c90";
      ctx.fillRect(-5, -30.4, 10, 1.8);
      ctx.beginPath();
      ctx.moveTo(0, -47.5);
      ctx.lineTo(0, -54);
      ctx.stroke();
      ctx.fillStyle = s.accent;
      ctx.beginPath();
      ctx.arc(0, -55, 2.8, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#8896a8";
      ctx.beginPath();
      ctx.arc(-12, -37, 2, 0, Math.PI * 2);
      ctx.arc(12, -37, 2, 0, Math.PI * 2);
      ctx.fill();
      break;
    }
    case "pirate": {
      // eyepatch
      ctx.fillStyle = "#14141a";
      ctx.beginPath();
      ctx.arc(3.6, -35.8, 4.2, 0, Math.PI * 2);
      ctx.fill();
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.moveTo(3.6, -35.8);
      ctx.lineTo(-9.5, -41);
      ctx.moveTo(3.6, -35.8);
      ctx.lineTo(9.5, -41);
      ctx.stroke();
      ctx.lineWidth = 2.5;
      // tricorn
      ctx.fillStyle = s.hatBrim;
      ctx.beginPath();
      ctx.moveTo(-17, -40);
      ctx.quadraticCurveTo(0, -48, 17, -40);
      ctx.quadraticCurveTo(0, -37.5, -17, -40);
      ctx.fill();
      ctx.stroke();
      const g = ctx.createLinearGradient(0, -55, 0, -42);
      g.addColorStop(0, s.hatMain1);
      g.addColorStop(1, s.hatMain2);
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(-10, -42);
      ctx.quadraticCurveTo(-10, -55, 0, -55);
      ctx.quadraticCurveTo(10, -55, 10, -42);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = s.hatBand;
      ctx.fillRect(-9.4, -45.8, 18.8, 2.6);
      ctx.fillStyle = "#fff";
      ctx.beginPath();
      ctx.arc(0, -50.2, 2.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = OUT;
      ctx.fillRect(-1.5, -50.8, 1, 1);
      ctx.fillRect(0.6, -50.8, 1, 1);
      break;
    }
    case "astro": {
      ctx.fillStyle = "#c9d3df";
      rr(ctx, -11.5, -27.5, 23, 4.6, 2.3);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "rgba(170,225,255,0.28)";
      ctx.beginPath();
      ctx.arc(0, -36, 13.4, 0, Math.PI * 2);
      ctx.fill();
      ctx.lineWidth = 3;
      ctx.strokeStyle = "#e8eef5";
      ctx.stroke();
      ctx.lineWidth = 1.2;
      ctx.strokeStyle = OUT;
      ctx.beginPath();
      ctx.arc(0, -36, 15, 0, Math.PI * 2);
      ctx.stroke();
      ctx.strokeStyle = "rgba(255,255,255,0.85)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(0, -36, 10.4, Math.PI * 1.15, Math.PI * 1.45);
      ctx.stroke();
      ctx.fillStyle = s.hatBand;
      ctx.beginPath();
      ctx.arc(-12.6, -36, 2.1, 0, Math.PI * 2);
      ctx.fill();
      break;
    }
    case "beanie": {
      ctx.fillStyle = s.hatMain1;
      ctx.beginPath();
      ctx.moveTo(-10.6, -41);
      ctx.quadraticCurveTo(-10.6, -54, 0, -54);
      ctx.quadraticCurveTo(10.6, -54, 10.6, -41);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = s.hatMain2;
      ctx.fillRect(-6.4, -52.4, 3, 8);
      ctx.fillRect(2.2, -52.4, 3, 8);
      ctx.fillStyle = s.hatBand;
      rr(ctx, -11.6, -45, 23.2, 5.6, 2.8);
      ctx.fill();
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(0, -55, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      break;
    }
    case "knight": {
      // flame plume
      ctx.fillStyle = s.accent;
      ctx.beginPath();
      ctx.moveTo(-5, -47);
      ctx.bezierCurveTo(-9, -57, -1, -57, -2, -64);
      ctx.bezierCurveTo(3, -58, 8, -58, 5, -47);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#ffe066";
      ctx.beginPath();
      ctx.moveTo(-2, -48);
      ctx.bezierCurveTo(-4, -54, 0, -54, 0, -58);
      ctx.bezierCurveTo(3, -54, 4, -53, 2, -48);
      ctx.closePath();
      ctx.fill();
      // helmet
      const g = ctx.createLinearGradient(0, -48, 0, -36);
      g.addColorStop(0, s.hatMain1);
      g.addColorStop(1, s.hatMain2);
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(0, -37, 11.4, Math.PI, 0);
      ctx.lineTo(11.4, -39);
      ctx.lineTo(-11.4, -39);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = s.hatBand;
      ctx.fillRect(-11, -42.2, 22, 2.8);
      ctx.fillStyle = s.hatMain2;
      rr(ctx, -1.8, -42, 3.6, 10.5, 1.6);
      ctx.fill();
      ctx.stroke();
      break;
    }
    case "ranger": {
      ctx.fillStyle = s.hatBand;
      ctx.beginPath();
      ctx.moveTo(5, -49);
      ctx.quadraticCurveTo(15, -56, 18, -64);
      ctx.quadraticCurveTo(9, -61, 3, -52);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      const g = ctx.createLinearGradient(0, -57, 0, -41);
      g.addColorStop(0, s.hatMain1);
      g.addColorStop(1, s.hatMain2);
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(-11.4, -40.5);
      ctx.quadraticCurveTo(-9, -53, 4, -57);
      ctx.quadraticCurveTo(1, -50, 11.4, -40.5);
      ctx.quadraticCurveTo(0, -37.5, -11.4, -40.5);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      break;
    }
    case "turban": {
      ctx.fillStyle = s.hatMain1;
      ctx.beginPath();
      ctx.arc(0, -49.5, 6.4, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      rr(ctx, -11.4, -47.6, 22.8, 10.6, 5);
      ctx.fill();
      ctx.stroke();
      ctx.strokeStyle = s.hatMain2;
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.moveTo(-9, -39);
      ctx.lineTo(-1, -46.5);
      ctx.moveTo(-2.5, -38.5);
      ctx.lineTo(6.5, -46.5);
      ctx.moveTo(4, -38.5);
      ctx.lineTo(10.5, -44);
      ctx.stroke();
      ctx.fillStyle = s.hatBand;
      ctx.strokeStyle = "#d19a00";
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.arc(0, -42.4, 2.6, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      break;
    }
    case "wizard": {
      ctx.fillStyle = s.hatBrim;
      ctx.beginPath();
      ctx.ellipse(0, -42, 17, 4.8, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      const g = ctx.createLinearGradient(0, -70, 0, -42);
      g.addColorStop(0, s.hatMain1);
      g.addColorStop(1, s.hatMain2);
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(-10.5, -42);
      ctx.quadraticCurveTo(-5, -54, 5, -70);
      ctx.quadraticCurveTo(7, -54, 10.5, -42);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = s.hatBand;
      ctx.fillRect(-10, -46.2, 20, 3.6);
      ctx.beginPath();
      ctx.arc(-1, -53, 1.6, 0, Math.PI * 2);
      ctx.arc(3.2, -60, 1.2, 0, Math.PI * 2);
      ctx.fill();
      break;
    }
    case "jester": {
      // three lobed cap, each tipped with a bell
      const lobes: [number, number, number][] = [[-12, -58, -26], [0, -66, 0], [12, -58, 26]];
      for (const [lx, ly, tipx] of lobes) {
        ctx.fillStyle = s.hatMain1;
        ctx.strokeStyle = OUT;
        ctx.beginPath();
        ctx.moveTo(lx - 6, -41);
        ctx.quadraticCurveTo(lx - 8, ly + 8, tipx, ly);
        ctx.quadraticCurveTo(lx + 10, ly + 10, lx + 7, -41);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        // banding stripe
        ctx.fillStyle = s.hatBand;
        ctx.beginPath();
        ctx.ellipse(tipx * 0.8, -50, 4.5, 3, tipx * 0.06, 0, Math.PI * 2);
        ctx.fill();
        // bell
        ctx.fillStyle = s.accent;
        ctx.beginPath();
        ctx.arc(tipx, ly, 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      }
      ctx.fillStyle = s.hatMain2;
      ctx.beginPath();
      ctx.ellipse(0, -41.5, 12, 4, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      break;
    }
    case "cowboy": {
      // wide brim with a dented crown
      ctx.fillStyle = s.hatBrim;
      ctx.strokeStyle = OUT;
      ctx.beginPath();
      ctx.moveTo(-19, -41);
      ctx.quadraticCurveTo(-12, -45, 0, -45);
      ctx.quadraticCurveTo(12, -45, 19, -41);
      ctx.quadraticCurveTo(10, -37.5, 0, -37.5);
      ctx.quadraticCurveTo(-10, -37.5, -19, -41);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      const g = ctx.createLinearGradient(0, -58, 0, -43);
      g.addColorStop(0, s.hatMain1);
      g.addColorStop(1, s.hatMain2);
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(-9.5, -43.5);
      ctx.quadraticCurveTo(-10, -54, -5, -56);
      ctx.quadraticCurveTo(0, -53.5, 5, -56);
      ctx.quadraticCurveTo(10, -54, 9.5, -43.5);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = s.hatBand;
      ctx.fillRect(-8.5, -49.5, 17, 3.6);
      // star
      ctx.fillStyle = s.accent;
      ctx.strokeStyle = OUT;
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      for (let i = 0; i < 10; i++) {
        const a = (i / 10) * Math.PI * 2 - Math.PI / 2;
        const r = i % 2 ? 1.7 : 3.6;
        const px = Math.cos(a) * r;
        const py = -51.5 + Math.sin(a) * r;
        if (!i) ctx.moveTo(px, py); else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.lineWidth = 2.5;
      break;
    }
    case "bee": {
      // striped aviator cap + two antennae + round goggles
      ctx.fillStyle = s.hatMain2;
      ctx.beginPath();
      ctx.ellipse(0, -41.5, 11.5, 3.6, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      const g = ctx.createLinearGradient(0, -55, 0, -42);
      g.addColorStop(0, s.hatMain1);
      g.addColorStop(1, s.hatMain2);
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(-9, -42);
      ctx.quadraticCurveTo(-9.5, -54.5, 0, -55);
      ctx.quadraticCurveTo(9.5, -54.5, 9, -42);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      // stripes
      ctx.fillStyle = s.hatMain2;
      ctx.fillRect(-7.5, -49.5, 15, 2.6);
      // antennae
      ctx.strokeStyle = s.hatMain2;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-4.5, -54);
      ctx.quadraticCurveTo(-7, -62, -9.5, -65);
      ctx.moveTo(4.5, -54);
      ctx.quadraticCurveTo(7, -62, 9.5, -65);
      ctx.stroke();
      ctx.fillStyle = s.hatMain1;
      ctx.strokeStyle = OUT;
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.arc(-10, -66, 2.6, 0, Math.PI * 2);
      ctx.arc(10, -66, 2.6, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.lineWidth = 2.5;
      // goggles resting on the cap
      ctx.fillStyle = "rgba(170,235,255,0.95)";
      ctx.strokeStyle = s.hatMain2;
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.arc(-4.2, -50.5, 3, 0, Math.PI * 2);
      ctx.arc(4.2, -50.5, 3, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(-1.2, -50.5);
      ctx.lineTo(1.2, -50.5);
      ctx.stroke();
      break;
    }
    case "chef": {
      // tall pleated toque
      ctx.fillStyle = s.hatBrim;
      ctx.strokeStyle = OUT;
      ctx.beginPath();
      ctx.moveTo(-9.5, -41.5);
      ctx.quadraticCurveTo(-10, -47, -8, -49);
      ctx.lineTo(8, -49);
      ctx.quadraticCurveTo(10, -47, 9.5, -41.5);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      const g = ctx.createLinearGradient(0, -68, 0, -49);
      g.addColorStop(0, s.hatMain1);
      g.addColorStop(1, s.hatMain2);
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(-8, -49);
      ctx.quadraticCurveTo(-12, -52, -11, -58);
      ctx.quadraticCurveTo(-12, -66, -4, -67);
      ctx.quadraticCurveTo(0, -70, 4, -67);
      ctx.quadraticCurveTo(12, -66, 11, -58);
      ctx.quadraticCurveTo(12, -52, 8, -49);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      // pleats
      ctx.strokeStyle = "rgba(120,130,150,0.55)";
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.moveTo(-5, -51);
      ctx.lineTo(-5.5, -64);
      ctx.moveTo(0, -51);
      ctx.lineTo(0, -67);
      ctx.moveTo(5, -51);
      ctx.lineTo(5.5, -64);
      ctx.stroke();
      ctx.lineWidth = 2.5;
      ctx.strokeStyle = OUT;
      ctx.fillStyle = s.hatBand;
      ctx.fillRect(-9, -50.5, 18, 2.4);
      break;
    }
    case "dino": {
      // spiky frill around the head
      ctx.fillStyle = s.hatMain1;
      ctx.strokeStyle = OUT;
      ctx.beginPath();
      const spikes = 7;
      for (let i = 0; i < spikes; i++) {
        const a = Math.PI * (0.08 + (0.84 * i) / (spikes - 1));
        const x1 = Math.cos(a) * 13;
        const y1 = -36 - Math.sin(a) * 13;
        const xt = Math.cos(a) * 20;
        const yt = -36 - Math.sin(a) * 20;
        ctx.moveTo(x1, y1);
        ctx.lineTo(xt, yt);
      }
      // draw as filled spikes
      ctx.closePath();
      ctx.fill();
      ctx.save();
      ctx.translate(0, -36);
      ctx.rotate(Math.PI);
      ctx.beginPath();
      for (let i = 0; i < spikes; i++) {
        const a = (i / (spikes - 1)) * Math.PI;
        ctx.moveTo(Math.cos(a + Math.PI) * 12.5, -Math.sin(a) * 12.5);
        ctx.lineTo(Math.cos(a + Math.PI) * 19.5, -Math.sin(a) * 19.5);
      }
      ctx.restore();
      ctx.fillStyle = s.hatMain1;
      for (let i = 0; i < spikes; i++) {
        const a = (i / (spikes - 1)) * Math.PI;
        const cx = Math.cos(a + Math.PI) * 14;
        const cy = -36 - Math.sin(a) * 14;
        const tx = Math.cos(a + Math.PI) * 20.5;
        const ty = -36 - Math.sin(a) * 20.5;
        ctx.beginPath();
        ctx.moveTo(cx - Math.sin(a) * 3.4, cy + Math.cos(a) * 3.4);
        ctx.lineTo(tx, ty);
        ctx.lineTo(cx + Math.sin(a) * 3.4, cy - Math.cos(a) * 3.4);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      }
      // low rounded cap over the crown
      ctx.fillStyle = s.hatMain2;
      ctx.beginPath();
      ctx.arc(0, -38, 10.6, Math.PI, 0);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = s.hatBand;
      ctx.fillRect(-9, -46.5, 18, 2.6);
      break;
    }
    case "vampire": {
      // tall cape collar + widow's peak + slim top hat
      ctx.fillStyle = s.hatBand;
      ctx.strokeStyle = OUT;
      for (const side of [-1, 1]) {
        ctx.beginPath();
        ctx.moveTo(side * 10, -30);
        ctx.lineTo(side * 16.5, -34.5);
        ctx.lineTo(side * 13.5, -28.5);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      }
      // hair with widow's peak
      ctx.fillStyle = s.hatMain2;
      ctx.beginPath();
      ctx.arc(0, -36.5, 10.6, Math.PI * 0.94, Math.PI * 2.06);
      ctx.lineTo(3, -42);
      ctx.lineTo(0, -38.5);
      ctx.lineTo(-3, -42);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      // top hat
      ctx.fillStyle = s.hatMain1;
      ctx.beginPath();
      ctx.ellipse(0, -44.5, 11.5, 3, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      const g = ctx.createLinearGradient(0, -62, 0, -44);
      g.addColorStop(0, s.hatMain2);
      g.addColorStop(1, s.hatMain1);
      ctx.fillStyle = g;
      ctx.fillRect(-8, -61, 16, 17);
      ctx.strokeRect(-8, -61, 16, 17);
      ctx.fillStyle = s.accent;
      ctx.fillRect(-8, -49, 16, 3.4);
      break;
    }
    case "samurai": {
      // kabuto dome + gold crescent crest + red cord
      ctx.fillStyle = s.hatMain2;
      ctx.strokeStyle = OUT;
      ctx.beginPath();
      ctx.ellipse(0, -41, 12.5, 4, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      const g = ctx.createLinearGradient(0, -56, 0, -40);
      g.addColorStop(0, s.hatMain1);
      g.addColorStop(1, s.hatMain2);
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(0, -40, 11, Math.PI, 0);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      // side flaps
      ctx.beginPath();
      ctx.moveTo(-10.5, -40);
      ctx.lineTo(-13.5, -33.5);
      ctx.lineTo(-9, -34.5);
      ctx.closePath();
      ctx.moveTo(10.5, -40);
      ctx.lineTo(13.5, -33.5);
      ctx.lineTo(9, -34.5);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      // crescent (maedate)
      ctx.fillStyle = s.accent;
      ctx.strokeStyle = OUT;
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.arc(-3, -56, 5, Math.PI * 0.15, Math.PI * 1.6, true);
      ctx.arc(-1.5, -55.5, 3.6, Math.PI * 1.5, Math.PI * 0.25, false);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(3, -56, 5, Math.PI * 1.4, Math.PI * 0.85, true);
      ctx.arc(1.5, -55.5, 3.6, Math.PI * 0.85, Math.PI * 1.65, false);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      // red cord tassel
      ctx.strokeStyle = "#c01f3a";
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.moveTo(0, -50.5);
      ctx.lineTo(0, -46);
      ctx.stroke();
      ctx.fillStyle = "#c01f3a";
      ctx.beginPath();
      ctx.arc(0, -44.5, 1.6, 0, Math.PI * 2);
      ctx.fill();
      ctx.lineWidth = 2.5;
      ctx.strokeStyle = OUT;
      break;
    }
    case "dragon": {
      // Exclusive Dragon Slayer hood — same head/body proportions as every other skin.
      ctx.fillStyle = s.hatMain2;
      ctx.beginPath();
      ctx.moveTo(-11, -39);
      ctx.quadraticCurveTo(-12, -55, 0, -57);
      ctx.quadraticCurveTo(12, -55, 11, -39);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      for (const side of [-1, 1]) {
        ctx.fillStyle = "#ead9b0";
        ctx.beginPath();
        ctx.moveTo(side * 6, -52);
        ctx.lineTo(side * 12, -66);
        ctx.lineTo(side * 13, -49);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      }
      ctx.fillStyle = s.hatMain1;
      ctx.beginPath();
      ctx.moveTo(-4, -56);
      ctx.lineTo(0, -68);
      ctx.lineTo(4, -56);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = s.hatBand;
      ctx.fillRect(-10, -46, 20, 3.4);
      break;
    }
    case "crown": {
      ctx.fillStyle = s.hatMain1;
      ctx.beginPath();
      ctx.moveTo(-9.5, -42);
      ctx.lineTo(-10.5, -54);
      ctx.lineTo(-4.8, -48);
      ctx.lineTo(0, -57);
      ctx.lineTo(4.8, -48);
      ctx.lineTo(10.5, -54);
      ctx.lineTo(9.5, -42);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = s.hatBand;
      ctx.beginPath();
      ctx.arc(0, -46, 2.2, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = s.hatMain2;
      ctx.fillRect(-9.2, -44.2, 18.4, 2.2);
      break;
    }
  }
}

/**
 * Draws the adventurer with its feet at (x, y).
 * facing: 1 = right, -1 = left. stretch: vertical scale (jump squash/stretch). legPhase: 0..1 leg swing.
 * The default skin reproduces the original character exactly.
 */
export function drawPlayer(ctx: CanvasRenderingContext2D, x: number, y: number, facing: number, stretch = 1, legPhase = 0, skin: Skin = ORIGINAL) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(facing * (1 / Math.sqrt(stretch)), stretch);
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  ctx.lineWidth = 2.5;
  ctx.strokeStyle = OUT;

  // backpack (behind body)
  ctx.fillStyle = skin.pack;
  rr(ctx, -17, -27, 11, 16, 4);
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = skin.packTrim;
  rr(ctx, -15, -24, 7, 4, 2);
  ctx.fill();

  // boots
  const swing = Math.sin(legPhase * Math.PI * 2) * 2;
  ctx.fillStyle = skin.boots;
  rr(ctx, -9 + swing, -8, 8, 8, 3);
  ctx.fill();
  ctx.stroke();
  rr(ctx, 1 - swing, -8, 8, 8, 3);
  ctx.fill();
  ctx.stroke();

  // body / jacket
  const g = ctx.createLinearGradient(0, -28, 0, -8);
  g.addColorStop(0, skin.jacketTop);
  g.addColorStop(1, skin.jacketBot);
  ctx.fillStyle = g;
  rr(ctx, -10, -27, 20, 20, 7);
  ctx.fill();
  ctx.stroke();
  // belt
  ctx.fillStyle = skin.belt;
  ctx.fillRect(-9.5, -14, 19, 3.5);
  ctx.fillStyle = skin.buckle;
  ctx.fillRect(-2, -14.5, 4.5, 4.5);

  // arm
  ctx.fillStyle = skin.jacketTop;
  rr(ctx, 4, -25, 6, 12, 3);
  ctx.fill();
  ctx.stroke();

  // scarf
  ctx.fillStyle = skin.scarf;
  rr(ctx, -10, -30, 20, 6, 3);
  ctx.fill();
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(-9, -26);
  ctx.lineTo(-17, -22 + swing * 0.5);
  ctx.lineTo(-10, -22);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // head
  ctx.fillStyle = skin.face;
  ctx.beginPath();
  ctx.arc(0, -36, 10, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // eyes
  ctx.fillStyle = "#fff";
  ctx.beginPath();
  ctx.ellipse(3.5, -36, 3.4, 4, 0, 0, Math.PI * 2);
  ctx.ellipse(-3, -36, 3, 3.6, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = OUT;
  ctx.beginPath();
  ctx.arc(4.6, -35.5, 1.8, 0, Math.PI * 2);
  ctx.arc(-2, -35.5, 1.6, 0, Math.PI * 2);
  ctx.fill();
  // smile
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.arc(2, -32, 3, 0.2, Math.PI - 0.5);
  ctx.stroke();
  ctx.lineWidth = 2.5;

  drawHat(ctx, skin);

  ctx.restore();
}

// ---------------------------------------------------------------------------------------------
// Platforms
// ---------------------------------------------------------------------------------------------
export type PlatformKind =
  | "normal" | "moving" | "crumble" | "spring" | "ice" | "wooden" | "sand" | "temp"
  /* worlds 7-12 */
  | "bubble" | "ghost" | "electric" | "asteroid" | "sticky" | "jelly"
  /* stages 13-20 */
  | "piston" | "mushroom" | "ship" | "clock" | "toyblock" | "note" | "book" | "obsidian";

/** Extra per-platform animation state passed by the engine. */
export interface PlatAnim {
  alpha?: number; // ghost phasing
  charge?: number; // 0..1 electric arcs
  push?: number; // conveyor direction (-1/0/1)
  wob?: number; // jelly wobble 0..1
  fade2?: number; // generic fade (bubble pop etc.)
}

type Pal = [string, string, string];

// index = world: cave, snow, volcano, forest, desert, sky.  Cave entries are the original palettes.
const NORMAL: Pal[] = [
  ["#8b7bb0", "#5d4a8a", "#6fe08a"],
  ["#9fb7d6", "#5f7fa8", "#ffffff"],
  ["#5e3d3b", "#2e1a1a", "#ff7a18"],
  ["#8a5a32", "#5a3a1e", "#5fd35f"],
  ["#d9a35c", "#a8742f", "#f6d58f"],
  ["#b08c68", "#7a5a3e", "#7fe36a"],
  ["#4f9fd0", "#22608f", "#8ff0ff"],
  ["#6b4fae", "#33215e", "#a6ff8f"],
  ["#2c2a52", "#171432", "#5ff2ff"],
  ["#5b5f80", "#2f3350", "#c8d0ff"],
  ["#ffd0ea", "#e07bb4", "#fff4c8"],
  ["#6f6a7e", "#3a3648", "#9c8cff"],
  ["#8b98a8", "#4c5866", "#f2b84b"],
  ["#eadbbd", "#9a6c78", "#ff8fb3"],
  ["#7c4a27", "#44291d", "#d9c49a"],
  ["#b08a4a", "#5f4830", "#ffd166"],
  ["#ff8f8f", "#7950bb", "#ffd93d"],
  ["#7950bb", "#3d276b", "#c8f6ff"],
  ["#8b5a87", "#4b3557", "#f5e7bf"],
  ["#352b3e", "#17121e", "#ff7043"],
];
const MOVING: Pal[] = [
  ["#6fb4d9", "#3c78a8", "#a8f0ff"],
  ["#7fd6ff", "#3c8fc4", "#e8fbff"],
  ["#c0623a", "#7a2e1a", "#ffb347"],
  ["#b57a3c", "#7a4a1e", "#8cd35f"],
  ["#6fb4a0", "#3c7a6a", "#bff0d8"],
  ["#ffffff", "#bfe0ff", "#ffffff"],
  ["#7fe0ff", "#2a86c4", "#d6faff"],
  ["#a98cf0", "#5e3fb0", "#d9ff9e"],
  ["#ff5ad6", "#7a1f8f", "#5ff2ff"],
  ["#8f9ac0", "#4a5480", "#e0e8ff"],
  ["#ffb0dd", "#d6478f", "#fff4c8"],
  ["#b0453f", "#5c1a1a", "#ff8a5c"],
  ["#8994a1", "#4c5866", "#f2b84b"],
  ["#f472b6", "#8d4c78", "#fff1f7"],
  ["#8b5a2b", "#4a2f18", "#d9c49a"],
  ["#c5a45d", "#6b4d2f", "#fff0b0"],
  ["#4d96ff", "#694a9a", "#ffd93d"],
  ["#a67cff", "#5b2d91", "#c8f6ff"],
  ["#8b5a87", "#4b3557", "#f5e7bf"],
  ["#6d1b17", "#2b1018", "#ff7043"],
];
const CRUMBLE: Pal[] = [
  ["#b58b6a", "#85583c", "#d8b48c"],
  ["#bfe3f5", "#7fb0cf", "#ffffff"],
  ["#7a3a1a", "#4a1a0a", "#ff5a1a"],
  ["#7a6a3a", "#4a3e1e", "#a8a85a"],
  ["#e0b878", "#b08840", "#f2dba8"],
  ["#d8e0f0", "#a0b0d0", "#ffffff"],
  ["#79c0e0", "#2f6b90", "#c8f4ff"],
  ["#7a5fc0", "#38226b", "#b6ff9e"],
  ["#3a3760", "#191634", "#ff5ad6"],
  ["#6b7099", "#363c60", "#dfe6ff"],
  ["#f0c0dc", "#b8679e", "#fff4c8"],
  ["#5c5566", "#2a2635", "#a89cff"],
  ["#77818d", "#3d4650", "#f2b84b"],
  ["#b78a9e", "#69445f", "#ffd0e5"],
  ["#6b452d", "#39251e", "#d9c49a"],
  ["#81643d", "#493c3c", "#ffd166"],
  ["#d57878", "#74425c", "#ffd93d"],
  ["#7950bb", "#3d276b", "#c8f6ff"],
  ["#8b5a87", "#4b3557", "#f5e7bf"],
  ["#4a3540", "#21121c", "#ff7043"],
];
const TEMP: Pal[] = [
  ["#c9b2ff", "#8a6fe0", "#ffffff"],
  ["#d5f3ff", "#8fd0f0", "#ffffff"],
  ["#ff9a3c", "#d6451a", "#ffe28a"],
  ["#b7e69a", "#6fb35a", "#e6ffd0"],
  ["#ffd89a", "#e0a050", "#fff0c8"],
  ["#f4fbff", "#c7e4ff", "#ffffff"],
  ["#9fe8ff", "#3f9fd0", "#ffffff"],
  ["#c8a8ff", "#6b3fbf", "#e8ffd0"],
  ["#5ff2ff", "#2b7fbf", "#ff5ad6"],
  ["#c0ccff", "#6b7ac0", "#ffffff"],
  ["#ffe0f2", "#ff8ad0", "#ffffff"],
  ["#a098b8", "#4e4664", "#ff6a4d"],
  ["#a7afb8", "#59636e", "#fff0b0"],
  ["#f9a8d4", "#8d4c78", "#fff1f7"],
  ["#b57a3c", "#6b452d", "#d9c49a"],
  ["#dbc07a", "#81643d", "#fff0b0"],
  ["#ff9f9f", "#7950bb", "#ffffff"],
  ["#c59aff", "#684094", "#ffffff"],
  ["#c8a0c0", "#6a4a6a", "#f5e7bf"],
  ["#6d1b17", "#2b1018", "#ff7043"],
];
const ICE: Pal = ["#c6f0ff", "#7ccbee", "#ffffff"];
const BUBBLE: Pal = ["#bdeeff", "#4fa8d8", "#ffffff"];
const GHOSTP: Pal = ["#b6ff9e", "#5e9e8a", "#eafff0"];
const ELEC: Pal = ["#3f3c6e", "#1a1740", "#5ff2ff"];
const AST: Pal = ["#8b8fb0", "#494d70", "#c8d0ff"];
const STICK: Pal = ["#ffc2e8", "#e072b8", "#fff6c8"];
const JELLY: Pal = ["#ff9ad0", "#e0479a", "#ffe6f6"];
const WOOD: Pal = ["#b57a3c", "#7a4a1e", "#8cd35f"];
const SAND: Pal = ["#f0c878", "#c9993f", "#fbe6b0"];

function palette(kind: PlatformKind, theme: number): Pal {
  switch (kind) {
    case "moving": return MOVING[theme];
    case "crumble": return CRUMBLE[theme];
    case "temp": return TEMP[theme];
    case "ice": return ICE;
    case "wooden": return WOOD;
    case "sand": return SAND;
    case "bubble": return BUBBLE;
    case "ghost": return GHOSTP;
    case "electric": return ELEC;
    case "asteroid": return AST;
    case "sticky": return STICK;
    case "jelly": return JELLY;
    default: return NORMAL[theme];
  }
}

/**
 * fade: 0..1 progress of the crumble / sink / vanish animation for fragile kinds.
 * theme: world index. t: running time for small animations.
 */
export function drawPlatform(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, kind: PlatformKind, fade = 0, theme = 0, t = 0, o: PlatAnim = {}) {
  const h = 14;
  const [top, bot, trim] = palette(kind, theme);
  ctx.save();
  if (fade > 0) {
    if (kind === "crumble") {
      ctx.translate((Math.random() - 0.5) * 2.4, fade * fade * 30);
      ctx.globalAlpha = Math.max(0, 1 - fade * 0.9);
    } else if (kind === "sand") {
      ctx.translate((Math.random() - 0.5) * 1.2, fade * 16);
      ctx.globalAlpha = Math.max(0, 1 - fade * 0.95);
    } else if (kind === "temp") {
      ctx.globalAlpha = fade < 0.55 ? 1 : Math.floor(fade * 22) % 2 ? 0.3 : 0.95;
    }
  }
  ctx.globalAlpha *= o.alpha ?? 1;
  if (kind === "jelly") {
    // squishy jiggle
    const sq = 1 + Math.sin(t * 9 + (o.wob ?? 0) * 6) * 0.05 * (1 + (o.wob ?? 0) * 3);
    ctx.translate(x + w / 2, y + h);
    ctx.scale(1 / sq, sq);
    ctx.translate(-(x + w / 2), -(y + h));
  }
  ctx.lineWidth = 2.5;
  ctx.strokeStyle = OUT;
  ctx.lineJoin = "round";
  if (kind === "bubble") {
    // translucent bubble with a rim highlight and no hard outline
    const g = ctx.createRadialGradient(x + w * 0.35, y - 4, 2, x + w / 2, y + 4, w * 0.7);
    g.addColorStop(0, "rgba(255,255,255,0.85)");
    g.addColorStop(0.45, "rgba(150,230,255,0.45)");
    g.addColorStop(1, "rgba(40,140,190,0.55)");
    ctx.fillStyle = g;
    ctx.strokeStyle = "rgba(220,250,255,0.9)";
    ctx.lineWidth = 2.2;
    rr(ctx, x, y - 2, w, h + 4, (h + 4) / 2);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = "rgba(255,255,255,0.9)";
    ctx.beginPath();
    ctx.ellipse(x + w * 0.28, y + 1.5, Math.min(7, w * 0.12), 2.4, -0.3, 0, Math.PI * 2);
    ctx.fill();
    if ((o.fade2 ?? 0) > 0) {
      ctx.strokeStyle = `rgba(255,255,255,${1 - (o.fade2 ?? 0)})`;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(x + w / 2, y + h / 2, (w / 2) * (1 + (o.fade2 ?? 0)), 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.restore();
    return;
  }
  // floating-island underside in the sky world
  if (theme === 5 && (kind === "normal" || kind === "spring")) {
    ctx.fillStyle = bot;
    ctx.beginPath();
    ctx.moveTo(x + w * 0.18, y + h - 3);
    ctx.lineTo(x + w * 0.5, y + h + 11);
    ctx.lineTo(x + w * 0.82, y + h - 3);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }
  const g = ctx.createLinearGradient(0, y, 0, y + h);
  g.addColorStop(0, top);
  g.addColorStop(1, bot);
  ctx.fillStyle = g;
  rr(ctx, x, y, w, h, 6);
  ctx.fill();
  ctx.stroke();
  // grass / snow / crust cap
  ctx.fillStyle = trim;
  rr(ctx, x + 2, y + 1.5, w - 4, 4.5, 2.5);
  ctx.fill();

  if (theme === 1 && (kind === "normal" || kind === "spring" || kind === "crumble")) {
    // snow drifts
    ctx.fillStyle = "#ffffff";
    for (let i = 0; i < 3; i++) {
      const cx = x + w * (0.2 + i * 0.3);
      ctx.beginPath();
      ctx.arc(cx, y + 1, 5 + (i % 2) * 2, Math.PI, 0);
      ctx.fill();
    }
  }
  if (theme === 6) {
    // coral / anemones on the ledge
    for (let i = 0; i < 2; i++) {
      const cx = x + 10 + ((i * 37) % Math.max(12, w - 18));
      ctx.fillStyle = i ? "rgba(255,140,190,0.85)" : "rgba(120,240,220,0.85)";
      ctx.beginPath();
      ctx.arc(cx, y + 1, 3, Math.PI, 0);
      ctx.fill();
    }
  }
  if (theme === 8) {
    // neon underglow strip
    ctx.fillStyle = `rgba(95,242,255,${0.35 + 0.35 * Math.sin(t * 5 + x)})`;
    ctx.fillRect(x + 4, y + h - 2.5, w - 8, 2);
  }
  if (theme === 10 && (kind === "normal" || kind === "sticky")) {
    // sprinkles
    ctx.lineWidth = 1.6;
    for (let i = 0; i < 4; i++) {
      const sx = x + 8 + ((i * 29) % Math.max(14, w - 16));
      ctx.strokeStyle = ["#ff4d94", "#5ff2ff", "#ffe066", "#a06bff"][i % 4];
      ctx.beginPath();
      ctx.moveTo(sx, y + 8);
      ctx.lineTo(sx + 4, y + 11);
      ctx.stroke();
    }
  }
  if (theme === 11 && (kind === "normal" || kind === "crumble")) {
    // stone block seams
    ctx.strokeStyle = "rgba(12,8,18,0.6)";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    for (let px2 = x + 22; px2 < x + w - 6; px2 += 22) {
      ctx.moveTo(px2, y + 6);
      ctx.lineTo(px2, y + h - 1);
    }
    ctx.stroke();
  }
  if (theme === 2 && (kind === "normal" || kind === "spring")) {
    ctx.strokeStyle = `rgba(255,140,40,${0.55 + 0.3 * Math.sin(t * 4 + x)})`;
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(x + w * 0.25, y + 7);
    ctx.lineTo(x + w * 0.33, y + 11);
    ctx.lineTo(x + w * 0.42, y + 8);
    ctx.moveTo(x + w * 0.65, y + 8);
    ctx.lineTo(x + w * 0.74, y + 12);
    ctx.stroke();
  }
  switch (kind) {
    case "crumble":
      ctx.strokeStyle = OUT;
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.moveTo(x + w * 0.3, y + 3);
      ctx.lineTo(x + w * 0.38, y + 8);
      ctx.lineTo(x + w * 0.33, y + h - 1);
      ctx.moveTo(x + w * 0.7, y + 3);
      ctx.lineTo(x + w * 0.63, y + 9);
      ctx.stroke();
      break;
    case "moving":
      ctx.fillStyle = "rgba(255,255,255,0.8)";
      ctx.beginPath();
      ctx.arc(x + 8, y + h / 2 + 2, 1.8, 0, Math.PI * 2);
      ctx.arc(x + w - 8, y + h / 2 + 2, 1.8, 0, Math.PI * 2);
      ctx.fill();
      break;
    case "ice":
      ctx.strokeStyle = "rgba(255,255,255,0.9)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(x + w * 0.2, y + 12);
      ctx.lineTo(x + w * 0.28, y + 6.5);
      ctx.moveTo(x + w * 0.55, y + 12);
      ctx.lineTo(x + w * 0.63, y + 6.5);
      ctx.stroke();
      break;
    case "wooden":
      ctx.strokeStyle = "rgba(40,20,5,0.55)";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      for (let px = x + 14; px < x + w - 8; px += 16) {
        ctx.moveTo(px, y + 6.5);
        ctx.lineTo(px, y + h - 1);
      }
      ctx.stroke();
      break;
    case "sand":
      ctx.fillStyle = "rgba(120,70,10,0.45)";
      for (let i = 0; i < 6; i++) {
        ctx.beginPath();
        ctx.arc(x + 8 + ((i * 37) % Math.max(10, w - 16)), y + 8 + (i % 3) * 2, 1.2, 0, Math.PI * 2);
        ctx.fill();
      }
      break;
    case "temp":
      if (theme === 2) {
        for (let i = 0; i < 3; i++) {
          const fx = x + w * (0.22 + i * 0.28);
          const fh = 7 + 3 * Math.sin(t * 9 + i * 2);
          ctx.fillStyle = i === 1 ? "#ffe066" : "#ff7a18";
          ctx.beginPath();
          ctx.moveTo(fx - 4, y + 1);
          ctx.quadraticCurveTo(fx - 3, y - fh * 0.6, fx, y - fh);
          ctx.quadraticCurveTo(fx + 3, y - fh * 0.6, fx + 4, y + 1);
          ctx.closePath();
          ctx.fill();
        }
      } else {
        ctx.strokeStyle = "rgba(255,255,255,0.75)";
        ctx.setLineDash([4, 4]);
        ctx.lineWidth = 1.6;
        rr(ctx, x + 3, y + 3, w - 6, h - 6, 4);
        ctx.stroke();
        ctx.setLineDash([]);
      }
      break;
    case "ghost":
      // wispy bottom edge
      ctx.fillStyle = trim;
      ctx.beginPath();
      for (let i = 0; i < 4; i++) {
        const cx = x + (w / 4) * (i + 0.5);
        ctx.moveTo(cx - 6, y + h - 2);
        ctx.quadraticCurveTo(cx, y + h + 8 + Math.sin(t * 4 + i) * 3, cx + 6, y + h - 2);
      }
      ctx.fill();
      break;
    case "electric": {
      const push = o.push ?? 0;
      if (push !== 0) {
        ctx.fillStyle = "rgba(95,242,255,0.95)";
        for (let i = 0; i < 3; i++) {
          const ax = x + w * (0.25 + i * 0.25) + push * 6;
          ctx.beginPath();
          ctx.moveTo(ax + push * 6, y + 8);
          ctx.lineTo(ax - push * 2, y + 4.5);
          ctx.lineTo(ax - push * 2, y + 11.5);
          ctx.closePath();
          ctx.fill();
        }
      }
      const ch = o.charge ?? 0;
      if (ch > 0) {
        ctx.strokeStyle = `rgba(255,90,214,${0.5 + 0.5 * ch})`;
        ctx.lineWidth = 2;
        ctx.beginPath();
        for (let i = 0; i < 4; i++) {
          const ax = x + 6 + (i + 0.5) * ((w - 12) / 4);
          ctx.moveTo(ax, y + 1);
          ctx.lineTo(ax + (Math.random() - 0.5) * 8, y - 5 - ch * 7);
          ctx.lineTo(ax + (Math.random() - 0.5) * 10, y - 11 - ch * 8);
        }
        ctx.stroke();
      }
      break;
    }
    case "asteroid":
      ctx.fillStyle = "rgba(20,18,40,0.55)";
      for (let i = 0; i < 3; i++) {
        ctx.beginPath();
        ctx.arc(x + 12 + i * (w / 3.4), y + 8.5, 2.6 - (i % 2), 0, Math.PI * 2);
        ctx.fill();
      }
      break;
    case "sticky":
      // dripping goo
      ctx.fillStyle = "rgba(255,150,210,0.9)";
      for (let i = 0; i < 3; i++) {
        const dx = x + 12 + i * ((w - 24) / 2);
        const dl = 3 + Math.abs(Math.sin(t * 2 + i * 1.7)) * 6;
        ctx.beginPath();
        ctx.moveTo(dx - 2.6, y + h - 2);
        ctx.lineTo(dx + 2.6, y + h - 2);
        ctx.quadraticCurveTo(dx, y + h + dl, dx - 2.6, y + h - 2);
        ctx.fill();
      }
      break;
    case "jelly":
      ctx.fillStyle = "rgba(255,255,255,0.5)";
      ctx.beginPath();
      ctx.ellipse(x + w * 0.3, y + 4, w * 0.12, 2.2, -0.2, 0, Math.PI * 2);
      ctx.fill();
      break;
    case "spring": {
      const cx = x + w / 2;
      ctx.strokeStyle = "#cfd6e0";
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      ctx.moveTo(cx - 7, y);
      ctx.lineTo(cx + 7, y - 3);
      ctx.lineTo(cx - 7, y - 6);
      ctx.lineTo(cx + 7, y - 9);
      ctx.stroke();
      ctx.fillStyle = "#ff4d5e";
      ctx.strokeStyle = OUT;
      ctx.lineWidth = 2.2;
      rr(ctx, cx - 12, y - 14, 24, 6, 3);
      ctx.fill();
      ctx.stroke();
      break;
    }
    default:
      break;
  }
  ctx.restore();
}

/** Wrapped candy bonus (Candy Kingdom) — worth more than a coin. */
export function drawCandy(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, spin: number) {
  const sx = Math.max(0.3, Math.abs(Math.cos(spin)));
  ctx.save();
  ctx.translate(x, y);
  const glow = ctx.createRadialGradient(0, 0, 2, 0, 0, r * 2.2);
  glow.addColorStop(0, "rgba(255,150,220,0.5)");
  glow.addColorStop(1, "rgba(255,150,220,0)");
  ctx.fillStyle = glow;
  ctx.beginPath();
  ctx.arc(0, 0, r * 2.2, 0, Math.PI * 2);
  ctx.fill();
  ctx.scale(sx, 1);
  ctx.lineWidth = 2.2;
  ctx.strokeStyle = OUT;
  // wrapper twists
  for (const s2 of [-1, 1]) {
    ctx.fillStyle = "#fff0f8";
    ctx.beginPath();
    ctx.moveTo(s2 * r * 0.85, 0);
    ctx.lineTo(s2 * r * 1.7, -r * 0.7);
    ctx.lineTo(s2 * r * 1.5, 0);
    ctx.lineTo(s2 * r * 1.7, r * 0.7);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }
  const g = ctx.createLinearGradient(0, -r, 0, r);
  g.addColorStop(0, "#ffd6ef");
  g.addColorStop(0.5, "#ff6ab8");
  g.addColorStop(1, "#d62e86");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(0, 0, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.strokeStyle = "rgba(255,255,255,0.9)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.55, 0.4, 2.4);
  ctx.stroke();
  ctx.restore();
}

export function drawCoin(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, spin: number) {
  const sx = Math.max(0.18, Math.abs(Math.cos(spin)));
  ctx.save();
  ctx.translate(x, y);
  // glow
  const glow = ctx.createRadialGradient(0, 0, 2, 0, 0, r * 2);
  glow.addColorStop(0, "rgba(255,220,80,0.45)");
  glow.addColorStop(1, "rgba(255,220,80,0)");
  ctx.fillStyle = glow;
  ctx.beginPath();
  ctx.arc(0, 0, r * 2, 0, Math.PI * 2);
  ctx.fill();
  ctx.scale(sx, 1);
  ctx.lineWidth = 2.2;
  ctx.strokeStyle = "#5a3300";
  const g = ctx.createLinearGradient(0, -r, 0, r);
  g.addColorStop(0, "#fff08a");
  g.addColorStop(1, "#f59e0b");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(0, 0, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.lineWidth = 1.6;
  ctx.strokeStyle = "rgba(160,90,0,0.8)";
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.58, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();
}
