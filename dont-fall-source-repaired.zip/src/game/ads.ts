// AdMob service — a safe, never-blocking wrapper around @capacitor-community/admob.
//
// Rules enforced here:
//  - On web (and anywhere the native plugin is absent) every method is a no-op that
//    resolves immediately, so the game behaves exactly as it did before ads existed.
//  - Consent (UMP) is collected before initialization; ads only load when the
//    platform says ads may be requested.
//  - If initialization fails (temporary network issue or native view not ready yet),
//    `this.initializing` is cleared so later calls can retry cleanly.
//  - Rewarded rewards are granted ONLY from the official AdMob reward callback
//    (RewardAdPluginEvents.Rewarded / showRewardVideoAd resolution), never from Dismissed.
//  - Every call is guarded so an ad failure can never break gameplay, menus or saves.

import { Capacitor } from "@capacitor/core";
import {
  AdMob,
  AdmobConsentStatus,
  BannerAdPluginEvents,
  BannerAdPosition,
  BannerAdSize,
  RewardAdPluginEvents,
} from "@capacitor-community/admob";
import { ADMOB, IS_TEST_ADS } from "./ads-config";

export type RewardKind = "revive" | "coins";

const isNative = () => Capacitor.isNativePlatform();

class AdsService {
  private ready = false;
  private initializing: Promise<boolean> | null = null;
  private initAttempts = 0;
  private bannerVisible = false;
  private bannerHeight = 0;
  private bannerSubscribers = new Set<(px: number) => void>();
  private interstitialReady = false;
  private interstitialLoading = false;
  private interstitialLoadedId: string | null = null;
  private interstitialShownCount = 0;
  private rewardedReady: Partial<Record<RewardKind, string>> = {};
  private rewardedLoading: Partial<Record<RewardKind, boolean>> = {};
  private bannerListeners: { remove: () => Promise<void> }[] = [];

  /**
   * Consent (UMP) → initialize.
   * Safe to call repeatedly. If an attempt fails (offline or native activity not ready),
   * `this.initializing` is cleared in `finally` so subsequent calls retry cleanly.
   */
  async init(): Promise<boolean> {
    if (!isNative()) return false;
    if (this.ready) return true;
    if (this.initializing) return this.initializing;

    this.initAttempts++;
    this.initializing = (async () => {
      try {
        let consent = await AdMob.requestConsentInfo();
        if (consent.isConsentFormAvailable && consent.status === AdmobConsentStatus.REQUIRED) {
          consent = await AdMob.showConsentForm();
        }
        if (!consent.canRequestAds) {
          this.ready = false;
          return false;
        }
        await AdMob.initialize();
        this.ready = true;
        return true;
      } catch {
        this.ready = false; // no internet, no consent, or SDK unavailable — retry allowed later
        return false;
      } finally {
        this.initializing = null;
      }
    })();

    return this.initializing;
  }

  // ---------------------------------------------------------------- Banner
  /**
   * Registers a screen (Main Menu, Character Shop, Ability Shop) that wants the bottom banner.
   * Returns an unsubscribe function that removes the banner when no allowed screen remains mounted.
   */
  subscribeBanner(onHeight: (px: number) => void): () => void {
    this.bannerSubscribers.add(onHeight);
    if (this.bannerVisible && this.bannerHeight > 0) {
      onHeight(this.bannerHeight);
    } else {
      void this.showBanner();
    }
    return () => {
      this.bannerSubscribers.delete(onHeight);
      if (this.bannerSubscribers.size === 0) {
        void this.removeBanner();
      }
    };
  }

  private notifyBannerHeight(px: number) {
    this.bannerHeight = px;
    for (const cb of this.bannerSubscribers) cb(px);
  }

  /** Shows the adaptive bottom banner if at least one allowed screen is mounted. */
  async showBanner(onHeight?: (px: number) => void): Promise<void> {
    if (onHeight) this.bannerSubscribers.add(onHeight);
    if (!isNative()) return;
    if (!(await this.init())) return;
    if (this.bannerSubscribers.size === 0) return;
    if (this.bannerVisible) {
      onHeight?.(this.bannerHeight);
      return;
    }
    try {
      if (!this.bannerListeners.length) {
        this.bannerListeners = await Promise.all([
          AdMob.addListener(BannerAdPluginEvents.SizeChanged, (size) => {
            this.notifyBannerHeight(size.height);
          }),
          AdMob.addListener(BannerAdPluginEvents.FailedToLoad, () => {
            this.bannerVisible = false;
            this.notifyBannerHeight(0);
          }),
        ]);
      }
      await AdMob.showBanner({
        adId: ADMOB.banner,
        adSize: BannerAdSize.ADAPTIVE_BANNER,
        position: BannerAdPosition.BOTTOM_CENTER,
        margin: 0,
        isTesting: IS_TEST_ADS,
      });
      this.bannerVisible = true;
    } catch {
      this.bannerVisible = false;
      this.notifyBannerHeight(0);
    }
  }

  async hideBanner(): Promise<void> {
    if (!isNative() || !this.bannerVisible) return;
    try {
      await AdMob.hideBanner();
      this.bannerVisible = false;
    } catch {
      /* ignore */
    }
  }

  async removeBanner(): Promise<void> {
    if (!isNative()) return;
    try {
      await AdMob.removeBanner();
    } catch {
      /* ignore */
    }
    this.bannerVisible = false;
    this.notifyBannerHeight(0);
  }

  getBannerHeight(): number {
    return this.bannerHeight;
  }

  // ---------------------------------------------------------- Interstitial
  async prepareInterstitial(): Promise<void> {
    if (!isNative() || this.interstitialReady || this.interstitialLoading) return;
    if (!(await this.init())) return;
    this.interstitialLoading = true;
    try {
      const info = await AdMob.prepareInterstitial({ adId: ADMOB.interstitial, isTesting: IS_TEST_ADS });
      this.interstitialLoadedId = info?.adUnitId ?? ADMOB.interstitial;
      this.interstitialReady = true;
    } catch {
      this.interstitialReady = false;
      this.interstitialLoadedId = null;
    } finally {
      this.interstitialLoading = false;
    }
  }

  /** Shows a prepared interstitial. Resolves true if one was actually displayed. */
  async showInterstitial(): Promise<boolean> {
    if (!isNative()) return false;
    if (!this.interstitialReady) {
      await this.prepareInterstitial();
      if (!this.interstitialReady) return false;
    }
    try {
      const targetId = this.interstitialLoadedId ?? ADMOB.interstitial;
      await AdMob.showInterstitial({ adId: targetId });
      this.interstitialReady = false;
      this.interstitialLoadedId = null;
      this.interstitialShownCount++;
      void this.prepareInterstitial(); // preload for the next 3-round milestone
      return true;
    } catch {
      this.interstitialReady = false;
      this.interstitialLoadedId = null;
      return false;
    }
  }

  // -------------------------------------------------------------- Rewarded
  private rewardedId(kind: RewardKind): string {
    return kind === "revive" ? ADMOB.rewardedRevive : ADMOB.rewardedCoins;
  }

  async prepareRewarded(kind: RewardKind): Promise<void> {
    if (!isNative() || this.rewardedReady[kind] || this.rewardedLoading[kind]) return;
    if (!(await this.init())) return;
    this.rewardedLoading[kind] = true;
    try {
      const info = await AdMob.prepareRewardVideoAd({ adId: this.rewardedId(kind), isTesting: IS_TEST_ADS });
      this.rewardedReady[kind] = info?.adUnitId ?? this.rewardedId(kind);
    } catch {
      delete this.rewardedReady[kind];
    } finally {
      this.rewardedLoading[kind] = false;
    }
  }

  /**
   * Shows a rewarded ad. Resolves with the earned reward item ONLY when the official
   * AdMob reward confirmation fires; resolves null when the ad fails, is closed early
   * without earning the reward, or is unavailable.
   */
  async showRewarded(kind: RewardKind): Promise<{ type: string; amount: number } | null> {
    if (!isNative()) return null;
    if (!this.rewardedReady[kind]) {
      await this.prepareRewarded(kind);
      if (!this.rewardedReady[kind]) return null;
    }
    const targetId = this.rewardedReady[kind]!;
    delete this.rewardedReady[kind];

    const handles: { remove: () => Promise<void> }[] = [];
    let earned: { type: string; amount: number } | null = null;

    try {
      const outcome = await new Promise<{ type: string; amount: number } | null>((resolve) => {
        let settled = false;
        const finish = (val: { type: string; amount: number } | null) => {
          if (settled) return;
          settled = true;
          resolve(val);
        };

        void (async () => {
          try {
            handles.push(
              await AdMob.addListener(RewardAdPluginEvents.Rewarded, (reward) => {
                if (reward && typeof reward.amount === "number") {
                  earned = { type: reward.type ?? kind, amount: reward.amount };
                }
              }),
              await AdMob.addListener(RewardAdPluginEvents.FailedToShow, () => {
                finish(null);
              }),
              await AdMob.addListener(RewardAdPluginEvents.Dismissed, () => {
                // Allow any queued Rewarded event on the bridge to arrive before settling.
                window.setTimeout(() => finish(earned), 40);
              }),
            );
            const direct = await AdMob.showRewardVideoAd({ adId: targetId });
            if (direct && typeof direct.amount === "number") {
              earned = { type: direct.type ?? kind, amount: direct.amount };
              finish(earned);
            }
          } catch {
            finish(null);
          }
        })();
      });
      void this.prepareRewarded(kind);
      return outcome;
    } finally {
      for (const h of handles) {
        try {
          await h.remove();
        } catch {
          /* ignore */
        }
      }
    }
  }

  isRewardedReady(kind: RewardKind): boolean {
    return !!this.rewardedReady[kind];
  }

  /** Test/debug visibility into the service state. */
  debugState() {
    return {
      native: isNative(),
      ready: this.ready,
      initializing: this.initializing !== null,
      initAttempts: this.initAttempts,
      env: IS_TEST_ADS ? "test" : "production",
      banner: this.bannerVisible,
      bannerSubscribers: this.bannerSubscribers.size,
      bannerHeight: this.bannerHeight,
      interstitialReady: this.interstitialReady,
      interstitialShownCount: this.interstitialShownCount,
      rewardedReady: { ...this.rewardedReady },
    };
  }
}

export const ads = new AdsService();
