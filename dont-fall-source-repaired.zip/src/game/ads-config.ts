// AdMob configuration — the ONLY place ad unit IDs live.
//
// Test vs production is chosen at BUILD time by Vite (import.meta.env), never by
// runtime detection.
//
// SAFE DEFAULT: Google test ads. Real AdMob IDs are selected ONLY when
// VITE_ADMOB_ENV is explicitly set to "production". A missing, empty or
// unrecognised value always resolves to "development" (Google test App ID and
// test ad units), so no build can accidentally serve live ads.
//
//   npm run build                            -> Google test IDs (safe default)
//   VITE_ADMOB_ENV=production npm run build  -> real production IDs (opt-in)
//
// The matching Android App ID is applied natively by native-android/patch-manifest.py
// (same VITE_ADMOB_ENV switch and same fallback), because the App ID lives in
// AndroidManifest.xml.
//
// NOTE: this exact rule is mirrored in native-android/patch-manifest.py — keep both
// in sync. Only an explicit "production" (case-insensitive, surrounding whitespace
// ignored) selects production; anything else selects development.

export type AdEnv = "production" | "development";

/** Normalised build-time environment flag. Missing/empty => "". */
const RAW_ADMOB_ENV = (import.meta.env.VITE_ADMOB_ENV ?? "").toString().trim().toLowerCase();

/** Production only on an explicit "production"; every other value is the safe test default. */
export const ADMOB_ENV: AdEnv = RAW_ADMOB_ENV === "production" ? "production" : "development";

export const IS_TEST_ADS = ADMOB_ENV === "development";

const IDS = {
  production: {
    appId: "ca-app-pub-4047064090575681~7263910675",
    banner: "ca-app-pub-4047064090575681/5123611304",
    interstitial: "ca-app-pub-4047064090575681/1101614971",
    rewardedRevive: "ca-app-pub-4047064090575681/1922732896",
    rewardedCoins: "ca-app-pub-4047064090575681/5151531467",
  },
  development: {
    appId: "ca-app-pub-3940256099942544~3347511713",
    banner: "ca-app-pub-3940256099942544/6300978111",
    interstitial: "ca-app-pub-3940256099942544/1033173712",
    rewardedRevive: "ca-app-pub-3940256099942544/5224354917",
    rewardedCoins: "ca-app-pub-3940256099942544/5224354917",
  },
} as const;

export const ADMOB = IDS[ADMOB_ENV];

/** Interstitial frequency: one after every N completed rounds. */
export const INTERSTITIAL_EVERY = 3;

/** Rewarded revive: at most this many per round. */
export const MAX_REVIVES_PER_ROUND = 1;

/** Rewarded coins: one double-coins offer per completed round. */
export const MAX_COIN_DOUBLES_PER_ROUND = 1;
