// DON'T FALL game engine.
// Core physics / controls / lava / difficulty are the original ones. On top of that: 20 worlds, extra platform
// types, world hazards, power-ups, weather and run statistics.

import { audio } from "./audio";
import { drawCandy, drawCoin, drawPlatform, drawPlayer, type PlatAnim, type PlatformKind } from "./sprites";
import type { Skin } from "./skins";
import {
  POWER_COLOR, POWER_NAME, WARN_COLOR, drawBoss, drawCactus, drawBlade, drawHazard, drawLaser, drawPlant,
  drawPowerup, drawSpikes, drawWarning, type HazKind, type PowerType,
} from "./hazards";
import { BOSS_TAIL, WORLDS, WORLD_LEN, drawWorldBackground, hash, worldAt, worldLabel, worldTitle, type WorldInfo } from "./worlds";
import type { RunStats } from "./progression";
import { abilityById, type AbilityDef } from "./abilities";
import {
  DRAGON_WORLD, EXPANSION_HAZARDS, EXPANSION_KINDS, drawExpansionAmbient, drawExpansionHazard,
  drawExpansionMounted, drawExpansionPlatform, drawRune, expansionMountedHit, expansionPlatform,
  updateExpansionAmbient,
} from "./stages13to20";
import { DragonFight, drawDragon, type DragonAttack } from "./dragon";

export const WORLD_W = 360;

// --- tuning (original gameplay constants) ----------------------------------------------------------
const GRAVITY = 1400;
const JUMP_V = 720;
const MOVE_SPEED = 230;
// Widest drawn extent of the hero: backpack / hat brim (~17) x squash factor (1/sqrt(0.7)) + outline.
// Used only to clamp against the solid side boundaries, so the sprite is never clipped by the screen edge.
const PLAYER_VISUAL_W = 22;
const SCORE_DIV = 10; // world px per meter

// --- new, clearly defined special physics ----------------------------------------------------------
const SPRING_MULT = 1.32; // spring platforms bounce higher
const SLIP_TIME = 0.55; // ice: steering is sluggish for the first part of the flight
const SLIP_K = 3; // (normal steering uses 10)
const STICK_MUL = 0.55; // sticky (candy) platforms slow horizontal control for a moment
const STICK_TIME = 0.7;
const JELLY_MULT = 1.22; // jelly platforms bounce higher
const BUBBLE_MULT = 1.08;
const GHOST_CYCLE = 3.6; // phantom platforms phase out of existence for a while
const GHOST_GONE = 1.25;
const GHOST_FADE = 0.4;
const CONVEYOR_PUSH = 105; // electric platform sideways kick
const LOW_G = 0.75; // outer space gravity multiplier
const LOW_G_JUMP = 0.95; // ... and its jump impulse, so jumps stay controllable
const LASER_WARN = 1.3; // telegraph time before a cyber beam fires
const LASER_FIRE = 1.15;
const BOSS_ATK = 1.85;
const ROCKET_V = 860;
const ROCKET_TIME = 1.25;
const PLAYER_R = 11; // forgiving hit circle, centred 26px above the feet

export const POWER_DURATION: Record<PowerType, number> = { shield: 25, magnet: 9, double: 12, rocket: ROCKET_TIME, slow: 8 };

const FRAGILE_DUR: Partial<Record<PlatformKind, number>> = { crumble: 0.5, sand: 0.9, temp: 1.5, ice: 1.9, toyblock: 0.85, obsidian: 0.72 };
const isFragile = (k: PlatformKind) => k === "crumble" || k === "sand" || k === "temp" || k === "toyblock" || k === "obsidian";

export interface HudPower {
  type: PowerType;
  frac: number;
}
export interface HudState {
  score: number;
  distance: number;
  bonus: number;
  coins: number;
  powers: HudPower[];
  boss: number; // 0..1 progress through the Warden encounter, -1 when inactive
  dragon: { hp: number; maxHp: number; phase: number } | null;
  /** Equipped character ability, with remaining cooldown for the in-game button. */
  ability: { id: string; name: string; ready: boolean; frac: number; charges: number } | null;
}
export interface WorldEvent {
  seg: number;
  index: number;
  loop: number;
  name: string;
  label: string;
  subtitle: string;
  accent: string;
}
export interface GameCallbacks {
  onHud: (h: HudState) => void;
  onCoin: (amount: number) => void;
  onWorld: (w: WorldEvent) => void;
  onGameOver: (r: RunStats) => void;
  onVictory: (r: RunStats & { fightTime: number }) => void;
  /** Rewarded-revive request (Game Over screen). */
  onRevive?: () => void;
}
export interface GameOptions {
  startMeters?: number;
  /** Equipped character ability id (owned + equipped, validated by the caller). */
  ability?: string | null;
  boss?: boolean; // jump straight into a Warden encounter
  god?: boolean;
  bot?: boolean;
}

interface PlatHaz {
  type: "plant" | "cactus" | "spike" | "blade" | "press" | "pendulum" | "clockhand";
  side: number;
  phase: number;
  warned: boolean;
}
interface Beam {
  y: number;
  x0: number;
  x1: number;
  state: 0 | 1;
  t: number;
}
interface Bonus {
  x: number;
  y: number;
  taken: boolean;
  phase: number;
}
interface Platform {
  x: number;
  y: number;
  w: number;
  kind: PlatformKind;
  theme: number;
  dir: number;
  speed: number;
  crumbling: boolean;
  crumbleT: number;
  dead: boolean;
  haz?: PlatHaz;
  y0: number; // base y for bobbing platforms
  phase: number;
  push: number; // conveyor direction (electric)
  baseX: number; // expansion platforms: fixed anchor for orbital/piston movement
  rune?: boolean; // dragon arena damage rune
  runeTaken?: boolean;
}
interface Coin {
  x: number;
  y: number;
  taken: boolean;
  phase: number;
}
interface PowerItem {
  x: number;
  y: number;
  type: PowerType;
  taken: boolean;
  phase: number;
}
interface Hazard {
  kind: HazKind;
  x: number;
  y: number; // lower-centre point
  vx: number;
  vy: number;
  g: number;
  r: number;
  c0: number; // collision segment from y-c0 ...
  c1: number; // ... to y-c1
  warn: number; // seconds of warning left (hazard not active yet)
  dir: number;
  ph: number; // sway / animation phase
  homing?: number;
  dead: boolean;
  near: boolean;
  awarded: boolean;
}
interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  color: string;
  size: number;
}
interface FloatText {
  x: number;
  y: number;
  text: string;
  color: string;
  life: number;
}
interface Amb {
  x: number;
  y: number;
  s: number;
  ph: number;
  rot: number;
}

const FALL_SPEC: Record<string, { r: number; c0: number; c1: number }> = {
  icicle: { r: 7, c0: 3, c1: 30 },
  rock: { r: 9, c0: 2, c1: 22 },
  firerock: { r: 11, c0: 11, c1: 11 },
  fruit: { r: 10, c0: 10, c1: 10 },
  star: { r: 10, c0: 11, c1: 11 },
  fireball: { r: 11, c0: 11, c1: 11 },
  bird: { r: 11, c0: 12, c1: 12 },
  jellyfish: { r: 11, c0: 4, c1: 28 },
  fish: { r: 11, c0: 12, c1: 12 },
  spore: { r: 10, c0: 10, c1: 14 },
  ghost: { r: 12, c0: 12, c1: 24 },
  drone: { r: 11, c0: 12, c1: 12 },
  meteor: { r: 11, c0: 8, c1: 18 },
  candy: { r: 9, c0: 9, c1: 13 },
  skull: { r: 11, c0: 12, c1: 14 },
  bossfire: { r: 10, c0: 10, c1: 10 },
  cog: { r: 11, c0: 10, c1: 17 },
  sporeseed: { r: 10, c0: 9, c1: 16 },
  cannonball: { r: 11, c0: 12, c1: 12 },
  toyball: { r: 12, c0: 12, c1: 12 },
  train: { r: 18, c0: 15, c1: 15 },
  soundwave: { r: 14, c0: 18, c1: 18 },
  bookdrop: { r: 12, c0: 9, c1: 18 },
  dragonfire: { r: 11, c0: 10, c1: 10 },
  shockwave: { r: 14, c0: 0, c1: 24 },
};
// hazards that cross the screen horizontally (telegraphed from the side)
const MOVER_KINDS = new Set<HazKind>(["bird", "fish", "ghost", "drone", "skull", "cannonball", "train", "soundwave", "shockwave"]);

// which falling hazard each world drops (cave only in endless levels)
// falling hazard per world (cave only in endless levels)
const FALL_KIND: (HazKind | null)[] = ["rock", "icicle", "firerock", "fruit", null, "star", "jellyfish", "spore", null, "meteor", "candy", null, "cog", null, null, null, "toyball", null, "bookdrop", null];
// horizontally crossing hazard per world
const MOVER_KIND: Partial<Record<number, HazKind>> = { 4: "bird", 6: "fish", 7: "ghost", 8: "drone", 11: "skull", 14: "cannonball", 16: "train", 17: "soundwave" };
// per-world moving-platform speed multiplier ("fast-moving platforms" in Cyber City)
const SPEED_MUL: number[] = [1, 1, 1, 1, 1, 1, 0.85, 1, 1.65, 1.1, 1, 1.15];

// platform kind tables per world: [kind, base chance, extra chance at full difficulty]
const KIND_TABLE: Record<number, [PlatformKind, number, number][]> = {
  1: [["ice", 0.22, 0.18], ["moving", 0.08, 0.12], ["crumble", 0.06, 0.1], ["spring", 0.06, 0]],
  2: [["temp", 0.18, 0.12], ["moving", 0.08, 0.1], ["crumble", 0.08, 0.08], ["spring", 0.05, 0]],
  3: [["wooden", 0.28, 0.12], ["crumble", 0.07, 0.07], ["spring", 0.07, 0]],
  4: [["sand", 0.26, 0.14], ["moving", 0.08, 0.1], ["spring", 0.05, 0]],
  5: [["moving", 0.28, 0.12], ["temp", 0.1, 0.1], ["spring", 0.07, 0]],
  6: [["bubble", 0.3, 0.12], ["moving", 0.1, 0.1], ["spring", 0.05, 0]],
  7: [["ghost", 0.3, 0.14], ["wooden", 0.12, 0.06], ["crumble", 0.05, 0.07], ["spring", 0.05, 0]],
  8: [["electric", 0.26, 0.12], ["moving", 0.24, 0.14], ["temp", 0.08, 0.08]],
  9: [["asteroid", 0.32, 0.14], ["crumble", 0.08, 0.1], ["moving", 0.1, 0.08], ["spring", 0.05, 0]],
  10: [["sticky", 0.24, 0.12], ["jelly", 0.24, 0.1], ["crumble", 0.05, 0.06]],
  11: [["crumble", 0.26, 0.18], ["temp", 0.1, 0.1], ["moving", 0.12, 0.12], ["sand", 0.06, 0.06]],
  12: [["piston", 0.46, 0.08], ["moving", 0.1, 0.06], ["spring", 0.05, 0]],
  13: [["mushroom", 0.52, 0.08], ["spring", 0.06, 0]],
  14: [["ship", 0.5, 0.08], ["wooden", 0.12, 0.04], ["crumble", 0.05, 0.05]],
  15: [["clock", 0.48, 0.08], ["moving", 0.1, 0.04], ["spring", 0.04, 0]],
  16: [["toyblock", 0.5, 0.08], ["moving", 0.1, 0.04], ["spring", 0.04, 0]],
  17: [["note", 0.52, 0.08], ["moving", 0.08, 0.04], ["spring", 0.04, 0]],
  18: [["book", 0.5, 0.08], ["moving", 0.1, 0.04], ["crumble", 0.05, 0.04]],
  19: [["obsidian", 0.42, 0.08], ["crumble", 0.1, 0.05], ["spring", 0.05, 0]],
};

const AMB_MAX = 96;

function segDist(px: number, py: number, x: number, y0: number, y1: number): number {
  // distance from point to vertical segment (x, y0..y1) with y0 <= y1
  const cy = Math.max(y0, Math.min(y1, py));
  return Math.hypot(px - x, py - cy);
}

function plantStage(t: number, phase: number): { stage: 0 | 1 | 2; u: number } {
  const c = (t + phase) % 3;
  if (c < 1.9) return { stage: 0, u: c / 1.9 };
  if (c < 2.6) return { stage: 1, u: (c - 1.9) / 0.7 };
  return { stage: 2, u: (c - 2.6) / 0.4 };
}

export class Game {
  private ctx: CanvasRenderingContext2D;
  private raf = 0;
  private last = 0;
  private time = 0;
  private scale = 1;
  private viewH = 640;

  private platforms: Platform[] = [];
  private coins: Coin[] = [];
  private powerItems: PowerItem[] = [];
  private hazards: Hazard[] = [];
  private particles: Particle[] = [];
  private texts: FloatText[] = [];
  private amb: Amb[] = [];
  private genY = 0;
  private lastWasFragile = false;
  private lastWasIce = false;
  private lastCenter = WORLD_W / 2;
  private hazCooldown = 0;
  private puCooldown = 0;

  private px = WORLD_W / 2;
  private py = 0;
  private vx = 0;
  private vy = 0;
  private facing = 1;
  private stretch = 1;
  private camY = 0;
  private lavaY = 260;
  private startY = 0;
  private startMax = 0;
  private maxHeight = 0;
  private dist = 0;
  private bonus = 0;
  private runCoins = 0;
  private dir = 0;
  private paused = false;
  private state: "playing" | "dying" | "over" | "victory" = "playing";
  private deathBy: "lava" | "hazard" = "lava";
  private dyingT = 0;

  // run stats
  private playTime = 0;
  private platformsLanded = 0;
  private powerupsTaken = 0;
  private nearMisses = 0;

  // worlds
  private curSeg = 0;
  private curIdx = 0;
  private curLoop = 0;
  private prevIdx = 0;
  private transT = 1;
  private maxSeg = 0;

  // power-up timers
  private shieldT = 0;
  private magnetT = 0;
  private doubleT = 0;
  private slowT = 0;
  private rocketT = 0;
  private invulnT = 0;
  private slipT = 0;

  // hazards / weather timers
  private fallT = 3.5;
  private eruptT = 6;
  private stormTimer = 8;
  private stormOn = false;
  private storm = 0;
  private windState = 0; // 0 idle, 1 warning, 2 gust
  private windTimer = 8;
  private windDir = 1;
  private wind = 0;
  private windTarget = 0;

  private hudT = 0;
  private lastWallHit = -1;
  private beamT = 6;
  private beams: Beam[] = [];
  private candies: Bonus[] = [];
  private candiesEaten = 0;
  private bossKills = 0;
  private boss = { active: false, t: 0, atk: 0, open: 0, hurt: 0, x: WORLD_W / 2, surge: 0, done: -1 };
  private gripT = 0;
  private moverT = 5;
  private god: boolean;
  private bot: boolean;
  private optsBoss: boolean;
  private dragon = new DragonFight();
  private dragonActive = false;
  private dragonTime = 0;
  private dragonReported = false;
  private dragonTargets: Platform[] = [];
  private runeCounter = 0;
  private expansionT = 2.5;
  private trapCounter = 0;
  private foughtBoss = false;

  // --- equipped character ability ---
  private abilityDef: AbilityDef | null = null;
  private abilityCd = 0;
  private abilityCharges = 0;
  private speedT = 0; // Overclock
  private lowgT = 0; // Zero-G Suit
  private slowFallT = 0; // Wing Beat
  private slowHazT = 0; // Time Warp
  private auraT = 0; // Molten Aura
  private balanceT = 0; // Perfect Balance
  private mistT = 0; // Mist Form
  private superBounce = 0; // Avalanche Ride (charges)

  constructor(private canvas: HTMLCanvasElement, private skin: Skin, private cb: GameCallbacks, opts: GameOptions = {}) {
    this.ctx = canvas.getContext("2d")!;
    this.optsBoss = !!opts.boss;
    this.setAbility(opts.ability ?? null);
    this.god = !!opts.god;
    this.bot = !!opts.bot;
    for (let i = 0; i < AMB_MAX; i++) this.amb.push({ x: Math.random() * WORLD_W, y: Math.random() * 640, s: Math.random(), ph: Math.random() * 6.28, rot: Math.random() * 6.28 });
    this.reset(opts.startMeters ?? 0);
  }

  // --- public API ------------------------------------------------------------------------------------
  start() {
    this.last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(0.033, (now - this.last) / 1000);
      this.last = now;
      if (!this.paused && this.state !== "over") this.update(dt);
      this.time += this.paused ? 0 : dt;
      this.render();
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  }

  destroy() {
    cancelAnimationFrame(this.raf);
  }

  setPaused(p: boolean) {
    this.paused = p;
  }

  /** Resumes a run after losing (rewarded revive). Returns false if not applicable. */
  revive(): boolean {
    if (this.state !== "dying" && this.state !== "over") return false;
    this.state = "playing";
    this.dyingT = 0;
    this.dir = 0;
    this.vx = 0;
    // Lift the player back into the safe upper-middle of the camera view above lava
    const safeY = Math.min(this.py, this.camY + this.viewH * 0.55, this.lavaY - 160);
    this.py = safeY;
    this.lavaY = Math.max(this.lavaY, this.py + 200);
    this.camY = Math.min(this.camY, this.py - this.viewH * 0.42);
    // Spawn a rescue platform directly beneath the revived player
    this.platforms.push({
      x: Math.max(12, Math.min(WORLD_W - 112, this.px - 50)),
      y: this.py + 28,
      w: 100,
      kind: "normal",
      theme: this.curIdx,
      dir: 0,
      speed: 0,
      crumbling: false,
      crumbleT: 0,
      dead: false,
      y0: this.py + 28,
      phase: 0,
      push: 0,
      baseX: this.px,
    });
    for (const h of this.hazards) {
      if (Math.hypot(h.x - this.px, h.y - this.py) < 120) h.dead = true;
    }
    this.vy = -JUMP_V * 0.9 * this.jumpMul();
    this.invulnT = Math.max(this.invulnT, 2.5);
    this.last = performance.now();
    this.burst(this.px, this.py - 26, 22, ["#7fd0ff", "#ffffff", "#ffd166"], 190);
    this.text(this.px, this.py - 84, "REVIVED!", "#7fd0ff");
    audio.sfx("powerup");
    return true;
  }

  setInput(dir: number) {
    this.dir = dir;
  }

  getRunStats(): RunStats {
    return {
      distance: this.dist,
      score: this.dist + this.bonus,
      bonus: this.bonus,
      coins: this.runCoins,
      platforms: this.platformsLanded,
      time: this.playTime,
      powerups: this.powerupsTaken,
      nearMisses: this.nearMisses,
      bosses: this.bossKills,
      candies: this.candiesEaten,
      worldSeg: this.maxSeg,
      wasBossFight: this.foughtBoss || this.dragonActive || this.boss.active || this.optsBoss,
    };
  }

  resize(cssW: number, cssH: number, dpr: number) {
    this.canvas.width = Math.round(cssW * dpr);
    this.canvas.height = Math.round(cssH * dpr);
    this.scale = cssW / WORLD_W;
    this.viewH = cssH / this.scale;
    this.ctx.setTransform(this.scale * dpr, 0, 0, this.scale * dpr, 0, 0);
    // keep camera consistent with start layout if the run hasn't begun
    if (this.maxHeight === this.startMax && this.state === "playing") this.camY = this.startY - this.viewH * 0.72;
  }

  reset(startMeters = 0) {
    this.platforms = [];
    this.coins = [];
    this.powerItems = [];
    this.hazards = [];
    this.particles = [];
    this.texts = [];
    this.startY = -startMeters * SCORE_DIV;
    this.startMax = startMeters * SCORE_DIV;
    this.px = WORLD_W / 2;
    this.py = this.startY;
    this.vx = 0;
    this.vy = -JUMP_V;
    this.facing = 1;
    this.stretch = 1;
    this.camY = this.startY - this.viewH * 0.72;
    this.lavaY = this.startY + 260;
    this.maxHeight = this.startMax;
    this.dist = Math.floor(startMeters);
    this.bonus = 0;
    this.runCoins = 0;
    this.state = "playing";
    this.dyingT = 0;
    this.lastWasFragile = false;
    this.lastWasIce = false;
    this.lastCenter = WORLD_W / 2;
    this.hazCooldown = 2;
    this.puCooldown = 3;
    const info = worldAt(this.dist);
    this.curSeg = this.maxSeg = info.seg;
    this.curIdx = this.prevIdx = info.index;
    this.curLoop = info.loop;
    this.transT = 1;
    audio.setWorld(info.index);
    this.vy = -JUMP_V * this.jumpMul();
    if (startMeters > 0) this.announce(info);
    if (this.optsBoss) {
      this.boss.active = true;
      this.boss.x = this.px;
      this.text(this.px, this.py - 90, "SURVIVE THE WARDEN!", "#ff6a4d");
    }
    // wide starting ground
    this.beams = [];
    this.candies = [];
    this.beamT = 5;
    this.moverT = 4;
    this.gripT = 0;
    this.boss = { active: false, t: 0, atk: 0, open: 0, hurt: 0, x: WORLD_W / 2, surge: 0, done: -1 };
    this.dragon = new DragonFight();
    this.dragonActive = info.index === DRAGON_WORLD;
    this.dragonTime = 0;
    this.dragonReported = false;
    this.dragonTargets = [];
    this.runeCounter = 0;
    this.expansionT = 2.5;
    this.trapCounter = 0;
    this.foughtBoss = this.dragonActive || this.optsBoss;
    this.resetAbilityState();
    this.platforms.push({ x: 40, y: this.startY, w: WORLD_W - 80, kind: "normal", theme: info.index, dir: 0, speed: 0, crumbling: false, crumbleT: 0, dead: false, y0: this.startY, phase: 0, push: 0, baseX: 40 });
    this.genY = this.startY;
    this.generate();
  }

  // --- debug / test hooks (only reachable via ?debug) ---------------------------------------------------
  debugState() {
    const kinds: Record<string, number> = {};
    for (const p of this.platforms) kinds[p.kind] = (kinds[p.kind] ?? 0) + 1;
    return {
      dist: this.dist, world: this.curIdx, loop: this.curLoop, state: this.state, coins: this.runCoins, bonus: this.bonus,
      shield: this.shieldT, magnet: this.magnetT, double: this.doubleT, slow: this.slowT, rocket: this.rocketT,
      hazards: this.hazards.filter((h) => !h.dead).length, kinds, py: this.py, lavaY: this.lavaY, storm: this.storm, wind: this.wind,
      platforms: this.platformsLanded, nearMisses: this.nearMisses,
      minX: PLAYER_VISUAL_W, maxX: WORLD_W - PLAYER_VISUAL_W,
      boss: this.boss.active, beams: this.beams.length, candies: this.candies.length, grip: +this.gripT.toFixed(2),
      dragon: this.dragonActive ? { hp: this.dragon.hp, phase: this.dragon.phase, dead: this.dragon.dead, time: this.dragonTime } : null,
      ability: this.abilityDef ? { id: this.abilityDef.id, cd: +this.abilityCd.toFixed(2), charges: this.abilityCharges } : null,
      expansion: this.curIdx >= 12 ? this.platforms.map((p) => ({ kind: p.kind, y0: p.y0, baseX: p.baseX, ...expansionPlatform(p, this.time), haz: p.haz?.type ?? null, rune: !!p.rune && !p.runeTaken })) : null,
    };
  }
  debugGive(type: PowerType) {
    this.applyPower(type, this.px, this.py - 40);
  }
  debugSpawn(kind: HazKind) {
    if (MOVER_KINDS.has(kind)) this.spawnMover(kind);
    else if (kind === "fireball") this.spawnEruption();
    else this.spawnFalling(kind);
  }
  setBot(b: boolean) {
    this.bot = b;
  }
  setGod(g: boolean) {
    this.god = g;
  }

  // --- difficulty (original formulas) -------------------------------------------------------------------
  private difficulty(score: number) {
    return Math.min(1, score / 2000);
  }

  /** Extra difficulty for the six newer worlds only, so the original six play exactly as before. */
  private ext() {
    return this.curIdx > 5 ? Math.min(0.55, (this.curIdx - 5) * 0.09) : 0;
  }

  /** Character ability radius: Mist Form shrinks the hurtbox instead of adding power. */
  private playerR() {
    return this.mistT > 0 ? PLAYER_R * 0.55 : PLAYER_R;
  }

  private resetAbilityState() {
    this.abilityCd = 0;
    this.abilityCharges = this.abilityDef?.charges ?? 0;
    this.speedT = this.lowgT = this.slowFallT = this.slowHazT = this.auraT = this.balanceT = this.mistT = 0;
    this.superBounce = 0;
  }

  /** Equips an ability for this run. Only validated, owned+equipped ids reach the engine. */
  setAbility(id: string | null) {
    this.abilityDef = id ? abilityById(id) ?? null : null;
    this.resetAbilityState();
  }

  /** True when the button may fire right now. */
  private abilityReady() {
    if (!this.abilityDef) return false;
    if (this.abilityDef.cooldown === 0) return this.abilityCharges > 0;
    return this.abilityCd <= 0;
  }

  /**
   * Activates the equipped character ability. Returns false when it is on cooldown,
   * out of charges or no ability is equipped — a locked ability can never fire here.
   */
  triggerAbility(): boolean {
    if (!this.abilityDef || this.state !== "playing") return false;
    if (!this.abilityReady()) {
      audio.sfx("error");
      return false;
    }
    const def = this.abilityDef;
    if (def.cooldown === 0) {
      this.abilityCharges = Math.max(0, this.abilityCharges - 1);
    } else {
      this.abilityCd = def.cooldown;
    }
    if (def.duration > 0) audio.sfx("powerup");
    audio.sfx("ability");
    this.burst(this.px, this.py - 26, 14, ["#ffd166", "#ffffff", "#7fd0ff"], 150);
    this.text(this.px, this.py - 84, def.name.toUpperCase() + "!", "#ffd166");
    this.applyAbility(def.id);
    return true;
  }

  private applyAbility(id: string) {
    const R = this.playerR;
    switch (id) {
      case "adventurers_grit": // extra mid-air jump impulse
        this.vy = -JUMP_V * 0.92 * this.jumpMul();
        this.stretch = 0.72;
        this.burst(this.px, this.py, 10, ["#e9d8ff", "#ffffff"], 110);
        break;
      case "shadow_dash": {
        this.px = Math.max(PLAYER_VISUAL_W, Math.min(WORLD_W - PLAYER_VISUAL_W, this.px + this.facing * 90));
        this.invulnT = Math.max(this.invulnT, 0.45);
        this.burst(this.px, this.py - 26, 16, ["#3a3d5c", "#c9d1dc"], 130);
        break;
      }
      case "piton_spike": {
        const y = this.py + 46;
        this.platforms.push({
          x: Math.max(4, Math.min(WORLD_W - 94, this.px - 45)), y, w: 90, kind: "temp", theme: this.curIdx,
          dir: 0, speed: 0, crumbling: false, crumbleT: 0, dead: false, y0: y, phase: 0, push: 0, baseX: this.px,
        });
        break;
      }
      case "overclock":
        this.speedT = 5;
        break;
      case "broadside":
      case "quick_draw":
      case "iai_slash":
      case "dragons_wrath":
        this.clearHazards(id);
        break;
      case "zero_g":
        this.lowgT = 4;
        break;
      case "time_warp":
        this.slowHazT = 4;
        break;
      case "molten_aura":
        this.auraT = 5;
        break;
      case "vine_swing": {
        // swing up onto the closest platform above the player
        let best: Platform | null = null;
        let bd = 170;
        for (const p of this.platforms) {
          if (p.dead) continue;
          const dy = this.py - p.y;
          if (dy <= 8) continue;
          if (this.px < p.x - 6 || this.px > p.x + p.w + 6) continue;
          if (dy < bd) {
            bd = dy;
            best = p;
          }
        }
        if (best) {
          this.py = best.y;
          this.vy = -JUMP_V * 0.85 * this.jumpMul();
          this.stretch = 0.74;
          this.burst(this.px, best.y, 12, ["#8cd35f", "#e8ffd0"], 120);
        } else {
          this.vy = -JUMP_V * 0.7; // nothing in reach: still a helpful hop
        }
        break;
      }
      case "mirage":
        this.invulnT = Math.max(this.invulnT, 2.5);
        break;
      case "treasure_rain":
        for (let i = 0; i < 6; i++) {
          this.coins.push({
            x: Math.max(24, Math.min(WORLD_W - 24, this.px + (Math.random() - 0.5) * 170)),
            y: this.py - 30 - Math.random() * 120,
            taken: false,
            phase: Math.random() * 6,
          });
        }
        break;
      case "perfect_balance":
        this.balanceT = 5;
        this.wind = 0;
        break;
      case "wing_beat":
        this.slowFallT = 3;
        break;
      case "recipe_day": {
        const pool: PowerType[] = ["shield", "magnet", "double", "slow", "rocket"];
        const type = pool[Math.floor(Math.random() * pool.length)];
        this.powerItems.push({ x: this.px, y: this.py - 120, type, taken: false, phase: Math.random() * 6 });
        break;
      }
      case "primal_roar":
        for (const h of this.hazards) {
          if (h.dead || h.kind === "dragonfire" || h.kind === "bossfire") continue;
          if (h.vy > 0 || h.vx !== 0) {
            h.vy = -Math.abs(h.vy || 220) - 120;
            h.dead = false;
          }
        }
        break;
      case "mist_form":
        this.mistT = 6;
        break;
      default:
        break;
    }
    void R;
  }

  /** Hazard-clearing abilities. Boss projectiles stay dangerous so fights are never trivialised. */
  private clearHazards(id: string) {
    const isBossShot = (k: HazKind) => k === "dragonfire" || k === "bossfire";
    let removed = 0;
    if (id === "broadside" || id === "dragons_wrath") {
      this.hazards = this.hazards.filter((h) => {
        if (isBossShot(h.kind)) return true;
        this.burst(h.x, h.y - 12, 6, ["#ffd166", "#ffffff"], 90);
        return false;
      });
      removed = 1;
    } else if (id === "quick_draw") {
      const sorted = this.hazards
        .filter((h) => !isBossShot(h.kind))
        .sort((a, b) => Math.hypot(a.x - this.px, a.y - this.py) - Math.hypot(b.x - this.px, b.y - this.py));
      for (const h of sorted.slice(0, 3)) {
        h.dead = true;
        this.burst(h.x, h.y - 12, 6, ["#ffd166", "#ffffff"], 90);
        removed++;
      }
    } else if (id === "iai_slash") {
      for (const h of this.hazards) {
        if (isBossShot(h.kind) || h.dead) continue;
        if (Math.abs(h.x - this.px) < 42 && h.y < this.py && this.py - h.y < 150) {
          h.dead = true;
          this.burst(h.x, h.y - 12, 6, ["#ffffff", "#c9d1dc"], 90);
          removed++;
        }
      }
    }
    if (id === "dragons_wrath") this.invulnT = Math.max(this.invulnT, 3);
    if (removed > 0) this.text(this.px, this.py - 66, "CLEARED!", "#ffd166");
  }

  private gMul() {
    let g = this.curIdx === 9 ? LOW_G : 1; // outer space: low gravity
    if (this.lowgT > 0) g *= 0.7; // Zero-G Suit
    if (this.slowFallT > 0) g *= 0.45; // Wing Beat
    return g;
  }
  private jumpMul() {
    return this.curIdx === 9 ? LOW_G_JUMP : 1;
  }
  private steerK() {
    if (this.balanceT > 0) return 24; // Perfect Balance: instant response
    if (this.slipT > 0) return SLIP_K;
    if (this.curIdx === 6) return 7; // water drag in the Underwater Kingdom
    return 10;
  }

  private lavaSpeed() {
    const d = this.difficulty(this.dist);
    const grace = Math.min(1, this.time / 2.5); // gentle start
    const endless = Math.min(14, this.curLoop * 5); // slightly faster in endless levels
    const newer = Math.max(0, this.curIdx - 5) * 5; // worlds 7-12 push a little harder
    const surge = this.boss.surge > 0 ? 30 : 0;
    return (24 + 78 * d + endless + newer + surge) * grace;
  }

  /** True while the player is inside the Warden fight at the top of the final world. */
  private inBossZone() {
    return this.curIdx === 11 && this.boss.done !== this.curSeg && this.dist - this.curSeg * WORLD_LEN >= WORLD_LEN - BOSS_TAIL;
  }

  // --- platform generation -----------------------------------------------------------------------------------
  private pickKind(widx: number, score: number, d: number, loop: number): PlatformKind {
    const r = Math.random();
    let kind: PlatformKind = "normal";
    if (widx === 0) {
      // original cave rules
      if (score > 120 && r < 0.1 + 0.3 * d) kind = "moving";
      else if (score > 250 && !this.lastWasFragile && r > 0.9 - 0.2 * d) kind = "crumble";
      else if (score > 100 && r >= 0.5 && r < 0.54) kind = "spring";
    } else {
      const k = 1 + 0.25 * loop;
      let acc = 0;
      const tbl = KIND_TABLE[widx] ?? [];
      for (const [kd, base, extra] of tbl) {
        acc += (base + extra * d) * k;
        if (r < acc) {
          kind = kd;
          break;
        }
      }
    }
    if ((isFragile(kind) || kind === "ghost" || kind === "clock") && this.lastWasFragile) kind = "normal";
    return kind;
  }

  private generate() {
    while (this.genY > this.camY - 320) {
      const score = -this.genY / SCORE_DIV;
      const d = this.difficulty(score);
      const gap = Math.min(138, 62 + 70 * d + Math.random() * 22);
      const y = this.genY - gap;
      const rawInfo = worldAt(-y / SCORE_DIV);
      // Stage 20 is the final arena: distance keeps accumulating honestly, but there is no stage 21.
      const info = this.curIdx === DRAGON_WORLD ? { ...rawInfo, seg: DRAGON_WORLD, index: DRAGON_WORLD, loop: 0 } : rawInfo;
      let w = (84 - 32 * d) * (0.92 + Math.random() * 0.22) * (1 - Math.min(0.1, info.loop * 0.03));

      const kind = this.pickKind(info.index, score, d, info.loop);
      if (kind === "ice") w *= 1.1;
      if (info.index > 5) w *= 1 - Math.min(0.12, (info.index - 5) * 0.02);
      this.lastWasFragile = isFragile(kind) || kind === "ghost" || kind === "clock";

      // hazard mounted on the platform (plants in the forest, cacti in the desert) — never next to another one
      let haz: PlatHaz | undefined;
      this.hazCooldown--;
      const worldM = (-y / SCORE_DIV) % 500;
      const mountable = info.index === 3 || info.index === 4 || info.index === 11 || info.index === 12 || info.index === 15;
      if (kind === "normal" && mountable && this.hazCooldown <= 0 && worldM > 40 && Math.random() < 0.26 + 0.2 * d + 0.04 * info.loop) {
        const type = info.index === 3 ? "plant" : info.index === 4 ? "cactus" : info.index === 12 ? "press" : info.index === 15 ? (this.trapCounter++ % 2 === 0 ? "pendulum" : "clockhand") : Math.random() < 0.55 ? "spike" : "blade";
        haz = { type, side: Math.random() < 0.5 ? -1 : 1, phase: Math.random() * 3, warned: false };
        w = Math.max(w, 80);
        this.hazCooldown = 3;
      }

      // reachability: bounded horizontal step (tighter after slippery ice)
      const maxDx = this.lastWasIce ? 70 : 128;
      const off = Math.max(-maxDx, Math.min(maxDx, (Math.random() - 0.5) * 340));
      let x = this.lastCenter + off - w / 2;
      x = Math.max(4, Math.min(WORLD_W - w - 4, x));
      this.lastWasIce = kind === "ice";

      const push = kind === "electric" ? (Math.random() < 0.5 ? -1 : 1) : 0;
      const p: Platform = {
        x, y, w, kind, theme: info.index,
        dir: Math.random() < 0.5 ? -1 : 1,
        speed: (kind === "wooden" || kind === "asteroid" ? 32 + Math.random() * 30 : 40 + Math.random() * 50) * (SPEED_MUL[info.index] ?? 1) * (kind === "electric" ? 1.5 : 1),
        crumbling: false, crumbleT: 0, dead: false, haz,
        y0: y,
        phase: Math.random() * GHOST_CYCLE,
        push,
        baseX: x,
        rune: info.index === DRAGON_WORLD && ++this.runeCounter % 3 === 0,
        runeTaken: false,
      };
      this.platforms.push(p);
      this.lastCenter = x + w / 2;
      this.genY = y;

      // power-up or coin above the platform
      this.puCooldown--;
      if (!haz && this.puCooldown <= 0 && score > 40 && Math.random() < 0.2) {
        this.powerItems.push({ x: x + w / 2, y: y - 50, type: this.pickPower(score), taken: false, phase: Math.random() * 6 });
        this.puCooldown = 7;
      } else if (info.index === 10 && Math.random() < 0.3) {
        // candy bonus: worth 3 coins
        this.candies.push({ x: x + w / 2, y: y - 44, taken: false, phase: Math.random() * 6 });
      } else if (Math.random() < 0.38) {
        this.coins.push({ x: x + w / 2, y: y - 42, taken: false, phase: Math.random() * 6 });
      }
    }
    // cull anything well below the screen
    const bottom = this.camY + this.viewH + 150;
    this.platforms = this.platforms.filter((p) => p.y < bottom && !p.dead);
    this.coins = this.coins.filter((c) => c.y < bottom && !c.taken);
    this.powerItems = this.powerItems.filter((c) => c.y < bottom && !c.taken);
    this.candies = this.candies.filter((c) => c.y < bottom && !c.taken);
    this.beams = this.beams.filter((bm) => bm.y < bottom + 40);
    if (this.curIdx === DRAGON_WORLD) this.dragonTargets = this.dragonTargets.filter((p) => !p.dead && p.y < bottom);
  }

  private pickPower(score: number): PowerType {
    const table: [PowerType, number][] = [["shield", 22], ["magnet", 20], ["double", 20], ["slow", 22], ["rocket", score > 120 ? 8 : 0]];
    const total = table.reduce((s, [, w]) => s + w, 0);
    let r = Math.random() * total;
    for (const [t, w] of table) {
      r -= w;
      if (r <= 0) return t;
    }
    return "shield";
  }

  /** Solid-boundary response: clamp the position and cancel any momentum pushing into the wall. */
  private hitWall(edge: number, side: number) {
    const impact = Math.abs(this.vx + this.wind);
    this.px = edge;
    if (this.vx * side > 0) this.vx = 0;
    if (impact > 110 && this.time - this.lastWallHit > 0.3) {
      this.lastWallHit = this.time;
      this.burst(edge + side * 5, this.py - 24, 5, ["rgba(255,255,255,0.9)", "#e9d8ff"], 55);
    }
  }

  private burst(x: number, y: number, n: number, colors: string[], power: number) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = (0.3 + Math.random()) * power;
      this.particles.push({
        x, y,
        vx: Math.cos(a) * s,
        vy: Math.sin(a) * s - power * 0.3,
        life: 0,
        max: 0.4 + Math.random() * 0.5,
        color: colors[Math.floor(Math.random() * colors.length)],
        size: 2 + Math.random() * 3,
      });
    }
  }

  private text(x: number, y: number, text: string, color: string) {
    this.texts.push({ x, y, text, color, life: 0 });
  }

  // --- worlds ----------------------------------------------------------------------------------------------------
  private announce(info: WorldInfo) {
    const w = WORLDS[info.index];
    this.cb.onWorld({
      seg: info.seg, index: info.index, loop: info.loop,
      name: worldTitle(info.index, info.loop), label: worldLabel(info.seg, info.loop),
      subtitle: w.subtitle, accent: w.accent,
    });
  }

  private enterWorld(info: WorldInfo) {
    this.prevIdx = this.curIdx;
    this.curIdx = info.index;
    this.curLoop = info.loop;
    this.curSeg = info.seg;
    this.maxSeg = Math.max(this.maxSeg, info.seg);
    if (info.index === DRAGON_WORLD) {
      this.dragon = new DragonFight();
      this.dragonActive = true;
      this.foughtBoss = true;
      this.dragonTime = 0;
      this.dragonTargets = [];
      this.hazards = [];
    }
    this.transT = 0;
    // grace period: no hazards right after entering a new world
    this.fallT = Math.max(this.fallT, 3.5);
    this.moverT = Math.max(this.moverT, 5);
    this.beamT = Math.max(this.beamT, 4);
    this.beams = [];
    this.eruptT = Math.max(this.eruptT, 6);
    this.windState = 0;
    this.windTimer = 7;
    this.stormOn = false;
    this.stormTimer = 9;
    audio.setWorld(info.index);
    audio.sfx("world");
    this.announce(info);
  }

  // --- hazards ---------------------------------------------------------------------------------------------------
  private spawnFalling(kind: HazKind) {
    const spec = FALL_SPEC[kind];
    let x = Math.max(26, Math.min(WORLD_W - 26, this.px + (Math.random() - 0.5) * 220));
    // never stack two falling hazards in the same column
    const crowded = this.hazards.some((o) => !o.dead && !MOVER_KINDS.has(o.kind) && Math.abs(o.x - x) < 55);
    if (crowded) x = Math.max(26, Math.min(WORLD_W - 26, WORLD_W - x));
    const d = this.difficulty(this.dist);
    const slow = kind === "jellyfish" || kind === "spore";
    this.hazards.push({
      kind,
      x,
      y: -1e9,
      vx: kind === "meteor" ? (Math.random() - 0.5) * 180 : kind === "candy" ? (Math.random() - 0.5) * 120 : 0,
      vy: slow ? 88 : kind === "meteor" ? 330 + 110 * d : 190 + 80 * d,
      g: slow ? 12 : kind === "meteor" ? 240 : 380,
      r: spec.r,
      c0: spec.c0,
      c1: spec.c1,
      warn: kind === "meteor" ? 0.95 : slow ? 1.25 : 1.0,
      dir: 1,
      ph: Math.random() * 6.28,
      dead: false,
      near: false,
      awarded: false,
    });
    audio.sfx("warn");
  }

  private spawnMover(kind: HazKind) {
    const dir = Math.random() < 0.5 ? 1 : -1;
    const d = this.difficulty(this.dist);
    const y = Math.max(this.camY + 150, Math.min(this.camY + this.viewH - 150, this.py - 70 - Math.random() * 80));
    const speed = kind === "drone" ? 225 + 45 * d : kind === "fish" ? 128 + 40 * d : kind === "ghost" ? 76 + 20 * d : kind === "skull" ? 138 + 40 * d : kind === "cannonball" ? 245 + 45 * d : kind === "train" ? 205 + 35 * d : kind === "soundwave" ? 175 + 30 * d : 165 + 60 * d;
    const spec = FALL_SPEC[kind];
    const edge = kind === "fish" || kind === "ghost" ? 46 : 34;
    this.hazards.push({
      kind,
      x: dir > 0 ? -edge : WORLD_W + edge,
      y,
      vx: dir * speed,
      vy: 0,
      g: 0,
      r: spec.r,
      c0: spec.c0,
      c1: spec.c1,
      warn: kind === "drone" || kind === "train" ? 1.45 : 1.15,
      dir,
      ph: Math.random() * 6.28,
      homing: kind === "ghost" || kind === "skull" ? 1 : 0,
      dead: false,
      near: false,
      awarded: false,
    });
    audio.sfx("warn");
  }

  private spawnRisingSpore() {
    const spec = FALL_SPEC.sporeseed;
    const x = Math.max(30, Math.min(WORLD_W - 30, this.px + (Math.random() - 0.5) * 210));
    this.hazards.push({
      kind: "sporeseed", x, y: this.camY + this.viewH + 45, vx: 0, vy: -(95 + Math.random() * 35), g: 0,
      r: spec.r, c0: spec.c0, c1: spec.c1, warn: 1.2, dir: 1, ph: Math.random() * 6.28, dead: false, near: false, awarded: false,
    });
    audio.sfx("mushroom");
  }

  private spawnEruption() {
    const x = Math.max(30, Math.min(WORLD_W - 30, this.px + (Math.random() - 0.5) * 180));
    this.hazards.push({
      kind: "fireball", x, y: this.lavaY, vx: (Math.random() - 0.5) * 40, vy: -(520 + Math.random() * 140), g: 520, r: 11, c0: 11, c1: 11,
      warn: 1.3, dir: 1, ph: Math.random() * 6.28, dead: false, near: false, awarded: false,
    });
    audio.sfx("warn");
  }

  private updateSpawns(dt: number) {
    if (this.state !== "playing" || this.rocketT > 0) return;
    const d = this.difficulty(this.dist);
    const loop = this.curLoop;
    const idx = this.curIdx;
    const ext = this.ext();
    // the Warden duel clears the sky so the fight stays readable
    const busy = this.boss.active || this.dragonActive;
    const fallKind = FALL_KIND[idx];
    if (idx === 13 && !busy) {
      this.expansionT -= dt;
      if (this.expansionT <= 0) {
        this.spawnRisingSpore();
        this.expansionT = Math.max(2.1, 4.0 - (idx - 11) * 0.2) + Math.random();
      }
    }
    this.fallT -= dt;
    if (this.fallT <= 0) {
      if (fallKind && !busy && (idx !== 0 || loop > 0)) this.spawnFalling(fallKind);
      this.fallT = Math.max(1.95, 4.6 - 1.9 * d - 0.4 * loop - ext * 1.5) + Math.random() * 1.3;
    }
    const mover = MOVER_KIND[idx];
    if (mover && !busy) {
      this.moverT -= dt;
      if (this.moverT <= 0) {
        this.spawnMover(mover);
        this.moverT = Math.max(3.4, 6.4 - 2 * d - 0.3 * loop - ext * 1.3) + Math.random() * 2;
      }
    }
    if (idx === 8) this.updateBeams(dt);
    if (idx === 2 || idx === 11) {
      this.eruptT -= dt;
      if (this.eruptT <= 0) {
        if (this.lavaY - this.camY < this.viewH - 20 && !busy) this.spawnEruption();
        this.eruptT = Math.max(4.2, 7 - 2 * d - 0.4 * loop - ext) + Math.random() * 2;
      }
    }
  }

  private hurt(h?: Hazard) {
    if (this.god || this.invulnT > 0 || this.rocketT > 0 || this.state !== "playing") return;
    if (this.shieldT > 0) {
      this.shieldT = 0;
      this.invulnT = 1.2;
      audio.sfx("shield");
      this.burst(this.px, this.py - 26, 16, ["#3fb7ff", "#bfe9ff", "#ffffff"], 160);
      this.text(this.px, this.py - 70, "SHIELD!", "#7fd0ff");
      if (h) h.dead = true;
      return;
    }
    this.state = "dying";
    this.deathBy = "hazard";
    this.dyingT = 0;
    this.vy = -320;
    audio.sfx("die");
    this.burst(this.px, this.py - 26, 20, ["#ff5a5a", "#ffd23f", "#ffffff"], 190);
    if (h) h.dead = true;
  }

  private updateHazards(dt: number) {
    const cx = this.px;
    const cy = this.py - 26;
    const camBottom = this.camY + this.viewH;
    for (const h of this.hazards) {
      if (h.dead) continue;
      if (h.warn > 0) {
        h.warn -= dt;
        if (h.kind === "fireball") {
          h.y = this.lavaY;
          h.x = Math.max(8, Math.min(WORLD_W - 8, h.x));
        }
        if (h.warn <= 0 && h.kind === "sporeseed") h.y = this.camY + this.viewH + 35;
        else if (h.warn <= 0 && h.kind !== "bird" && h.kind !== "fireball") h.y = this.camY - 40;
        continue;
      }
      const hdt = dt * (this.slowHazT > 0 ? 0.5 : 1);
      h.x += h.vx * hdt;
      h.y += h.vy * hdt;
      h.vy += h.g * hdt;
      if (h.kind === "jellyfish" || h.kind === "spore") h.x += Math.sin(this.time * 2.2 + h.ph) * 40 * dt;
      if (h.kind === "fish") h.y += Math.sin(this.time * 3 + h.ph) * 30 * dt;
      if (h.kind === "sporeseed") h.x += Math.sin(this.time * 3 + h.ph) * 70 * dt;
      if (h.kind === "shockwave") h.y = this.lavaY;
      if (h.kind === "toyball" && h.vy > 0 && h.y > this.lavaY - 5) {
        h.y = this.lavaY - 5;
        h.vy = -370;
        audio.sfx("toy");
      }
      if (h.kind === "sporeseed" && h.y < this.camY - 70) h.dead = true;
      if (h.homing && this.state === "playing") {
        const want = Math.max(-64, Math.min(64, (this.py - 26 - h.y) * 1.1));
        h.vy += (want - h.vy) * Math.min(1, dt * 2.4);
      }
      if (MOVER_KINDS.has(h.kind)) {
        if (h.x < -70 || h.x > WORLD_W + 70 || h.y > camBottom + 60 || h.y < this.camY - 220) h.dead = true;
      } else if (h.kind === "candy" && h.y > this.lavaY) {
        h.dead = true; // the candy pops in the lava
      } else if (h.kind === "fireball") {
        if (h.vy > 0 && h.y > this.lavaY + 20) h.dead = true;
      } else if (h.y > camBottom + 80) {
        h.dead = true;
      }
      if (h.dead || this.state !== "playing") continue;
      // collision + near-miss
      const dd = segDist(cx, cy, h.x, h.y - h.c1, h.y - h.c0);
      const hit = h.r + this.playerR();
      if (dd < hit) {
        this.hurt(h);
      } else if (!h.awarded && this.rocketT <= 0) {
        if (dd < hit + 20) h.near = true;
        else if (h.near && dd > hit + 24) {
          h.awarded = true;
          this.bonus += 10;
          this.nearMisses++;
          audio.sfx("near");
          this.text(this.px, this.py - 72, "NEAR MISS! +10", "#ffe066");
          this.burst(this.px, this.py - 26, 12, ["#ffe066", "#ffffff", "#7fe3ff"], 130);
        }
      }
    }
    this.hazards = this.hazards.filter((h) => !h.dead);

    // platform-mounted hazards (cactus / snapping plant)
    if (this.state !== "playing") return;
    for (const p of this.platforms) {
      const hz = p.haz;
      if (!hz || p.dead) continue;
      if (Math.abs(p.y - cy) > 90) continue;
      const hx = p.x + (hz.side < 0 ? 12 : p.w - 12);
      if (hz.type === "press" || hz.type === "pendulum" || hz.type === "clockhand") {
        if (expansionMountedHit(hz.type, hx, p, this.time, cx, cy, this.playerR())) this.hurt();
        continue;
      }
      if (hz.type === "blade") {
        const a2 = Math.sin(this.time * 1.8 + hz.phase) * 1.15;
        const bxx = hx + Math.sin(a2) * 54;
        const byy = p.y - 60 + Math.cos(a2) * 54;
        if (this.state === "playing" && Math.hypot(cx - bxx, cy - byy) < 22) this.hurt();
        continue;
      }
      let active = true;
      let height = 25;
      let halfW = 8;
      if (hz.type === "spike") {
        height = 16;
        halfW = 17;
      }
      if (hz.type === "plant") {
        const st = plantStage(this.time, hz.phase);
        if (st.stage === 1 && !hz.warned && Math.abs(hx - cx) < 130) {
          hz.warned = true;
          audio.sfx("warn");
        }
        if (st.stage === 0) hz.warned = false;
        active = st.stage === 2;
        height = 36;
      }
      if (!active) continue;
      // circle vs rect
      const nx = Math.max(hx - halfW, Math.min(hx + halfW, cx));
      const ny = Math.max(p.y - height, Math.min(p.y, cy));
      if (Math.hypot(cx - nx, cy - ny) < this.playerR()) this.hurt();
    }
  }

  // --- ambient / weather ---------------------------------------------------------------------------------------------
  // --- phantom (Enchanted Forest) platforms -------------------------------------------------------------------
  private ghostSolid(p: Platform) {
    return (this.time + p.phase) % GHOST_CYCLE < GHOST_CYCLE - GHOST_GONE;
  }

  private ghostAlpha(p: Platform) {
    const c = (this.time + p.phase) % GHOST_CYCLE;
    const out = GHOST_CYCLE - GHOST_GONE;
    if (c >= out) return 0.14;
    if (c > out - GHOST_FADE) return 1 - ((c - (out - GHOST_FADE)) / GHOST_FADE) * 0.86;
    if (c < GHOST_FADE) return 0.14 + (c / GHOST_FADE) * 0.86;
    return 1;
  }

  // --- Cyber City sweeping lasers ------------------------------------------------------------------------------
  private updateBeams(dt: number) {
    if (this.curIdx !== 8) {
      if (this.beams.length) this.beams = [];
      return;
    }
    this.beamT -= dt;
    if (this.beamT <= 0 && this.state === "playing" && this.beams.length < 2 && !this.boss.active) {
      // the beam always leaves a clear gap on one side so it can be dodged
      const gap = 158;
      const gx = 30 + Math.random() * (WORLD_W - 60 - gap);
      const left = Math.random() < 0.5;
      this.beams.push({ y: this.py - 140 - Math.random() * 80, x0: left ? 2 : gx + gap, x1: left ? gx : WORLD_W - 2, state: 0, t: LASER_WARN });
      audio.sfx("laser");
      this.beamT = Math.max(2.5, 4.6 - 2 * this.difficulty(this.dist) - this.ext() * 1.6) + Math.random();
    }
    for (const bm of this.beams) {
      bm.t -= dt;
      if (bm.t <= 0) {
        if (bm.state === 0) {
          bm.state = 1;
          bm.t = LASER_FIRE;
        } else bm.t = -1;
      }
      if (bm.state === 1 && this.state === "playing" && this.invulnT <= 0 && this.rocketT <= 0) {
        const cy = this.py - 26;
        if (Math.abs(cy - bm.y) < 9 && this.px > bm.x0 - 6 && this.px < bm.x1 + 6) this.hurt();
      }
    }
    this.beams = this.beams.filter((bm) => bm.t > 0);
  }

  // --- the Warden: final-world boss duel ------------------------------------------------------------------------
  private updateBoss(dt: number) {
    const zone = this.inBossZone();
    if (zone && !this.boss.active && this.state === "playing") {
      this.boss.active = true;
      this.foughtBoss = true;
      this.boss.t = 0;
      this.boss.atk = 1.3;
      this.boss.open = 0;
      this.boss.x = this.px;
      audio.sfx("boss");
      this.text(this.px, this.py - 96, "THE WARDEN!", "#ff6a4d");
    }
    if (!zone && this.boss.active) {
      // out-climbed: the Warden burns out and pays out
      this.boss.active = false;
      this.boss.done = this.curSeg;
      this.bossKills++;
      this.bonus += 200;
      this.runCoins += 50;
      this.cb.onCoin(50);
      audio.sfx("win");
      this.burst(this.boss.x, this.lavaY - 34, 26, ["#ff6a4d", "#ffd23f", "#ffffff"], 230);
      this.text(this.px, this.py - 96, "WARDEN DEFEATED! +200", "#ffd62e");
    }
    if (!this.boss.active) return;
    this.boss.t += dt;
    this.boss.surge = Math.max(0, this.boss.surge - dt);
    this.boss.hurt = Math.max(0, this.boss.hurt - dt * 2);
    this.boss.x += Math.max(-58, Math.min(58, (this.px - this.boss.x) * 1.5)) * dt;
    this.boss.x = Math.max(56, Math.min(WORLD_W - 56, this.boss.x));
    if (this.state !== "playing") return;
    this.boss.atk -= dt;
    // the jaw glows for ~0.5s before every breath — that is the warning
    this.boss.open = this.boss.atk < 0.55 ? Math.min(1, (0.55 - this.boss.atk) / 0.5) : Math.max(0, this.boss.open - dt * 3);
    if (this.boss.atk <= 0) {
      this.bossFire(Math.floor(this.boss.t / BOSS_ATK) % 3);
      this.boss.atk = Math.max(1.05, BOSS_ATK - this.ext() * 1.1);
    }
    if (Math.hypot(this.px - this.boss.x, this.py - 26 - (this.lavaY - 46)) < 46) this.hurt();
  }

  private bossFire(patt: number) {
    const bx = this.boss.x;
    const by = this.lavaY - 62;
    const ang0 = Math.atan2(this.py - 26 - by, this.px - bx);
    const sp = 235 + 45 * this.ext();
    if (patt === 0) {
      for (const o of [-0.34, 0, 0.34]) this.shootBoss(bx, by, ang0 + o, sp);
    } else if (patt === 1) {
      for (const o of [-0.62, -0.31, 0, 0.31, 0.62]) this.shootBoss(bx, by, ang0 + o, sp * 0.92);
    } else {
      for (const s of [-1, 1]) this.hazards.push({ kind: "skull", x: bx + s * 40, y: by, vx: s * 130, vy: -60, g: 0, r: 11, c0: 12, c1: 14, warn: 0, dir: s, ph: Math.random() * 6, homing: 1, dead: false, near: false, awarded: false });
      this.boss.surge = 1.5; // lava surge during the summon
      audio.sfx("crumble");
    }
    audio.sfx("laser");
  }

  private shootBoss(x: number, y: number, ang: number, sp: number) {
    this.hazards.push({
      kind: "bossfire", x, y, vx: Math.cos(ang) * sp, vy: Math.sin(ang) * sp, g: 80,
      r: 10, c0: 10, c1: 10, warn: 0, dir: Math.cos(ang) > 0 ? 1 : -1, ph: Math.random() * 6, dead: false, near: false, awarded: false,
    });
  }

  // --- Stage 20: damageable three-phase Dragon ------------------------------------------------------
  private damageDragon(amount: number) {
    if (!this.dragonActive || this.dragon.dead) return;
    const killed = this.dragon.damage(amount);
    this.bonus += 50;
    audio.sfx("shield");
    if (killed) {
      this.state = "victory";
      this.hazards = [];
      this.dragonTargets = [];
      audio.sfx("dragonwin");
      this.burst(this.dragon.x, this.dragon.y, 55, ["#fff3b0", "#ffd166", "#ff7043", "#ffffff"], 300);
      this.text(this.px, this.py - 100, "DRAGON DEFEATED!", "#ffd166");
      this.emitHud();
    }
  }

  private updateDragon(dt: number, prevFeet: number) {
    if (!this.dragonActive) return;
    this.dragonTime += dt;
    const attack = this.dragon.update(dt, { px: this.px, py: this.py, camY: this.camY });

    if (this.state === "victory") {
      if (this.dragon.deadT > 1.8 && !this.dragonReported) {
        this.dragonReported = true;
        this.state = "over";
        this.cb.onVictory({ ...this.getRunStats(), fightTime: this.dragonTime });
      }
      return;
    }
    if (this.state !== "playing") return;

    // Select the platforms during the visible warning, then destroy them on the attack.
    if (this.dragon.warning && this.dragon.attack === "platform" && this.dragonTargets.length === 0) {
      this.dragonTargets = this.platforms
        .filter((p) => !p.dead && !p.crumbling && Math.abs(p.y - this.py) < 260)
        .slice(0, this.dragon.phase >= 3 ? 3 : this.dragon.phase);
    }
    if (attack) this.fireDragonAttack(attack);

    const headY = this.dragon.y - 45;
    if (this.vy > 0 && prevFeet <= headY + 8 && this.py >= headY && Math.abs(this.px - this.dragon.x) < 50) {
      this.py = headY;
      this.vy = -JUMP_V * 1.18;
      this.invulnT = 0.75;
      this.stretch = 0.68;
      this.damageDragon(12);
      this.text(this.px, this.py - 65, "HEAD STOMP! +50", "#fff3b0");
      return;
    }
    if (!this.dragon.dead && Math.hypot(this.px - this.dragon.x, this.py - 26 - (this.dragon.y - 8)) < 32) this.hurt();
  }

  private fireDragonAttack(attack: DragonAttack) {
    const d = this.dragon;
    audio.sfx(attack.kind === "platform" ? "mechanical" : "roar");
    if (attack.kind === "platform") {
      for (const p of this.dragonTargets) {
        p.crumbling = true;
        p.crumbleT = 0;
      }
      this.dragonTargets = [];
      return;
    }
    if (attack.kind === "shockwave") {
      for (const side of [-1, 1]) {
        this.hazards.push({ kind: "shockwave", x: d.x, y: this.lavaY, vx: side * attack.speed * 0.8, vy: 0, g: 0, r: 14, c0: 0, c1: 24, warn: 0, dir: side, ph: Math.random() * 6, dead: false, near: false, awarded: false });
      }
      return;
    }
    const originY = d.y + 7;
    const base = Math.atan2(this.py - 26 - originY, this.px - d.x);
    for (let i = 0; i < attack.count; i++) {
      const angle = base + (i - (attack.count - 1) / 2) * attack.spread;
      const fire = attack.kind === "breath";
      this.hazards.push({
        kind: fire ? "dragonfire" : "bossfire", x: d.x, y: originY,
        vx: Math.cos(angle) * attack.speed, vy: Math.sin(angle) * attack.speed, g: fire ? 0 : 90,
        r: fire ? 11 : 10, c0: 10, c1: 10, warn: 0, dir: Math.cos(angle) > 0 ? 1 : -1,
        ph: Math.random() * 6, dead: false, near: false, awarded: false,
      });
    }
  }

  private updateWeather(dt: number) {
    const wi = this.curIdx;
    if (wi === 1 || wi === 4 || wi === 6) {
      this.stormTimer -= dt;
      if (this.stormTimer <= 0) {
        this.stormOn = !this.stormOn;
        this.stormTimer = this.stormOn ? 6 + Math.random() * 3 : 13 + Math.random() * 10;
      }
    } else this.stormOn = false;
    this.storm += ((this.stormOn ? 1 : 0) - this.storm) * Math.min(1, dt * 1.2);

    if ((wi === 5 || wi === 6) && this.state === "playing") {
      this.windTimer -= dt;
      if (this.windTimer <= 0) {
        if (this.windState === 0) {
          this.windState = 1;
          this.windTimer = 1.3;
          this.windDir = Math.random() < 0.5 ? -1 : 1;
          audio.sfx("warn");
        } else if (this.windState === 1) {
          this.windState = 2;
          this.windTimer = 3.2;
        } else {
          this.windState = 0;
          this.windTimer = Math.max(wi === 6 ? 4 : 5, 9 - 3 * this.difficulty(this.dist)) + Math.random() * 3;
        }
      }
      const base = wi === 6 ? 44 : 52; // under-water currents shove less hard but last longer
      this.windTarget = this.windState === 2 ? this.windDir * (base + 14 * this.difficulty(this.dist)) : 0;
    } else {
      this.windState = 0;
      this.windTarget = 0;
    }
    this.wind += (this.windTarget - this.wind) * Math.min(1, dt * 3);
  }

  private updateAmbient(dt: number) {
    const idx = this.curIdx;
    if (idx >= 12) {
      const count = Math.min(AMB_MAX, WORLDS[idx].ambient);
      for (let i = 0; i < count; i++) updateExpansionAmbient(this.amb[i], idx, dt, this.time, WORLD_W, this.viewH);
      return;
    }
    const count = Math.min(AMB_MAX, WORLDS[idx].ambient + Math.round(this.storm * 50));
    const H = this.viewH;
    const t = this.time;
    for (let i = 0; i < count; i++) {
      const a = this.amb[i];
      let vx = 0;
      let vy = 0;
      switch (idx) {
        case 0: vx = Math.sin(t * 0.6 + a.ph) * 6; vy = -4 - a.s * 5; break;
        case 1: vx = Math.sin(t * 1.3 + a.ph) * 16 + this.storm * 120 + this.wind * 0.5; vy = 34 + a.s * 30 + this.storm * 30; break;
        case 2: vx = Math.sin(t * 1.7 + a.ph) * 14; vy = -(26 + a.s * 36); break;
        case 3: vx = Math.sin(t * 1.1 + a.ph) * 28 + 10; vy = 22 + a.s * 16; break;
        case 4: vx = 70 + a.s * 40 + this.storm * 280; vy = Math.sin(t + a.ph) * 6 + 8 + this.storm * 10; break;
        case 5: vx = -(50 + a.s * 50) - this.wind * 2.5; vy = 10; break;
        case 6: vx = Math.sin(t * 1.4 + a.ph) * 14 + this.wind * 0.7; vy = -(20 + a.s * 22); break;
        case 7: vx = Math.sin(t * 0.8 + a.ph) * 22; vy = -(8 + a.s * 12) + Math.sin(t * 1.6 + a.ph) * 6; break;
        case 8: vx = (a.s > 0.5 ? 1 : -1) * (10 + a.s * 16); vy = 120 + a.s * 140; break;
        case 9: vx = -(4 + a.s * 10) - this.wind * 0.2; vy = 6 + a.s * 8; break;
        case 10: vx = Math.sin(t * 1.2 + a.ph) * 16; vy = 40 + a.s * 34; break;
        default: vx = Math.sin(t * 0.9 + a.ph) * 10 - this.wind * 0.2; vy = 16 + a.s * 18; break;
      }
      a.x += vx * dt;
      a.y += vy * dt;
      a.rot += dt * (1 + a.s * 2);
      if (a.x < -14) a.x = WORLD_W + 14;
      else if (a.x > WORLD_W + 14) a.x = -14;
      if (a.y > H + 14) a.y = -14;
      else if (a.y < -14) a.y = H + 14;
      if (idx === 9) a.rot += dt * 0.2;
    }
  }

  // --- power-ups -----------------------------------------------------------------------------------------------------------
  private applyPower(type: PowerType, x: number, y: number) {
    this.powerupsTaken++;
    audio.sfx("powerup");
    const col = POWER_COLOR[type];
    this.burst(x, y, 16, [col, "#ffffff", col], 150);
    this.text(x, y - 18, POWER_NAME[type], col);
    switch (type) {
      case "shield": this.shieldT = POWER_DURATION.shield; break;
      case "magnet": this.magnetT = POWER_DURATION.magnet; break;
      case "double": this.doubleT = POWER_DURATION.double; break;
      case "slow": this.slowT = POWER_DURATION.slow; break;
      case "rocket":
        this.rocketT = ROCKET_TIME;
        this.invulnT = Math.max(this.invulnT, ROCKET_TIME + 1.2); // brief grace after the boost ends
        break;
    }
  }

  private botDir(): number {
    let best: Platform | null = null;
    let bc = 1e9;
    for (const p of this.platforms) {
      if (p.dead) continue;
      const dy = p.y - this.py;
      const cxp = p.x + p.w / 2;
      const dx = Math.abs(cxp - this.px);
      if (this.vy < 0 ? dy < -25 && dy > -175 && dx < 150 : dy > -5 && dy < 120) {
        const c = dx + dy * (this.vy < 0 ? 0.5 : 0.3);
        if (c < bc) {
          bc = c;
          best = p;
        }
      }
    }
    if (!best) return 0;
    const diff = best.x + best.w / 2 - this.px;
    return Math.abs(diff) < 6 ? 0 : diff > 0 ? 1 : -1;
  }

  // --- simulation -----------------------------------------------------------------------------------------------------------------
  private update(dt: number) {
    // particles + floating texts
    for (const p of this.particles) {
      p.life += dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vy += 500 * dt;
    }
    this.particles = this.particles.filter((p) => p.life < p.max);
    for (const t of this.texts) {
      t.life += dt;
      t.y -= 26 * dt;
    }
    this.texts = this.texts.filter((t) => t.life < 1.2);

    if (this.transT < 1) this.transT = Math.min(1, this.transT + dt / 2.2);
    if (this.state === "playing") this.playTime += dt;
    this.magnetT = Math.max(0, this.magnetT - dt);
    this.doubleT = Math.max(0, this.doubleT - dt);
    this.slowT = Math.max(0, this.slowT - dt);
    this.shieldT = Math.max(0, this.shieldT - dt);
    this.invulnT = Math.max(0, this.invulnT - dt);
    this.updateWeather(dt);
    this.updateAmbient(dt);
    this.updateBoss(dt);
    this.gripT = Math.max(0, this.gripT - dt);
    if (this.abilityDef) {
      this.speedT = Math.max(0, this.speedT - dt);
      this.lowgT = Math.max(0, this.lowgT - dt);
      this.slowFallT = Math.max(0, this.slowFallT - dt);
      this.slowHazT = Math.max(0, this.slowHazT - dt);
      this.auraT = Math.max(0, this.auraT - dt);
      this.balanceT = Math.max(0, this.balanceT - dt);
      this.mistT = Math.max(0, this.mistT - dt);
      if (this.abilityCd > 0) {
        this.abilityCd = Math.max(0, this.abilityCd - dt);
        if (this.abilityCd === 0) audio.sfx("click");
      }
      if (this.auraT > 0) {
        // Molten Aura burns nearby hazards
        for (const h of this.hazards) {
          if (h.dead || h.kind === "dragonfire" || h.kind === "bossfire") continue;
          if (Math.hypot(h.x - this.px, h.y - 12 - (this.py - 26)) < 58) {
            h.dead = true;
            this.burst(h.x, h.y - 12, 7, ["#ff7a18", "#ffd166"], 110);
          }
        }
      }
    }

    // lava always rises (slower while SLOW LAVA is active)
    this.lavaY -= this.lavaSpeed() * (this.slowT > 0 ? 0.4 : 1) * dt;
    const camBottom = this.camY + this.viewH;
    this.lavaY = Math.min(this.lavaY, camBottom + 220);

    for (const p of this.platforms) {
      if (EXPANSION_KINDS.has(p.kind)) {
        const ep = expansionPlatform(p, this.time);
        p.x = ep.x;
        p.y = ep.y;
      }
      if (p.kind === "bubble") p.y = p.y0 + Math.sin(this.time * 1.7 + p.phase) * 7;
      if ((p.kind === "moving" || p.kind === "wooden" || p.kind === "asteroid") && !p.dead) {
        p.x += p.dir * p.speed * dt;
        if (p.x < 2) {
          p.x = 2;
          p.dir = 1;
        } else if (p.x + p.w > WORLD_W - 2) {
          p.x = WORLD_W - 2 - p.w;
          p.dir = -1;
        }
      }
      if (p.crumbling) {
        p.crumbleT += dt;
        if (p.kind === "sand" && Math.random() < 0.5) {
          this.particles.push({ x: p.x + Math.random() * p.w, y: p.y + 10, vx: (Math.random() - 0.5) * 20, vy: 10, life: 0, max: 0.5, color: "#f0c878", size: 2.5 });
        }
        if (p.crumbleT >= (FRAGILE_DUR[p.kind] ?? 0.5)) p.dead = true;
      }
    }

    if (this.state === "dying") {
      this.dyingT += dt;
      if (this.deathBy === "hazard") {
        this.vy += GRAVITY * this.gMul() * dt;
        this.py += this.vy * dt;
      }
      this.updateHazards(dt);
      if (this.dyingT > 0.9) {
        this.state = "over";
        this.cb.onGameOver(this.getRunStats());
      }
      return;
    }

    if (this.state === "victory") {
      this.updateDragon(dt, this.py);
      return;
    }

    if (this.bot) this.dir = this.botDir();

    // horizontal movement (ice makes steering sluggish for a short time; wind pushes in the sky world)
    const target = this.dir * MOVE_SPEED * (this.gripT > 0 ? STICK_MUL : 1) * (this.speedT > 0 ? 1.3 : 1);
    const k = this.steerK();
    this.slipT = Math.max(0, this.slipT - dt);
    this.vx += (target - this.vx) * Math.min(1, dt * k);
    this.px += (this.vx + (this.balanceT > 0 ? 0 : this.wind)) * dt;
    // SOLID SIDE BOUNDARIES (invisible walls) — clamped in world space, so the constraint is
    // pixel-exact on every screen size. Replaces the old left/right wrap-around.
    if (this.px < PLAYER_VISUAL_W) this.hitWall(PLAYER_VISUAL_W, -1);
    else if (this.px > WORLD_W - PLAYER_VISUAL_W) this.hitWall(WORLD_W - PLAYER_VISUAL_W, 1);
    if (this.vx > 15) this.facing = 1;
    else if (this.vx < -15) this.facing = -1;

    // vertical movement + platform collision
    const prevFeet = this.py;
    if (this.rocketT > 0) {
      this.rocketT -= dt;
      this.vy = -ROCKET_V;
      this.py += this.vy * dt;
      this.stretch += (1.15 - this.stretch) * Math.min(1, dt * 8);
      this.particles.push({ x: this.px + (Math.random() - 0.5) * 8, y: this.py + 2, vx: (Math.random() - 0.5) * 60, vy: 120 + Math.random() * 120, life: 0, max: 0.35, color: Math.random() < 0.5 ? "#ffb347" : "#ffe066", size: 3 + Math.random() * 3 });
      if (this.rocketT <= 0) {
        this.vy = -JUMP_V * 0.6 * this.jumpMul();
        this.fallT = Math.max(this.fallT, 2.5);
      }
    } else {
      this.vy += GRAVITY * this.gMul() * dt;
      this.py += this.vy * dt;
      this.stretch += (1 - this.stretch) * Math.min(1, dt * 9);

      if (this.vy > 0) {
        for (const p of this.platforms) {
          if (p.dead) continue;
          if (p.kind === "ghost" && !this.ghostSolid(p)) continue; // phased out — nothing to land on
          if (EXPANSION_KINDS.has(p.kind) && !expansionPlatform(p, this.time).solid) continue;
          if (prevFeet <= p.y + 1 && this.py >= p.y && this.px > p.x - 8 && this.px < p.x + p.w + 8) {
            this.py = p.y;
            const abilityBounce = this.superBounce > 0 ? 1.5 : 1;
            if (abilityBounce > 1) {
              this.superBounce--;
              this.burst(this.px, p.y, 10, ["#ffffff", "#9fe6ff"], 120);
            }
            const bounce = (p.kind === "spring" ? SPRING_MULT : p.kind === "jelly" ? JELLY_MULT : p.kind === "bubble" ? BUBBLE_MULT : EXPANSION_KINDS.has(p.kind) ? expansionPlatform(p, this.time).bounce : 1) * abilityBounce;
            this.vy = -JUMP_V * bounce * this.jumpMul();
            this.stretch = bounce >= JELLY_MULT ? 0.62 : p.kind === "spring" ? 0.7 : 0.78;
            this.platformsLanded++;
            audio.sfx(bounce > 1.15 ? "spring" : "jump");
            audio.sfx("land");
            if (p.kind === "piston") audio.sfx("mechanical");
            else if (p.kind === "mushroom") audio.sfx("mushroom");
            else if (p.kind === "ship") audio.sfx("cannon");
            else if (p.kind === "clock") audio.sfx("clock");
            else if (p.kind === "toyblock") audio.sfx("toy");
            else if (p.kind === "note") audio.sfx("note");
            else if (p.kind === "book") audio.sfx("page");
            this.burst(this.px, p.y, 6, p.kind === "ice" || p.kind === "bubble" ? ["#ffffff", "#9fe6ff"] : p.kind === "jelly" ? ["#ffd6ef", "#ff8ad0"] : ["#e9d8ff", "#b9a0ee"], 70);
            if (p.kind === "ice") this.slipT = SLIP_TIME;
            if (p.kind === "sticky") this.gripT = STICK_TIME;
            if (p.kind === "electric" && p.push) {
              this.vx += p.push * CONVEYOR_PUSH;
              audio.sfx("laser");
            }
            if (isFragile(p.kind) && !p.crumbling) {
              p.crumbling = true;
              if (p.kind !== "temp") audio.sfx("crumble");
            }
            break;
          }
        }
      }
      if (this.vy < -300) this.stretch += (1.12 - this.stretch) * Math.min(1, dt * 6);
    }

    // coins (magnet pulls nearby coins in; double coins doubles the value)
    for (const c of this.coins) {
      if (c.taken) continue;
      let dx = c.x - this.px;
      let dy = c.y - (this.py - 22);
      if (this.magnetT > 0) {
        const d = Math.hypot(dx, dy);
        if (d < 150 && d > 1) {
          const sp = 420 * dt;
          c.x -= (dx / d) * Math.min(sp, d);
          c.y -= (dy / d) * Math.min(sp, d);
          dx = c.x - this.px;
          dy = c.y - (this.py - 22);
        }
      }
      if (dx * dx + dy * dy < 30 * 30) {
        c.taken = true;
        const amount = this.doubleT > 0 ? 2 : 1;
        this.runCoins += amount;
        audio.sfx("coin");
        this.burst(c.x, c.y, 8, ["#ffe066", "#fff6b0", "#f59e0b"], 90);
        if (amount > 1) this.text(c.x, c.y - 10, "+2", "#ffe066");
        this.cb.onCoin(amount);
        this.emitHud();
      }
    }

    // power-ups
    for (const it of this.powerItems) {
      if (it.taken) continue;
      const dx = it.x - this.px;
      const dy = it.y - (this.py - 24);
      if (dx * dx + dy * dy < 32 * 32) {
        it.taken = true;
        this.applyPower(it.type, it.x, it.y);
      }
    }

    // candy bonuses (Candy Kingdom) — worth 3 coins, doubled by 2x COINS
    for (const cd of this.candies) {
      if (cd.taken) continue;
      let dx = cd.x - this.px;
      let dy = cd.y - (this.py - 22);
      if (this.magnetT > 0) {
        const d = Math.hypot(dx, dy);
        if (d < 150 && d > 1) {
          cd.x -= (dx / d) * Math.min(420 * dt, d);
          cd.y -= (dy / d) * Math.min(420 * dt, d);
          dx = cd.x - this.px;
          dy = cd.y - (this.py - 22);
        }
      }
      if (dx * dx + dy * dy < 30 * 30) {
        cd.taken = true;
        this.candiesEaten++;
        const amount = this.doubleT > 0 ? 6 : 3;
        this.runCoins += amount;
        audio.sfx("candy");
        this.burst(cd.x, cd.y, 10, ["#ff6ab8", "#fff0f8", "#ffe066"], 100);
        this.text(cd.x, cd.y - 12, `+${amount}`, "#ffb0dd");
        this.cb.onCoin(amount);
        this.emitHud();
      }
    }

    // Stage-20 runes and boss contact/attacks.
    this.updateDragon(dt, prevFeet);
    if ((this.state as string) === "victory") return;
    if (this.dragonActive && !this.dragon.dead) {
      for (const p of this.platforms) {
        if (!p.rune || p.runeTaken || p.dead) continue;
        const rx = p.x + p.w / 2;
        const ry = p.y - 38;
        if (Math.hypot(rx - this.px, ry - (this.py - 24)) < 31) {
          p.runeTaken = true;
          this.burst(rx, ry, 18, ["#fff3b0", "#ffb347", "#ff7043"], 180);
          this.text(rx, ry - 18, "RUNE HIT!", "#ffd166");
          this.damageDragon(8);
        }
      }
    }

    // distance (meters) — score also includes near-miss bonus
    if (-this.py > this.maxHeight) {
      this.maxHeight = -this.py;
      this.dist = Math.floor(this.maxHeight / SCORE_DIV);
    }
    const info = worldAt(this.dist);
    if (info.seg !== this.curSeg && this.curIdx !== DRAGON_WORLD) this.enterWorld(info);

    // camera follows upward progress only
    const camTarget = this.py - this.viewH * 0.42;
    if (camTarget < this.camY) this.camY += (camTarget - this.camY) * Math.min(1, dt * 9);

    this.generate();
    this.updateSpawns(dt);
    this.updateHazards(dt);

    // death: lava or falling off the bottom
    if (this.state === "playing" && (this.py > this.lavaY + 2 || this.py > this.camY + this.viewH + 80)) {
      if (this.god) {
        // test mode only: bounce back up instead of dying
        this.py = Math.min(this.py, this.camY + this.viewH - 60);
        this.lavaY = this.py + 400;
        this.vy = -JUMP_V * 1.3;
      } else {
        this.state = "dying";
        this.deathBy = "lava";
        this.dyingT = 0;
        audio.sfx("die");
        this.burst(this.px, Math.min(this.py, this.lavaY), 22, ["#ff7a18", "#ffd23f", "#ff3d00"], 200);
      }
    }

    this.hudT += dt;
    if (this.hudT > 0.1) this.emitHud();
  }

  private emitHud() {
    this.hudT = 0;
    const powers: HudPower[] = [];
    if (this.rocketT > 0) powers.push({ type: "rocket", frac: this.rocketT / ROCKET_TIME });
    if (this.shieldT > 0) powers.push({ type: "shield", frac: this.shieldT / POWER_DURATION.shield });
    if (this.magnetT > 0) powers.push({ type: "magnet", frac: this.magnetT / POWER_DURATION.magnet });
    if (this.doubleT > 0) powers.push({ type: "double", frac: this.doubleT / POWER_DURATION.double });
    if (this.slowT > 0) powers.push({ type: "slow", frac: this.slowT / POWER_DURATION.slow });
    const boss = this.boss.active ? Math.min(1, Math.max(0, (this.dist - (this.curSeg * WORLD_LEN + WORLD_LEN - BOSS_TAIL)) / BOSS_TAIL)) : -1;
    this.cb.onHud({
      score: this.dist + this.bonus, distance: this.dist, bonus: this.bonus, coins: this.runCoins, powers, boss,
      dragon: this.dragonActive ? { hp: this.dragon.hp, maxHp: this.dragon.maxHp, phase: this.dragon.phase } : null,
      ability: this.abilityDef
        ? {
            id: this.abilityDef.id,
            name: this.abilityDef.name,
            ready: this.abilityReady(),
            frac: this.abilityDef.cooldown > 0 ? 1 - this.abilityCd / this.abilityDef.cooldown : this.abilityCharges / (this.abilityDef.charges || 1),
            charges: this.abilityCharges,
          }
        : null,
    });
  }

  // --- rendering ---------------------------------------------------------------------------------------------------------------------
  private render() {
    const ctx = this.ctx;
    const W = WORLD_W;
    const H = this.viewH;
    const cam = this.camY;
    const t = this.time;

    // background (cross-fades between worlds)
    if (this.transT < 1 && this.prevIdx !== this.curIdx) {
      drawWorldBackground(ctx, this.prevIdx, W, H, cam, t);
      ctx.globalAlpha = this.transT;
      drawWorldBackground(ctx, this.curIdx, W, H, cam, t);
      ctx.globalAlpha = 1;
    } else {
      drawWorldBackground(ctx, this.curIdx, W, H, cam, t);
    }

    this.drawAmbient(ctx, H);

    // coins
    for (const c of this.coins) {
      if (c.taken) continue;
      const sy = c.y - cam;
      if (sy < -30 || sy > H + 30) continue;
      drawCoin(ctx, c.x, sy + Math.sin(t * 3 + c.phase) * 3, 10, t * 4 + c.phase);
    }
    // power-ups
    for (const it of this.powerItems) {
      if (it.taken) continue;
      const sy = it.y - cam;
      if (sy < -40 || sy > H + 40) continue;
      drawPowerup(ctx, it.type, it.x, sy + Math.sin(t * 3 + it.phase) * 4, t);
    }

    // candy bonuses
    for (const cd of this.candies) {
      if (cd.taken) continue;
      const cy2 = cd.y - cam;
      if (cy2 < -30 || cy2 > H + 30) continue;
      drawCandy(ctx, cd.x, cy2 + Math.sin(t * 3 + cd.phase) * 3, 11, t * 3.4 + cd.phase);
    }

    // platforms (+ mounted hazards)
    for (const p of this.platforms) {
      const sy = p.y - cam;
      if (sy < -50 || sy > H + 30) continue;
      const dur = FRAGILE_DUR[p.kind] ?? 0.5;
      const anim: PlatAnim = {};
      if (p.kind === "ghost") anim.alpha = this.ghostAlpha(p);
      if (p.kind === "electric") {
        const cp = (t + p.phase) % 2.4;
        anim.charge = cp > 1.5 ? 1 : cp > 1.1 ? 0.45 : 0;
        anim.push = p.push;
      }
      if (p.kind === "jelly") anim.wob = Math.min(1, Math.abs(this.vy) / 700);
      const fade = p.crumbling ? Math.min(1, p.crumbleT / dur) : 0;
      if (EXPANSION_KINDS.has(p.kind)) {
        const ep = expansionPlatform(p, t);
        drawExpansionPlatform(ctx, p, p.x, sy, t, ep.alpha, fade);
        if (p.rune && !p.runeTaken && !p.dead) drawRune(ctx, p.x + p.w / 2, sy - 38, t);
        if (this.dragon.warning && this.dragonTargets.includes(p)) drawWarning(ctx, p.x + p.w / 2, sy - 48, "#ffd166", t);
      } else {
        drawPlatform(ctx, p.x, sy, p.w, p.kind, fade, p.theme, t, anim);
      }
      const hz = p.haz;
      if (hz && !p.dead) {
        const hx = p.x + (hz.side < 0 ? 12 : p.w - 12);
        if (hz.type === "press" || hz.type === "pendulum" || hz.type === "clockhand") drawExpansionMounted(ctx, hz.type, hx, p, sy, t);
        else if (hz.type === "cactus") drawCactus(ctx, hx, sy + 2);
        else if (hz.type === "spike") drawSpikes(ctx, hx - 17, sy + 2, 34);
        else if (hz.type === "blade") drawBlade(ctx, hx, sy - 60, Math.sin(t * 1.8 + hz.phase) * 1.15, 54);
        else {
          const st = plantStage(t, hz.phase);
          drawPlant(ctx, hx, sy + 2, st.stage, st.u, t);
        }
      }
    }

    // active falling / flying hazards
    for (const h of this.hazards) {
      if (h.warn > 0 || h.dead) continue;
      const sy = h.y - cam;
      if (sy < -110 || sy > H + 50) continue;
      if (EXPANSION_HAZARDS.has(h.kind)) drawExpansionHazard(ctx, h.kind, h.x, sy, t, h.dir, h.vx, h.vy || h.g * 0.2);
      else drawHazard(ctx, h.kind, h.x, sy, t, h.dir, h.vx, h.vy || h.g * 0.2);
    }

    // cyber lasers (drawn over the level, under the HUD)
    for (const bm of this.beams) {
      const sy = bm.y - cam;
      if (sy < -24 || sy > H + 24) continue;
      drawLaser(ctx, bm.x0, bm.x1, sy, bm.state, bm.state === 1 ? 1 - bm.t / LASER_FIRE : bm.t / LASER_WARN, t);
    }

    if (this.dragonActive) drawDragon(ctx, this.dragon, this.dragon.y - cam, t);

    // player (hidden once swallowed by lava)
    const feetScreen = this.py - cam;
    const lavaScreen = this.lavaY - cam;
    if (!(this.state !== "playing" && this.deathBy === "lava" && this.py > this.lavaY)) {
      const phase = t * 4;
      if (this.rocketT > 0) this.drawFlame(ctx, this.px, feetScreen);
      const blink = this.invulnT > 0 && this.rocketT <= 0 && Math.floor(t * 14) % 2 === 0;
      if (blink) ctx.globalAlpha = 0.45;
      drawPlayer(ctx, this.px, feetScreen, this.facing, this.stretch, phase, this.skin);
      ctx.globalAlpha = 1;
      if (this.shieldT > 0) this.drawShield(ctx, this.px, feetScreen - 28, t);
    }

    // particles
    for (const p of this.particles) {
      ctx.globalAlpha = Math.max(0, 1 - p.life / p.max);
      ctx.fillStyle = p.color;
      ctx.fillRect(p.x - p.size / 2, p.y - cam - p.size / 2, p.size, p.size);
    }
    ctx.globalAlpha = 1;

    this.drawLava(ctx, W, H, lavaScreen);

    // the Warden rises out of the lava during the final duel
    if (this.boss.active || this.boss.hurt > 0) {
      const by = lavaScreen - 4;
      if (by > -140 && by < H + 120) {
        drawBoss(ctx, this.boss.x, by, t, this.boss.open, this.boss.hurt);
        if (this.boss.surge > 0) {
          const pulse = ctx.createLinearGradient(0, H, 0, H - 200);
          pulse.addColorStop(0, `rgba(255,70,30,${0.3 * Math.min(1, this.boss.surge)})`);
          pulse.addColorStop(1, "rgba(255,70,30,0)");
          ctx.fillStyle = pulse;
          ctx.fillRect(0, H - 200, W, 200);
        }
      }
    }

    // weather tint
    if (this.storm > 0.02) {
      ctx.fillStyle = this.curIdx === 1 ? `rgba(235,245,255,${this.storm * 0.2})` : this.curIdx === 6 ? `rgba(120,200,230,${this.storm * 0.22})` : `rgba(240,185,100,${this.storm * 0.24})`;
      ctx.fillRect(0, 0, W, H);
    }

    // danger glow when lava is close
    const dist = lavaScreen - feetScreen;
    if (this.state === "playing" && dist < 170) {
      const a = (1 - Math.max(0, dist) / 170) * (0.28 + 0.1 * Math.sin(t * 9));
      const g = ctx.createLinearGradient(0, H, 0, H - 260);
      g.addColorStop(0, `rgba(255,60,20,${a})`);
      g.addColorStop(1, "rgba(255,60,20,0)");
      ctx.fillStyle = g;
      ctx.fillRect(0, H - 260, W, 260);
    }

    this.drawWarnings(ctx, W, H, cam, lavaScreen, t);

    // floating texts
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.lineJoin = "round";
    for (const f of this.texts) {
      ctx.globalAlpha = Math.max(0, Math.min(1, (1.2 - f.life) * 2));
      ctx.font = "700 15px 'Fredoka Variable', 'Trebuchet MS', sans-serif";
      ctx.lineWidth = 4;
      ctx.strokeStyle = "#1b0a3d";
      const x = Math.max(50, Math.min(W - 50, f.x));
      ctx.strokeText(f.text, x, f.y - cam);
      ctx.fillStyle = f.color;
      ctx.fillText(f.text, x, f.y - cam);
    }
    ctx.globalAlpha = 1;
  }

  private drawFlame(ctx: CanvasRenderingContext2D, x: number, y: number) {
    const fl = 26 + Math.random() * 14;
    ctx.fillStyle = "#ff7a18";
    ctx.beginPath();
    ctx.moveTo(x - 8, y - 4);
    ctx.quadraticCurveTo(x - 5, y + fl * 0.6, x, y + fl);
    ctx.quadraticCurveTo(x + 5, y + fl * 0.6, x + 8, y - 4);
    ctx.fill();
    ctx.fillStyle = "#ffe066";
    ctx.beginPath();
    ctx.moveTo(x - 4, y - 4);
    ctx.quadraticCurveTo(x - 2, y + fl * 0.4, x, y + fl * 0.65);
    ctx.quadraticCurveTo(x + 2, y + fl * 0.4, x + 4, y - 4);
    ctx.fill();
  }

  private drawShield(ctx: CanvasRenderingContext2D, x: number, y: number, t: number) {
    const lowFlash = this.shieldT < 4 && Math.floor(t * 8) % 2 === 0;
    ctx.save();
    ctx.globalAlpha = lowFlash ? 0.35 : 1;
    const g = ctx.createRadialGradient(x, y, 12, x, y, 36);
    g.addColorStop(0, "rgba(120,210,255,0.05)");
    g.addColorStop(1, "rgba(120,210,255,0.42)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(x, y, 36 + Math.sin(t * 6) * 1.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.lineWidth = 2.5;
    ctx.strokeStyle = "rgba(200,240,255,0.95)";
    ctx.stroke();
    ctx.restore();
  }

  private drawAmbient(ctx: CanvasRenderingContext2D, H: number) {
    const idx = this.curIdx;
    if (idx >= 12) {
      const count = Math.min(AMB_MAX, WORLDS[idx].ambient);
      const fade = Math.min(1, this.transT * 1.5);
      for (let i = 0; i < count; i++) drawExpansionAmbient(ctx, this.amb[i], idx, this.time, fade);
      return;
    }
    const count = Math.min(AMB_MAX, WORLDS[idx].ambient + Math.round(this.storm * 50));
    const fade = Math.min(1, this.transT * 1.5);
    const t = this.time;
    ctx.save();
    for (let i = 0; i < count; i++) {
      const a = this.amb[i];
      if (a.y > H + 14) continue;
      switch (idx) {
        case 0:
          ctx.fillStyle = `rgba(200,160,255,${0.3 * fade})`;
          ctx.beginPath();
          ctx.arc(a.x, a.y, 1 + a.s * 1.4, 0, Math.PI * 2);
          ctx.fill();
          break;
        case 1:
          ctx.fillStyle = `rgba(255,255,255,${0.85 * fade})`;
          ctx.beginPath();
          ctx.arc(a.x, a.y, 1.2 + a.s * 1.8, 0, Math.PI * 2);
          ctx.fill();
          break;
        case 2:
          ctx.fillStyle = `rgba(255,${130 + Math.floor(a.s * 90)},40,${(0.5 + 0.4 * Math.sin(t * 6 + a.ph)) * fade})`;
          ctx.fillRect(a.x, a.y, 2 + a.s * 2, 2 + a.s * 2);
          break;
        case 3:
          ctx.save();
          ctx.translate(a.x, a.y);
          ctx.rotate(a.rot);
          ctx.fillStyle = a.s > 0.6 ? `rgba(200,220,80,${0.85 * fade})` : `rgba(90,200,90,${0.85 * fade})`;
          ctx.beginPath();
          ctx.ellipse(0, 0, 4.5, 2.2, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
          break;
        case 4: {
          const len = 6 + this.storm * 18;
          ctx.strokeStyle = `rgba(255,228,170,${0.55 * fade})`;
          ctx.lineWidth = 1.4;
          ctx.beginPath();
          ctx.moveTo(a.x, a.y);
          ctx.lineTo(a.x - len, a.y - 1);
          ctx.stroke();
          break;
        }
        case 5: {
          const len = 16 + a.s * 22 + Math.abs(this.wind) * 0.5;
          ctx.strokeStyle = `rgba(255,255,255,${0.38 * fade})`;
          ctx.lineWidth = 1.6;
          ctx.beginPath();
          ctx.moveTo(a.x, a.y);
          ctx.lineTo(a.x + len, a.y);
          ctx.stroke();
          break;
        }
        case 6: {
          const r = 1.6 + a.s * 3.4;
          ctx.strokeStyle = `rgba(200,245,255,${0.6 * fade})`;
          ctx.lineWidth = 1.4;
          ctx.beginPath();
          ctx.arc(a.x, a.y, r, 0, Math.PI * 2);
          ctx.stroke();
          ctx.fillStyle = `rgba(255,255,255,${0.22 * fade})`;
          ctx.fill();
          break;
        }
        case 7: {
          const r = 1.6 + a.s * 2.6;
          const g = ctx.createRadialGradient(a.x, a.y, 0.4, a.x, a.y, r * 3.4);
          g.addColorStop(0, `rgba(200,255,170,${0.85 * fade})`);
          g.addColorStop(1, "rgba(140,255,190,0)");
          ctx.fillStyle = g;
          ctx.beginPath();
          ctx.arc(a.x, a.y, r * 3.4, 0, Math.PI * 2);
          ctx.fill();
          break;
        }
        case 8: {
          const len = 8 + a.s * 18;
          ctx.strokeStyle = a.s > 0.5 ? `rgba(95,242,255,${0.5 * fade})` : `rgba(255,90,214,${0.5 * fade})`;
          ctx.lineWidth = 1.4;
          ctx.beginPath();
          ctx.moveTo(a.x, a.y);
          ctx.lineTo(a.x, a.y + len);
          ctx.stroke();
          break;
        }
        case 9: {
          ctx.fillStyle = `rgba(255,255,255,${(0.4 + 0.5 * Math.abs(Math.sin(t * 2 + a.ph))) * fade})`;
          const r = 0.8 + a.s * 1.5;
          ctx.fillRect(a.x, a.y, r, r);
          break;
        }
        case 10: {
          ctx.save();
          ctx.translate(a.x, a.y);
          ctx.rotate(a.rot * 2);
          ctx.fillStyle = (["#ff4d94", "#5ff2ff", "#ffe066", "#a06bff", "#7dffb0"][Math.floor(a.s * 5) % 5] as string) + Math.round(200 * fade).toString(16).padStart(2, "0");
          ctx.fillRect(-2.4, -1, 4.8, 2);
          ctx.restore();
          break;
        }
        default: {
          ctx.fillStyle = `rgba(150,120,140,${0.5 * fade})`;
          ctx.beginPath();
          ctx.arc(a.x, a.y, 1 + a.s * 1.6, 0, Math.PI * 2);
          ctx.fill();
          const e = 0.4 + 0.35 * Math.sin(t * 5 + a.ph);
          ctx.fillStyle = `rgba(255,120,60,${e * 0.5 * fade})`;
          if (a.s > 0.75) ctx.fillRect(a.x, a.y + 6, 1.6, 1.6);
          break;
        }
      }
    }
    ctx.restore();
  }

  private drawWarnings(ctx: CanvasRenderingContext2D, W: number, H: number, cam: number, lavaScreen: number, t: number) {
    for (const h of this.hazards) {
      if (h.warn <= 0 || h.dead) continue;
      const col = WARN_COLOR[h.kind];
      if (h.kind === "sporeseed") {
        drawWarning(ctx, h.x, H - 88, WARN_COLOR[h.kind], t);
      } else if (MOVER_KINDS.has(h.kind)) {
        const y = Math.max(120, Math.min(H - 110, h.y - cam));
        const x = h.dir > 0 ? 22 : W - 22;
        drawWarning(ctx, x, y, col, t);
        // arrow showing the direction of travel
        ctx.fillStyle = col;
        ctx.strokeStyle = "#1b0a3d";
        ctx.lineWidth = 2;
        ctx.beginPath();
        const ax = x + h.dir * 24;
        ctx.moveTo(ax + h.dir * 8, y);
        ctx.lineTo(ax - h.dir * 2, y - 8);
        ctx.lineTo(ax - h.dir * 2, y + 8);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      } else if (h.kind === "fireball") {
        const y = lavaScreen - 34;
        if (y > 100 && y < H) {
          ctx.fillStyle = `rgba(255,200,80,${0.5 + 0.3 * Math.sin(t * 16)})`;
          ctx.beginPath();
          ctx.ellipse(h.x, lavaScreen - 2, 22, 7, 0, 0, Math.PI * 2);
          ctx.fill();
          drawWarning(ctx, h.x, y, col, t);
        }
      } else {
        drawWarning(ctx, h.x, 132, col, t, Math.min(260, H - 160));
      }
    }
    // wind gust warning (sky world)
    if (this.windState === 1 || (this.windState === 2 && this.windTimer > 0 && Math.abs(this.wind) > 8)) {
      const warn = this.windState === 1;
      ctx.save();
      ctx.globalAlpha = warn ? 0.55 + 0.4 * Math.sin(t * 14) : 0.5;
      ctx.lineWidth = 4;
      ctx.strokeStyle = "#ffffff";
      ctx.lineCap = "round";
      ctx.lineJoin = "round";
      const y = 150;
      const d = this.windDir;
      const shift = ((t * 70) % 30) * d;
      for (let i = 0; i < 3; i++) {
        const x = W / 2 + (i - 1) * 30 + shift;
        ctx.beginPath();
        ctx.moveTo(x - d * 8, y - 12);
        ctx.lineTo(x + d * 6, y);
        ctx.lineTo(x - d * 8, y + 12);
        ctx.stroke();
      }
      ctx.restore();
    }
  }

  private drawLava(ctx: CanvasRenderingContext2D, W: number, H: number, ly: number) {
    if (ly > H + 20) return;
    const t = this.time;
    // glow above surface
    const glow = ctx.createLinearGradient(0, ly - 110, 0, ly);
    glow.addColorStop(0, "rgba(255,90,20,0)");
    glow.addColorStop(1, "rgba(255,110,30,0.4)");
    ctx.fillStyle = glow;
    ctx.fillRect(0, ly - 110, W, 110);

    const wave = (x: number) => Math.sin(x * 0.045 + t * 2.2) * 5 + Math.sin(x * 0.11 - t * 3.1) * 2.5;
    const body = ctx.createLinearGradient(0, ly, 0, ly + 140);
    body.addColorStop(0, "#ffc233");
    body.addColorStop(0.12, "#ff7a18");
    body.addColorStop(0.55, "#e0310f");
    body.addColorStop(1, "#8c0f08");
    ctx.fillStyle = body;
    ctx.beginPath();
    ctx.moveTo(0, H + 20);
    for (let x = 0; x <= W; x += 6) ctx.lineTo(x, ly + wave(x));
    ctx.lineTo(W, H + 20);
    ctx.closePath();
    ctx.fill();

    // bright crest line
    ctx.strokeStyle = this.slowT > 0 ? "#bff3ff" : "#ffe28a";
    ctx.lineWidth = 3;
    ctx.lineJoin = "round";
    ctx.beginPath();
    for (let x = 0; x <= W; x += 6) {
      const y = ly + wave(x);
      if (x === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    // bubbles
    ctx.fillStyle = "rgba(255,220,120,0.75)";
    for (let i = 0; i < 7; i++) {
      const bx = hash(i * 3.3) * W;
      const ph = (t * 0.5 + hash(i) * 3) % 1;
      const by = ly + 40 - ph * 55 + wave(bx);
      const r = 2 + hash(i + 5) * 3.5 * (1 - ph);
      ctx.beginPath();
      ctx.arc(bx, by, r, 0, Math.PI * 2);
      ctx.fill();
    }
  }
}

