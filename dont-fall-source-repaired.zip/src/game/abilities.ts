// Abilities: each character owns exactly ONE exclusive ability.
// An ability is a separate coin purchase from the character itself, is bound to that character only,
// and must be owned AND equipped before the in-game ability button appears.

export interface AbilityDef {
  id: string;
  /** Owning character skin id. The ability can never be used by another character. */
  character: string;
  name: string;
  desc: string;
  price: number;
  /** Seconds before the ability can be used again. 0 = charge-based (see charges). */
  cooldown: number;
  /** How long the effect lasts once triggered. 0 = instant. */
  duration: number;
  /** Charge-based abilities (e.g. super-bounce) carry charges instead of a timed effect. */
  charges?: number;
}

export const ABILITIES: AbilityDef[] = [
  { id: "adventurers_grit", character: "original", name: "Adventurer's Grit", desc: "One extra jump impulse in mid-air.", price: 500, cooldown: 12, duration: 0 },
  { id: "shadow_dash", character: "ninja", name: "Shadow Dash", desc: "Dash forward and pass through hazards for a moment.", price: 800, cooldown: 14, duration: 0.45 },
  { id: "piton_spike", character: "explorer", name: "Piton Spike", desc: "Hammer a temporary ledge beneath your feet.", price: 1100, cooldown: 18, duration: 0 },
  { id: "overclock", character: "robot", name: "Overclock", desc: "Move 30% faster and jump slightly higher for 5s.", price: 1400, cooldown: 20, duration: 5 },
  { id: "broadside", character: "pirate", name: "Broadside", desc: "Fire every cannon: clear the screen of hazards.", price: 2200, cooldown: 28, duration: 0 },
  { id: "zero_g", character: "astronaut", name: "Zero-G Suit", desc: "Cut gravity by 30% for 4 seconds.", price: 1900, cooldown: 18, duration: 4 },
  { id: "time_warp", character: "wizard", name: "Time Warp", desc: "Hazards fall at half speed for 4 seconds.", price: 2600, cooldown: 20, duration: 4 },
  { id: "avalanche_ride", character: "snow", name: "Avalanche Ride", desc: "Your next 2 landings launch you much higher.", price: 2200, cooldown: 0, duration: 0, charges: 2 },
  { id: "molten_aura", character: "fire", name: "Molten Aura", desc: "Burn hazards that come within reach for 5s.", price: 3200, cooldown: 20, duration: 5 },
  { id: "vine_swing", character: "ranger", name: "Vine Swing", desc: "Swing up onto the nearest platform above you.", price: 3600, cooldown: 18, duration: 0 },
  { id: "mirage", character: "desert", name: "Mirage", desc: "Become untouchable for 2.5 seconds.", price: 3000, cooldown: 20, duration: 2.5 },
  { id: "treasure_rain", character: "royal", name: "Treasure Rain", desc: "Rains 6 coins around you.", price: 4500, cooldown: 30, duration: 0 },
  { id: "perfect_balance", character: "jester", name: "Perfect Balance", desc: "Instant steering and no wind for 5 seconds.", price: 5200, cooldown: 18, duration: 5 },
  { id: "quick_draw", character: "cowboy", name: "Quick Draw", desc: "Shoot the 3 nearest hazards out of the sky.", price: 6000, cooldown: 14, duration: 0 },
  { id: "wing_beat", character: "bumblebee", name: "Wing Beat", desc: "Flutter gently: 55% lower gravity for 3 seconds.", price: 6800, cooldown: 18, duration: 3 },
  { id: "recipe_day", character: "chef", name: "Recipe of the Day", desc: "Cook up a random power-up above you.", price: 7500, cooldown: 30, duration: 0 },
  { id: "primal_roar", character: "dino", name: "Primal Roar", desc: "Roar: falling hazards flee back upward.", price: 8500, cooldown: 22, duration: 0 },
  { id: "mist_form", character: "vampire", name: "Mist Form", desc: "Become mist: your body is 45% smaller for 6s.", price: 9800, cooldown: 20, duration: 6 },
  { id: "iai_slash", character: "samurai", name: "Iai Slash", desc: "Slice every hazard in the column above you.", price: 11500, cooldown: 16, duration: 0 },
  { id: "dragons_wrath", character: "dragonslayer", name: "Dragon's Wrath", desc: "Unleash the hoard: clear everything and stay safe for 3s.", price: 15000, cooldown: 35, duration: 3 },
];

export const ABILITY_MAP: Record<string, AbilityDef> = Object.fromEntries(ABILITIES.map((a) => [a.id, a]));

export function abilityForCharacter(characterId: string): AbilityDef | undefined {
  return ABILITIES.find((a) => a.character === characterId);
}

export function abilityById(id: string): AbilityDef | undefined {
  return ABILITY_MAP[id];
}

/** The ability usable right now for an equipped character, or null when none is owned+equipped. */
export function equippedAbility(save: { owned: string[]; equipped: string; abilities: { owned: string[]; equipped: Record<string, string> } }): AbilityDef | null {
  const id = save.abilities?.equipped?.[save.equipped];
  if (!id) return null;
  const def = ABILITY_MAP[id];
  if (!def) return null;
  // An ability belongs to exactly one character and only works while that character is equipped.
  if (def.character !== save.equipped) return null;
  if (!save.owned.includes(save.equipped)) return null;
  if (!save.abilities.owned.includes(id)) return null;
  return def;
}

export type AbilityBlock = { ok: false; reason: "owned-ability" | "no-character" | "funds" | "unknown" };
export type AbilityCheck = { ok: true; ability: AbilityDef } | AbilityBlock;

/** Validated in the state layer so a crafted UI event can never bypass the rules. */
export function checkAbilityBuy(id: string, save: { owned: string[]; coins: number; abilities: { owned: string[] } }): AbilityCheck {
  const def = ABILITY_MAP[id];
  if (!def) return { ok: false, reason: "unknown" };
  if (save.abilities.owned.includes(id)) return { ok: false, reason: "owned-ability" };
  if (!save.owned.includes(def.character)) return { ok: false, reason: "no-character" };
  if (save.coins < def.price) return { ok: false, reason: "funds" };
  return { ok: true, ability: def };
}
