// Character skins. All skins share the exact same body proportions, hitbox and animation —
// only colours and headgear differ (purely cosmetic, no gameplay advantage).

export type HatStyle =
  | "explorer"
  | "pith"
  | "ninja"
  | "robot"
  | "pirate"
  | "astro"
  | "beanie"
  | "knight"
  | "ranger"
  | "turban"
  | "wizard"
  | "crown"
  | "dragon"
  | "jester"
  | "cowboy"
  | "bee"
  | "chef"
  | "dino"
  | "vampire"
  | "samurai";

export interface Skin {
  id: string;
  name: string;
  price: number;
  blurb: string;
  jacketTop: string;
  jacketBot: string;
  belt: string;
  buckle: string;
  scarf: string;
  boots: string;
  pack: string;
  packTrim: string;
  face: string;
  hat: HatStyle;
  hatBrim: string;
  hatMain1: string;
  hatMain2: string;
  hatBand: string;
  accent: string;
}

/** The original adventurer — default, free, drawn exactly as before. */
export const ORIGINAL: Skin = {
  id: "original",
  name: "Original Adventurer",
  price: 0,
  blurb: "Where it all began.",
  jacketTop: "#ff9f43",
  jacketBot: "#e2671c",
  belt: "#4a2a14",
  buckle: "#ffd23f",
  scarf: "#e63946",
  boots: "#5b3418",
  pack: "#8a5a2b",
  packTrim: "#c28a4a",
  face: "#ffd7b0",
  hat: "explorer",
  hatBrim: "#b9803f",
  hatMain1: "#d79a52",
  hatMain2: "#a76f33",
  hatBand: "#e63946",
  accent: "#ffd23f",
};

const base = ORIGINAL;
const mk = (o: Partial<Skin> & Pick<Skin, "id" | "name" | "price" | "blurb" | "hat">): Skin => ({ ...base, ...o });

export const SKINS: Skin[] = [
  ORIGINAL,
  mk({
    id: "ninja", name: "Ninja", price: 360, blurb: "Silent, swift and stylish.", hat: "ninja",
    jacketTop: "#3a3d5c", jacketBot: "#171827", belt: "#e63946", buckle: "#c9d1dc", scarf: "#e63946",
    boots: "#171827", pack: "#2c2f48", packTrim: "#e63946", hatBand: "#e63946", hatBrim: "#171827", hatMain1: "#22243a", hatMain2: "#14151f", accent: "#c9d1dc",
  }),
  mk({
    id: "explorer", name: "Explorer", price: 650, blurb: "Pith helmet, safari vest.", hat: "pith",
    jacketTop: "#d6b66a", jacketBot: "#a98536", belt: "#5b3a1a", scarf: "#3f9d4a", boots: "#6b4423",
    pack: "#4d6b3a", packTrim: "#9ccf6b", hatBrim: "#d9c18a", hatMain1: "#f6ebc5", hatMain2: "#dcc48c", hatBand: "#3f9d4a",
  }),
  mk({
    id: "robot", name: "Robot", price: 1050, blurb: "Beep boop. Bounce bounce.", hat: "robot",
    jacketTop: "#9fb3c8", jacketBot: "#62768d", belt: "#2f3b4a", buckle: "#5ff2ff", scarf: "#3fb7ff", boots: "#38465a",
    pack: "#46586f", packTrim: "#5ff2ff", face: "#cfd8e3", hatMain1: "#5ff2ff", accent: "#ff4d4d",
  }),
  mk({
    id: "pirate", name: "Pirate", price: 1500, blurb: "Yarr! Lava be no match.", hat: "pirate",
    jacketTop: "#a3232f", jacketBot: "#661019", belt: "#2a1a10", scarf: "#f5f0e0", boots: "#2a1a10",
    pack: "#5b3a1a", packTrim: "#d8a24a", hatBrim: "#14141a", hatMain1: "#2e2e3a", hatMain2: "#1a1a22", hatBand: "#ffd23f",
  }),
  mk({
    id: "astronaut", name: "Astronaut", price: 2400, blurb: "Low gravity? Not today.", hat: "astro",
    jacketTop: "#f4f7fb", jacketBot: "#c1cbd9", belt: "#ff7a18", scarf: "#ff7a18", boots: "#8b97a8",
    pack: "#b9c2d0", packTrim: "#ff7a18", hatBand: "#ff7a18",
  }),
  mk({
    id: "wizard", name: "Wizard", price: 2500, blurb: "A little magic never hurts.", hat: "wizard",
    jacketTop: "#7a4be0", jacketBot: "#4a24a8", belt: "#ffd23f", buckle: "#fff29a", scarf: "#a58bff", boots: "#2f1a6b",
    pack: "#4a2f9a", packTrim: "#ffd23f", hatBrim: "#4a24a8", hatMain1: "#8456f0", hatMain2: "#4a24a8", hatBand: "#ffd23f",
  }),
  mk({
    id: "snow", name: "Snow Explorer", price: 3240, blurb: "Cozy parka, cold peaks.", hat: "beanie",
    jacketTop: "#66b9f2", jacketBot: "#3a82c4", belt: "#f5f9ff", buckle: "#9edcff", scarf: "#ffffff", boots: "#2f4f7a",
    pack: "#e8f3ff", packTrim: "#7fc4ff", hatMain1: "#ee5468", hatMain2: "#c0293f", hatBand: "#ffffff", hatBrim: "#ffffff",
  }),
  mk({
    id: "fire", name: "Fire Knight", price: 4180, blurb: "Forged in the volcano.", hat: "knight",
    jacketTop: "#c4232f", jacketBot: "#7a1019", belt: "#ffc61f", buckle: "#fff29a", scarf: "#ff7a18", boots: "#4a4f5c",
    pack: "#5a5f6e", packTrim: "#ffc61f", hatMain1: "#d3dae4", hatMain2: "#8f9aaa", hatBand: "#ffc61f", accent: "#ff6a1a",
  }),
  mk({
    id: "ranger", name: "Forest Ranger", price: 5000, blurb: "One with the treetops.", hat: "ranger",
    jacketTop: "#49ac55", jacketBot: "#2a6d34", belt: "#5b3a1a", scarf: "#8b5a2b", boots: "#4a2f18",
    pack: "#6b4423", packTrim: "#d8a24a", hatMain1: "#3a9444", hatMain2: "#256a2f", hatBand: "#e63946", hatBrim: "#256a2f",
  }),
  mk({
    id: "desert", name: "Desert Traveler", price: 5800, blurb: "Sun-proof and sand-ready.", hat: "turban",
    jacketTop: "#ecca84", jacketBot: "#c79a4a", belt: "#7a4a1a", buckle: "#3fb7ff", scarf: "#2a6fd6", boots: "#8b5a2b",
    pack: "#b8864a", packTrim: "#f1d9a0", hatMain1: "#f8f1e2", hatMain2: "#d8cdb0", hatBand: "#3fb7ff",
  }),
  mk({
    id: "royal", name: "Royal Gold", price: 7000, blurb: "For true climbing legends.", hat: "crown",
    jacketTop: "#ffd84a", jacketBot: "#e0a000", belt: "#7a2a2a", buckle: "#ff5a6a", scarf: "#c01f3a", boots: "#7a4a00",
    pack: "#c01f3a", packTrim: "#ffd23f", hatMain1: "#ffd84a", hatMain2: "#e0a000", hatBand: "#ff5a6a", hatBrim: "#e0a000",
  }),
  mk({
    id: "jester", name: "Jester", price: 8200, blurb: "Three bells, zero fear.", hat: "jester",
    jacketTop: "#e94f8d", jacketBot: "#b32a63", belt: "#ffd166", buckle: "#fff3b0", scarf: "#2ec4b6", boots: "#5b1d43",
    pack: "#2ec4b6", packTrim: "#ffd166", hatMain1: "#e94f8d", hatMain2: "#b32a63", hatBand: "#2ec4b6", hatBrim: "#e94f8d", accent: "#ffd166",
  }),
  mk({
    id: "cowboy", name: "Cowboy", price: 9500, blurb: "Fastest boots in the canyon.", hat: "cowboy",
    jacketTop: "#5b84c4", jacketBot: "#3a5a94", belt: "#6b4423", buckle: "#ffd166", scarf: "#e63946", boots: "#4a2f18",
    pack: "#8a5a2b", packTrim: "#c28a4a", hatMain1: "#a9743c", hatMain2: "#7c5228", hatBand: "#5b3418", hatBrim: "#8a5a2b", accent: "#ffd166",
  }),
  mk({
    id: "bumblebee", name: "Bumblebee", price: 11000, blurb: "Bzz! Danger level: cute.", hat: "bee",
    jacketTop: "#ffd166", jacketBot: "#f2a51c", belt: "#3a2410", buckle: "#fff6c0", scarf: "#ffd166", boots: "#3a2410",
    pack: "#3a2410", packTrim: "#ffd166", face: "#ffd7b0", hatMain1: "#ffd166", hatMain2: "#3a2410", hatBand: "#3a2410", hatBrim: "#ffd166", accent: "#ffd166",
  }),
  mk({
    id: "chef", name: "Chef", price: 12500, blurb: "Five-star jumps. Michelin-climbing.", hat: "chef",
    jacketTop: "#f6f8fb", jacketBot: "#d3dae4", belt: "#e63946", buckle: "#ffd166", scarf: "#e63946", boots: "#8b97a8",
    pack: "#d3dae4", packTrim: "#e63946", hatMain1: "#ffffff", hatMain2: "#e4e9f0", hatBand: "#c28a4a", hatBrim: "#e4e9f0",
  }),
  mk({
    id: "dino", name: "Dinosaur", price: 14200, blurb: "Prehistoric bounce.", hat: "dino",
    jacketTop: "#7cb342", jacketBot: "#558b2f", belt: "#6b4423", buckle: "#ffd166", scarf: "#ffca28", boots: "#33691e",
    pack: "#558b2f", packTrim: "#ffca28", hatMain1: "#8bc34a", hatMain2: "#558b2f", hatBand: "#ffca28", hatBrim: "#689f38",
  }),
  mk({
    id: "vampire", name: "Vampire", price: 16000, blurb: "Never climbs after dark.", hat: "vampire",
    jacketTop: "#7a1f3d", jacketBot: "#4a1029", belt: "#1b0a1f", buckle: "#ffd166", scarf: "#1b0a1f", boots: "#1b0a1f",
    pack: "#4a1029", packTrim: "#7a1f3d", face: "#f0e4dc", hatMain1: "#17111f", hatMain2: "#0d0913", hatBand: "#7a1f3d", hatBrim: "#17111f", accent: "#e63946",
  }),
  mk({
    id: "samurai", name: "Samurai", price: 18000, blurb: "The calm before the bounce.", hat: "samurai",
    jacketTop: "#a33327", jacketBot: "#6d1a12", belt: "#ffd166", buckle: "#fff3b0", scarf: "#ffd166", boots: "#2a0f0b",
    pack: "#6d1a12", packTrim: "#ffd166", hatMain1: "#221d2e", hatMain2: "#120e1a", hatBand: "#ffd166", hatBrim: "#221d2e", accent: "#ffd166",
  }),
];

/** Exclusive stage-20 reward. Not for sale and deliberately outside the 12-step purchase sequence. */
export const SECRET_SKIN: Skin = mk({
  id: "dragonslayer", name: "Dragon Slayer", price: 0, blurb: "Defeat the Dragon to earn this legendary hero.", hat: "dragon",
  jacketTop: "#ff7043", jacketBot: "#8d1f2d", belt: "#ffd166", buckle: "#fff3b0", scarf: "#ffd166", boots: "#321522",
  pack: "#5b2745", packTrim: "#ffb347", hatMain1: "#a82932", hatMain2: "#5b2745", hatBand: "#ffd166", hatBrim: "#5b2745", accent: "#ff7043",
});

export const ALL_SKINS: Skin[] = [...SKINS, SECRET_SKIN];

export function skinById(id: string): Skin {
  return ALL_SKINS.find((s) => s.id === id) ?? ORIGINAL;
}

// ---------------------------------------------------------------------------
// STRICT SEQUENTIAL UNLOCK RULE
// A character can only be bought when *every* character before it in SKINS is
// already owned. Coins never bypass it. Validity is always derived from the
// saved purchase history (`owned`), never from the balance. Purchases are never
// revoked — an older save that bought out of order keeps those characters.
// ---------------------------------------------------------------------------
export function knownOwned(owned: string[]): string[] {
  const seen = new Set<string>();
  for (const id of owned) if (ALL_SKINS.some((s) => s.id === id) && !seen.has(id)) seen.add(id);
  return [...seen];
}

export function ownedSet(owned: string[]): Set<string> {
  return new Set(knownOwned(owned));
}

export function skinIndex(id: string): number {
  return SKINS.findIndex((s) => s.id === id);
}

/** The only character that may be purchased right now (-1 once the set is complete). */
export function nextBuyIndex(owned: string[]): number {
  const set = ownedSet(owned);
  for (let i = 0; i < SKINS.length; i++) if (!set.has(SKINS[i].id)) return i;
  return -1;
}

/** First character missing from the chain before `index` — the one blocking it. */
export function missingBefore(index: number, owned: string[]): Skin | null {
  const set = ownedSet(owned);
  for (let i = 0; i < index; i++) if (!set.has(SKINS[i].id)) return SKINS[i];
  return null;
}

export type BuyBlock = { ok: false; reason: "owned" | "sequence" | "complete" | "funds"; missing?: Skin; need?: number };
export type BuyCheck = { ok: true; skin: Skin } | BuyBlock;

export function checkBuy(index: number, owned: string[], coins: number): BuyCheck {
  if (index < 0 || index >= SKINS.length) return { ok: false, reason: "complete" };
  const skin = SKINS[index];
  if (ownedSet(owned).has(skin.id)) return { ok: false, reason: "owned" };
  const missing = missingBefore(index, owned);
  if (missing) return { ok: false, reason: "sequence", missing };
  if (coins < skin.price) return { ok: false, reason: "funds", need: skin.price - coins };
  return { ok: true, skin };
}

/** "Character 3" — the number the UI quotes in lock messages. */
export function ordinalLabel(index: number): string {
  return `Character ${index + 1}`;
}
