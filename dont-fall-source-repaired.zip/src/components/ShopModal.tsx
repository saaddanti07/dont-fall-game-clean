import { useEffect, useRef, useState } from "react";
import { SECRET_SKIN, SKINS, missingBefore, nextBuyIndex, ordinalLabel, skinById, skinIndex } from "../game/skins";
import type { SaveData } from "../game/storage";
import { BannerInset } from "./BannerInset";
import { CoinCounter } from "./CoinCounter";
import { CheckIcon, CoinIcon, LockIcon } from "./Icons";
import { Modal } from "./Modal";
import { SkinPreview } from "./SkinPreview";

interface Props {
  save: SaveData;
  onBuy: (id: string) => void;
  onEquip: (id: string) => void;
  onClose: () => void;
}

type State = "equipped" | "owned" | "next" | "locked";

interface Part {
  tx: number;
  ty: number;
  dur: number;
  delay: number;
  size: number;
  color: string;
}

/** A "mystery" collection: everything after the next character is a dark silhouette until unlocked. */
export function ShopModal({ save, onBuy, onEquip, onClose }: Props) {
  const nextIdx = nextBuyIndex(save.owned);
  const ownedCount = SKINS.filter((s) => save.owned.includes(s.id)).length;
  const [sel, setSel] = useState(Math.max(0, nextIdx));
  const skin = skinById(SKINS[sel].id);
  const idx = skinIndex(skin.id);
  const owned = new Set(save.owned);
  const stateOf = (i: number): State => (save.equipped === SKINS[i].id ? "equipped" : owned.has(SKINS[i].id) ? "owned" : i === nextIdx ? "next" : "locked");
  const state = stateOf(idx);
  const price = skin.price;
  const afford = save.coins >= price;
  const blocker = missingBefore(idx, save.owned);
  // "far" = a locked character that is at least two slots ahead of the next one to buy
  const isFar = (i: number) => stateOf(i) === "locked" && nextIdx >= 0 && i - nextIdx >= 2;
  const statusText: Record<State, string> = { equipped: "Equipped", owned: "Owned", next: "Next in line", locked: "Locked" };

  // ---- unlock reveal (silhouette -> full art, particles, shine, ribbon) ----
  const [reveal, setReveal] = useState<{ id: string; parts: Part[] } | null>(null);
  const revealTimer = useRef<number | null>(null);
  useEffect(() => () => {
    if (revealTimer.current) window.clearTimeout(revealTimer.current);
  }, []);

  const triggerReveal = (id: string) => {
    const sk = skinById(id);
    const palette = ["#ffd62e", "#ffffff", sk.accent, "#ff9f1c"];
    const parts: Part[] = Array.from({ length: 26 }, (_, i) => {
      const ang = (i / 26) * Math.PI * 2 + Math.random() * 0.5;
      const dist = 55 + Math.random() * 75;
      return {
        tx: Math.cos(ang) * dist,
        ty: Math.sin(ang) * dist - 18,
        dur: 0.7 + Math.random() * 0.55,
        delay: Math.random() * 0.14,
        size: 5 + Math.random() * 8,
        color: palette[Math.floor(Math.random() * palette.length)],
      };
    });
    setReveal({ id, parts });
    if (revealTimer.current) window.clearTimeout(revealTimer.current);
    revealTimer.current = window.setTimeout(() => setReveal(null), 1600);
  };

  const onBuyClick = (id: string) => {
    onBuy(id);
    triggerReveal(id);
  };

  const tileState = (st: State) =>
    st === "equipped"
      ? "border-emerald-400/80 bg-[#1d4a46]"
      : st === "owned"
        ? "border-teal-300/60 bg-[#20364f]"
        : st === "next"
          ? "border-[#ffd62e] bg-[#5a2f9e]"
          : "border-white/12 bg-black/40";

  const revealing = reveal?.id === skin.id;

  return (
    <Modal title="Character Shop" onClose={onClose} tall noScroll>
      {/* preview + action */}
      <div className="shrink-0 border-b-2 border-white/10 px-3 pb-3 pt-2.5">
        <div className="mb-1.5 flex items-center justify-between gap-2">
          <CoinCounter value={save.coins} />
          <span className="flex items-center gap-1.5 text-[0.72rem] font-bold uppercase tracking-[0.12em] text-violet-100">
            Collection
            <span className="value-text text-[1rem] leading-none">
              {ownedCount}/{SKINS.length}
            </span>
          </span>
        </div>
        <div className="h-1.5 overflow-hidden rounded-full bg-black/50">
          <div className="h-full rounded-full bg-gradient-to-r from-[#ffd62e] to-[#ff9f1c] transition-[width] duration-300" style={{ width: `${(ownedCount / SKINS.length) * 100}%` }} />
        </div>

        <div className="relative mx-auto mt-1 h-[min(22dvh,160px)] w-full max-w-[200px]">
          {/* base art: full for the next/owned, silhouette for locked */}
          <SkinPreview skin={skin} animated scene silhouette={state === "locked" && !revealing} />
          <span className="absolute left-1 top-0 rounded-lg border-2 border-[#1b0a3d] bg-[#ffd62e] px-1.5 py-0.5 font-display text-[0.8rem] leading-tight text-[#3b1a00]" data-slot="order">
            #{idx + 1}
          </span>
          {/* the mystery mark on a far, still-locked selection */}
          {state === "locked" && isFar(idx) && (
            <span className="qmark absolute inset-0 flex items-center justify-center text-5xl" aria-hidden="true">
              ?
            </span>
          )}
          {/* unlock reveal: the silhouette fades away to show the full artwork */}
          {revealing && (
            <div className="pointer-events-none absolute inset-0" data-testid="reveal">
              <SkinPreview skin={skin} animated silhouette className="silhouette-fade absolute inset-0 h-full w-full" />
              <div className="reveal-shine" />
              <span className="reveal-ring" />
              {reveal!.parts.map((pt, i) => (
                <span
                  key={i}
                  className="burst-dot"
                  style={{ width: pt.size, height: pt.size, background: pt.color, ["--tx" as string]: `${pt.tx}px`, ["--ty" as string]: `${pt.ty}px`, ["--dur" as string]: `${pt.dur}s`, ["--delay" as string]: `${pt.delay}s` }}
                />
              ))}
              <span className="reveal-ribbon" data-testid="ribbon">
                ★ {skin.name.toUpperCase()} UNLOCKED ★
              </span>
            </div>
          )}
        </div>
        <div className="mt-1 text-center">
          <div className="font-display text-[1.45rem] leading-none tracking-wide text-white text-outline" data-testid="skin-name">
            {skin.name}
          </div>
          <div className="mt-1.5 text-[0.88rem] font-medium text-violet-100">{state === "locked" && isFar(idx) ? "A mystery still… unlock the characters ahead of it to reveal." : skin.blurb}</div>
        </div>

        {/* status + price */}
        <div className="mt-2 flex items-center justify-between gap-2">
          <span
            className={`rounded-full border-2 px-3 py-1 text-[0.72rem] font-bold uppercase tracking-[0.14em] ${
              state === "equipped"
                ? "border-emerald-300 bg-emerald-500/30 text-emerald-100"
                : state === "owned"
                  ? "border-teal-300 bg-teal-500/25 text-teal-100"
                  : state === "next"
                    ? "border-[#5a2f00] bg-[#ffd62e] text-[#3b1a00]"
                    : "border-white/25 bg-black/40 text-violet-100"
            }`}
            data-testid="skin-state"
          >
            {statusText[state]}
          </span>
          <span className={`flex items-center gap-1.5 font-display text-[1.15rem] leading-none ${owned.has(skin.id) ? "text-emerald-300" : "text-white"}`} data-testid="price">
            {owned.has(skin.id) ? "Owned" : <>{price.toLocaleString()} <CoinIcon className="h-6 w-6" /></>}
          </span>
        </div>

        {/* Purchase progress for the next character in the sequence */}
        {state === "next" && (
          <div className="mt-2 rounded-2xl bg-black/35 p-2.5" data-testid="purchase-progress">
            <div className="flex items-center justify-between text-[0.78rem] font-semibold text-violet-100">
              <span>
                Price <b className="text-white">{price.toLocaleString()}</b>
              </span>
              <span>
                Balance <b className="text-white">{save.coins.toLocaleString()}</b>
              </span>
            </div>
            <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-black/50">
              <div
                className="h-full rounded-full transition-[width] duration-300"
                style={{
                  width: `${Math.min(100, (save.coins / price) * 100)}%`,
                  background: afford ? "linear-gradient(90deg,#a6ff72,#3fdc50)" : "linear-gradient(90deg,#ffd62e,#ff9f1c)",
                }}
              />
            </div>
            <div className="mt-1 flex items-center justify-between text-[0.74rem] font-bold">
              <span className="text-violet-100">{afford ? "Ready to buy!" : `Remaining: ${(price - save.coins).toLocaleString()} coins`}</span>
              <span className="tabular-nums text-white">{Math.min(100, Math.round((save.coins / price) * 100))}%</span>
            </div>
          </div>
        )}

        <div className="mt-2.5">
          {state === "equipped" ? (
            <button className="btn btn-muted w-full gap-2 text-[1.2rem]" style={{ minHeight: 54 }} disabled>
              <CheckIcon /> EQUIPPED
            </button>
          ) : state === "owned" ? (
            <button className="btn btn-play w-full text-[1.4rem]" style={{ minHeight: 56, animation: "none" }} onClick={() => onEquip(skin.id)} data-slot="select">
              SELECT
            </button>
          ) : state === "next" && afford ? (
            <button className="btn btn-gold w-full gap-2 text-[1.3rem]" style={{ minHeight: 56 }} onClick={() => onBuyClick(skin.id)} data-slot="buy">
              BUY <CoinIcon className="h-7 w-7" /> {price.toLocaleString()}
            </button>
          ) : state === "next" ? (
            <button className="btn btn-muted w-full flex-col gap-0 text-[1.05rem] leading-tight" style={{ minHeight: 56 }} disabled data-slot="buy">
              <span className="flex items-center gap-1.5">
                <CoinIcon className="h-5 w-5" /> {price.toLocaleString()}
              </span>
              <span className="font-body text-[0.78rem] font-semibold tracking-normal text-violet-200">Need {(price - save.coins).toLocaleString()} more coins</span>
            </button>
          ) : (
            <button className="btn btn-muted w-full flex-col gap-0.5 text-[1rem] leading-tight" style={{ minHeight: 56 }} disabled data-slot="locked-note">
              <span className="flex items-center gap-1.5 font-display tracking-wide text-[#ffd62e]" data-testid="lock-msg">
                <LockIcon className="h-4 w-4" /> Purchase {blocker ? ordinalLabel(skinIndex(blocker.id)) : "the previous character"} first.
              </span>
              <span className="font-body text-[0.78rem] font-semibold tracking-normal text-violet-200">
                {blocker ? (isFar(idx) ? `Character ${skinIndex(blocker.id) + 1} of ${SKINS.length}` : `${blocker.name} — ${ordinalLabel(skinIndex(blocker.id))} of ${SKINS.length}`) : ""}
              </span>
            </button>
          )}
        </div>
      </div>

      {/* character grid — in purchase order */}
      <div className="scroll-thin min-h-0 flex-1 overflow-y-auto p-3">
        <p className="mb-2 text-center text-[0.76rem] font-semibold leading-snug text-violet-100">
          Unlock in order. Each one reveals the next mystery — coins alone can’t skip ahead.
        </p>
        <div className="grid grid-cols-3 gap-2.5">
          {SKINS.map((s, i) => {
            const st = stateOf(i);
            const blocked = st === "locked" ? missingBefore(i, save.owned) : null;
            const far = isFar(i);
            const justBought = reveal?.id === s.id;
            return (
              <button
                key={s.id}
                onClick={() => setSel(i)}
                aria-pressed={sel === i}
                aria-label={`${s.name}, character ${i + 1}, ${st === "equipped" ? "equipped" : st === "owned" ? "owned" : st === "next" ? "available to buy" : `locked mystery, purchase ${ordinalLabel(skinIndex(blocked!.id)).toLowerCase()} first`}`}
                data-skin={s.id}
                data-state={st}
                data-far={far ? "true" : "false"}
                className={`relative flex flex-col items-center rounded-2xl border-[3px] px-1 pb-1.5 pt-1 transition-colors ${tileState(st)} ${sel === i ? "outline-2 outline-white/70 outline-offset-2" : ""} ${justBought ? "tile-pop" : ""}`}
              >
                <span className="absolute left-1 top-1 z-10 rounded-md border-2 border-[#1b0a3d] bg-black/60 px-1 font-display text-[0.66rem] leading-tight text-white">{i + 1}</span>
                {st !== "equipped" && st !== "owned" && (
                  <span className={`absolute right-1 top-1 z-10 flex h-5 w-5 items-center justify-center rounded-full ${st === "next" ? "bg-[#ffd62e] text-[#3b1a00]" : "bg-black/70 text-violet-200"}`}>
                    {st === "next" ? <CoinIcon className="h-3.5 w-3.5" /> : <LockIcon className="h-3 w-3" />}
                  </span>
                )}
                {st === "next" && <span className="pointer-events-none absolute inset-0 z-10 rounded-xl" style={{ animation: "herePulse 2.2s ease-in-out infinite" }} aria-hidden="true" />}
                <div className={`relative h-[62px] w-[62px] ${st === "locked" ? "" : ""}`}>
                  <SkinPreview skin={s} silhouette={st === "locked"} />
                  {st === "locked" && far && (
                    <span className="qmark absolute inset-0 flex items-center justify-center text-3xl" aria-hidden="true">
                      ?
                    </span>
                  )}
                </div>
                <span className={`w-full truncate text-center text-[0.72rem] font-bold leading-tight ${st === "locked" ? "text-violet-200" : "text-white"}`}>
                  {st === "locked" && far ? "? ? ?" : s.name}
                </span>
                <span className="mt-0.5 flex items-center gap-1 text-[0.66rem] font-bold uppercase leading-none tracking-wide">
                  {st === "equipped" ? (
                    <span className="flex items-center gap-0.5 text-emerald-200">
                      <CheckIcon className="h-3 w-3" /> Equipped
                    </span>
                  ) : st === "owned" ? (
                    <span className="text-teal-200">Owned</span>
                  ) : st === "next" ? (
                    <span className="flex items-center gap-1 text-[#ffd62e]">
                      <CoinIcon className="h-3.5 w-3.5" />
                      {s.price.toLocaleString()}
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-violet-300">
                      <LockIcon className="h-3 w-3" />#{blocked ? skinIndex(blocked.id) + 1 : "?"}
                    </span>
                  )}
                </span>
              </button>
            );
          })}
        </div>
        <div className={`mt-3 flex items-center gap-3 rounded-2xl border-2 p-2.5 ${save.owned.includes(SECRET_SKIN.id) ? "border-[#ffd166] bg-[#3c1a35]" : "border-white/15 bg-black/30"}`} data-secret-skin>
          <div className="relative h-[76px] w-[76px] shrink-0">
            <SkinPreview skin={SECRET_SKIN} silhouette={!save.owned.includes(SECRET_SKIN.id)} />
            {!save.owned.includes(SECRET_SKIN.id) && <span className="qmark absolute inset-0 flex items-center justify-center text-3xl">?</span>}
          </div>
          <div className="min-w-0 flex-1">
            <div className="panel-label">Secret reward</div>
            <div className="mt-1 font-display text-[1.15rem] leading-none text-white">{save.owned.includes(SECRET_SKIN.id) ? SECRET_SKIN.name : "? ? ?"}</div>
            <div className="mt-1 text-[0.75rem] font-semibold text-violet-100">{save.owned.includes(SECRET_SKIN.id) ? "Dragon defeated — unlocked forever" : "Defeat the Dragon in stage 20"}</div>
          </div>
          {save.owned.includes(SECRET_SKIN.id) && (
            save.equipped === SECRET_SKIN.id ? (
              <span className="rounded-full border-2 border-emerald-300 px-2 py-1 text-[0.65rem] font-bold uppercase text-emerald-200">Equipped</span>
            ) : (
              <button className="btn btn-play btn-sm shrink-0 px-2.5 text-[0.8rem]" onClick={() => onEquip(SECRET_SKIN.id)}>SELECT</button>
            )
          )}
        </div>
        <BannerInset />
        {nextIdx === -1 && (
          <div className="mt-3 flex items-center justify-center gap-2 rounded-2xl border-2 border-[#ffd62e]/70 bg-[#4a3a1c] px-3 py-2.5 text-center">
            <CheckIcon className="h-5 w-5 text-[#ffd62e]" />
            <span className="font-display text-[1.05rem] leading-none text-white">COMPLETE — all {SKINS.length} characters owned</span>
          </div>
        )}
      </div>
    </Modal>
  );
}
