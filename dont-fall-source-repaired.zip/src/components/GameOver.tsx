import type { Completed } from "../game/progression";
import { CheckIcon, CoinIcon, HomeIcon, RestartIcon, TrophyIcon } from "./Icons";
import { StackedTitle } from "./StackedTitle";

export interface GameOverResult {
  distance: number;
  score: number;
  bonus: number;
  coins: number;
  best: number;
  newBest: boolean;
  completed: Completed[];
}

interface Props {
  result: GameOverResult;
  onRestart: () => void;
  onMenu: () => void;
  /** Optional rewarded ads (null when unavailable — the buttons then stay disabled). */
  onRevive?: () => void;
  onDoubleCoins?: () => void;
  reviveUsed?: boolean;
  doubled?: boolean;
  reviveBusy?: boolean;
  doubleBusy?: boolean;
}

export function GameOver({ result: r, onRestart, onMenu, onRevive, onDoubleCoins, reviveUsed, doubled, reviveBusy, doubleBusy }: Props) {
  const missions = r.completed.filter((c) => c.kind !== "achievement");
  const awards = r.completed.filter((c) => c.kind === "achievement");
  return (
    <div
      className="fade-in absolute inset-0 z-20 flex flex-col overflow-y-auto px-5"
      style={{
        background: "radial-gradient(ellipse at 50% 40%, rgba(60,20,110,0.88), rgba(10,3,22,0.94))",
        paddingTop: "max(16px, env(safe-area-inset-top))",
        paddingBottom: "max(16px, env(safe-area-inset-bottom))",
      }}
    >
      <div className="m-auto flex w-full max-w-[340px] flex-col items-center gap-[min(2dvh,16px)]">
        <StackedTitle lines={["GAME", "OVER!"]} label="Game Over" small />

        <div className="pop-in panel flex w-full flex-col items-center gap-2.5 rounded-3xl px-3.5 py-3">
          <div className="flex flex-col items-center gap-1.5">
            <span className="panel-label">Final distance</span>
            <span className="value-text text-[clamp(2.6rem,14vw,3.8rem)] leading-none tabular-nums" data-testid="final-distance">
              {r.distance.toLocaleString()}
              <span className="ml-1 font-body text-[1rem] font-semibold tracking-normal text-violet-100">m</span>
            </span>
            {r.newBest && (
              <span className="rounded-full border-2 border-[#5a2f00] bg-gradient-to-b from-[#fff29a] to-[#ffb300] px-3 py-0.5 text-xs font-bold uppercase tracking-wider text-[#3b1a00]">★ New best! ★</span>
            )}
            {r.bonus > 0 && <span className="text-[0.82rem] font-semibold text-violet-100">Score {r.score.toLocaleString()} (near-miss bonus +{r.bonus})</span>}
          </div>

          <div className="grid w-full grid-cols-2 gap-2">
            <div className="flex flex-col items-center gap-1.5 rounded-2xl bg-black/30 py-2">
              <span className="panel-label flex items-center gap-1.5">
                <TrophyIcon className="h-4 w-4" /> Best
              </span>
              <span className="value-text text-[1.35rem] leading-none tabular-nums">{r.best.toLocaleString()} m</span>
            </div>
            <div className="flex flex-col items-center gap-1.5 rounded-2xl bg-black/30 py-2">
              <span className="panel-label flex items-center gap-1.5">
                <CoinIcon className="h-4 w-4" /> Coins
              </span>
              <span className="value-text text-[1.35rem] leading-none tabular-nums">+{r.coins}</span>
            </div>
          </div>

          <div className="w-full rounded-2xl bg-black/30 px-3 py-2" data-testid="completed-missions">
            <div className="panel-label mb-1.5">Missions completed</div>
            {r.completed.length === 0 ? (
              <div className="text-[0.85rem] font-medium text-violet-200">None this run — keep climbing!</div>
            ) : (
              <ul className="flex flex-col gap-1">
                {[...missions, ...awards].slice(0, 4).map((c, i) => (
                  <li key={i} className="flex items-center justify-between gap-2 text-[0.88rem] font-semibold text-white">
                    <span className="flex min-w-0 items-center gap-1.5">
                      <span className="flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-emerald-400 text-[#06361b]">
                        <CheckIcon className="h-3 w-3" />
                      </span>
                      <span className="truncate">{c.kind === "achievement" ? `★ ${c.title}` : c.title}</span>
                    </span>
                    <span className="flex shrink-0 items-center gap-0.5 font-display text-[#ffd62e]">
                      +{c.reward}
                      <CoinIcon className="h-4 w-4" />
                    </span>
                  </li>
                ))}
                {r.completed.length > 4 && <li className="text-[0.8rem] text-violet-200">+{r.completed.length - 4} more</li>}
              </ul>
            )}
          </div>
        </div>

        <div className="pop-in flex w-full flex-col gap-3">
          {onRevive && (
            <button
              className="btn btn-blue min-h-[58px] gap-2 text-[1.15rem]"
              onClick={onRevive}
              disabled={reviveUsed || reviveBusy}
              data-testid="revive-button"
            >
              {reviveUsed ? "REVIVE USED" : reviveBusy ? "LOADING AD…" : "WATCH AD TO REVIVE"}
            </button>
          )}
          {onDoubleCoins && r.coins > 0 && (
            <button
              className="btn btn-gold min-h-[56px] gap-2 text-[1.1rem]"
              onClick={onDoubleCoins}
              disabled={doubled || doubleBusy}
              data-testid="double-coins-button"
            >
              {doubled ? `DOUBLED! +${r.coins}` : doubleBusy ? "LOADING AD…" : `WATCH AD TO DOUBLE COINS (+${r.coins})`}
            </button>
          )}
          <button className="btn btn-play min-h-[64px] gap-2.5 text-[1.8rem]" onClick={onRestart}>
            <RestartIcon className="h-7 w-7" /> RETRY
          </button>
          <button className="btn btn-purple min-h-[54px] gap-2 text-[1.2rem]" onClick={onMenu}>
            <HomeIcon className="h-6 w-6" /> MAIN MENU
          </button>
        </div>
      </div>
    </div>
  );
}
