import { useCallback, useEffect, useRef } from "react";
import { CaveBackground } from "./CaveBackground";
import { MenuCharacter } from "./MenuCharacter";
import { StackedTitle } from "./StackedTitle";
import { audio } from "../game/audio";
import { ORIGINAL } from "../game/skins";

const HOLD_MS = 3450; // full splash hold before the exit fade begins
const EXIT_MS = 350; // smooth crossfade into the main menu (~3.8s total)

/**
 * Recurring cinematic opening screen.
 * Shown on EVERY fresh app launch (initial mount only) — never when returning
 * from gameplay to the menu, since App never re-arms it.
 *
 * Reuses only original artwork: CaveBackground (purple cave), MenuCharacter with
 * the ORIGINAL yellow-hat adventurer, and the StackedTitle DON'T FALL logo.
 * Sequence: fade from black → cave reveal → hero entrance → title pop → tagline
 * → hold → crossfade to menu. Tap anywhere to skip.
 */
export function SplashScreen({ onDone }: { onDone: () => void }) {
  const doneRef = useRef(onDone);
  doneRef.current = onDone;
  const leavingRef = useRef<HTMLDivElement>(null);
  const finished = useRef(false);

  const finish = useCallback(() => {
    if (finished.current) return;
    finished.current = true;
    // A tap is a user gesture: unlock audio the same way menu buttons do.
    audio.unlock();
    const el = leavingRef.current;
    if (el) el.style.opacity = "0";
    window.setTimeout(() => doneRef.current(), EXIT_MS);
  }, []);

  useEffect(() => {
    const t = window.setTimeout(finish, HOLD_MS);
    return () => window.clearTimeout(t);
  }, [finish]);

  return (
    <div
      ref={leavingRef}
      className="relative h-full w-full cursor-pointer overflow-hidden bg-black"
      style={{ transition: `opacity ${EXIT_MS}ms ease` }}
      onPointerDown={finish}
      role="button"
      aria-label="Skip intro, go to main menu"
      data-testid="splash-screen"
    >
      {/* 1 — purple cave reveal */}
      <div className="splash-bg absolute inset-0">
        <CaveBackground />
      </div>

      {/* cinematic spotlight behind the hero */}
      <div className="splash-spot pointer-events-none absolute inset-0" aria-hidden="true" />
      {/* vignette for depth */}
      <div
        className="pointer-events-none absolute inset-0"
        aria-hidden="true"
        style={{ background: "radial-gradient(ellipse at 50% 45%, transparent 45%, rgba(5,1,12,0.55) 100%)" }}
      />

      <div
        className="relative z-10 flex h-full flex-col items-center justify-center px-6"
        style={{
          paddingTop: "max(20px, env(safe-area-inset-top))",
          paddingBottom: "max(20px, env(safe-area-inset-bottom))",
        }}
      >
        {/* 2 — hero entrance (original yellow-hat adventurer) */}
        <div className="splash-hero relative h-[min(38dvh,300px)] w-full max-w-[300px]">
          <MenuCharacter skin={ORIGINAL} />
        </div>

        {/* 3 — title reveal */}
        <div className="splash-title mt-1">
          <StackedTitle lines={["DON'T", "FALL!"]} label="DON'T FALL!" />
        </div>

        {/* 4 — tagline + loading shimmer */}
        <p className="splash-tag text-outline mt-3 text-center text-[clamp(0.95rem,4.2vw,1.15rem)] font-semibold text-white">
          Climb. Bounce. Outrun the lava!
        </p>
        <div className="splash-bar mt-5 h-1.5 w-44 overflow-hidden rounded-full bg-white/15" aria-hidden="true">
          <div className="splash-bar-fill h-full w-full rounded-full" />
        </div>
        <p className="splash-tap mt-4 text-[0.72rem] font-bold uppercase tracking-[0.22em] text-violet-200">
          Tap to continue
        </p>
      </div>

      {/* 0 — fade in from black (starts opaque, fades away) */}
      <div className="splash-black pointer-events-none absolute inset-0 bg-black" aria-hidden="true" />
    </div>
  );
}
