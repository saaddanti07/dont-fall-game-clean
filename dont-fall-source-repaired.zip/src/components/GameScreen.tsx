import { useCallback, useEffect, useRef, useState } from "react";
import { Game, type GameOptions, type HudState, type WorldEvent } from "../game/engine";
import { audio } from "../game/audio";
import type { RunStats } from "../game/progression";
import type { Skin } from "../game/skins";
import { AbilityButton } from "./AbilityButton";
import { CoinCounter } from "./CoinCounter";
import { FlameIcon, HomeIcon, PauseIcon, PlayIcon } from "./Icons";
import { PowerChips } from "./PowerChips";
import { StackedTitle } from "./StackedTitle";
import { WorldBanner } from "./WorldBanner";

interface Props {
  gameRef?: React.RefObject<Game | null>;
  skin: Skin;
  /** Owned + equipped ability id for the equipped character (null when none). */
  ability?: string | null;
  debug?: GameOptions | null;
  /** Legitimate fast-start: begin the run at this altitude (World select). */
  startMeters?: number;
  onCoin: (amount: number) => void;
  onGameOver: (r: RunStats) => void;
  onVictory: (r: RunStats & { fightTime: number }) => void;
  onExit: (r: RunStats) => void;
  onRevive?: () => void;
}

const EMPTY_HUD: HudState = { score: 0, distance: 0, bonus: 0, coins: 0, powers: [], boss: -1, dragon: null, ability: null };

export function GameScreen({ gameRef: gameRefProp, skin, debug, startMeters = 0, ability, onCoin, onGameOver, onVictory, onExit, onRevive }: Props) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const internalGameRef = useRef<Game | null>(null);
  const gameRef = gameRefProp ?? internalGameRef;
  const cbs = useRef({ onCoin, onGameOver, onVictory, onRevive });
  cbs.current = { onCoin, onGameOver, onVictory, onRevive };

  const [hud, setHud] = useState<HudState>(EMPTY_HUD);
  const [world, setWorld] = useState<WorldEvent | null>(null);
  const [worldName, setWorldName] = useState("CAVE");
  const [paused, setPaused] = useState(false);
  const pausedRef = useRef(false);

  const setPause = useCallback((p: boolean) => {
    pausedRef.current = p;
    setPaused(p);
    gameRef.current?.setPaused(p);
    if (p) gameRef.current?.setInput(0);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current!;
    const wrap = wrapRef.current!;
    const game = new Game(
      canvas,
      skin,
      {
        onHud: setHud,
        onCoin: (n) => cbs.current.onCoin(n),
        onWorld: (w) => {
          setWorld(w);
          setWorldName(w.name);
        },
        onGameOver: (r) => cbs.current.onGameOver(r),
        onVictory: (r) => cbs.current.onVictory(r),
        onRevive: () => cbs.current.onRevive?.(),
      },
      { ...(debug ?? {}), startMeters, ability },
    );
    gameRef.current = game;
    if (debug) (window as unknown as { __game?: Game }).__game = game;

    const fit = () => {
      const r = wrap.getBoundingClientRect();
      game.resize(r.width, r.height, Math.min(window.devicePixelRatio || 1, 2.5));
    };
    fit();
    const ro = new ResizeObserver(fit);
    ro.observe(wrap);
    game.start();

    // keyboard controls
    const keys = new Set<string>();
    const sync = () => {
      const left = keys.has("ArrowLeft") || keys.has("a") || keys.has("A");
      const right = keys.has("ArrowRight") || keys.has("d") || keys.has("D");
      game.setInput(left === right ? 0 : left ? -1 : 1);
    };
    const down = (e: KeyboardEvent) => {
      if (e.key === "Escape" || e.key === "p") setPause(!pausedRef.current);
      keys.add(e.key);
      sync();
    };
    const up = (e: KeyboardEvent) => {
      keys.delete(e.key);
      sync();
    };
    // pause automatically whenever the page is hidden or loses focus
    const vis = () => {
      if (document.hidden) setPause(true);
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    document.addEventListener("visibilitychange", vis);
    window.addEventListener("blur", vis);

    return () => {
      game.destroy();
      ro.disconnect();
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
      document.removeEventListener("visibilitychange", vis);
      window.removeEventListener("blur", vis);
      gameRef.current = null;
    };
    // the engine is created once per run (a new run mounts a fresh component via `key`)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [setPause, startMeters]);

  // touch / mouse: hold left or right half of the screen
  const steer = (e: React.PointerEvent) => {
    if (pausedRef.current) return;
    const r = wrapRef.current!.getBoundingClientRect();
    gameRef.current?.setInput(e.clientX < r.left + r.width / 2 ? -1 : 1);
  };

  return (
    <div className="relative h-full w-full">
      <div
        ref={wrapRef}
        className="absolute inset-0 touch-none"
        onPointerDown={(e) => {
          audio.unlock();
          (e.target as Element).setPointerCapture?.(e.pointerId);
          steer(e);
        }}
        onPointerMove={(e) => (e.buttons > 0 || e.pointerType === "touch" ? steer(e) : undefined)}
        onPointerUp={() => gameRef.current?.setInput(0)}
        onPointerCancel={() => gameRef.current?.setInput(0)}
        onContextMenu={(e) => e.preventDefault()}
      >
        <canvas ref={canvasRef} className="block h-full w-full" />
      </div>

      {/* HUD — dark translucent panels, kept to the top of the screen */}
      <div
        className="pointer-events-none absolute inset-x-0 top-0 z-10 px-3"
        style={{ paddingTop: "max(12px, calc(env(safe-area-inset-top) + 6px))" }}
      >
        <div className="flex items-start justify-between gap-2">
          <div className="panel flex min-w-[104px] flex-col items-start gap-1 rounded-2xl px-3.5 py-2" role="status" aria-label={`Score ${hud.score}, distance ${hud.distance} meters`}>
            <span className="panel-label">Score</span>
            <span className="value-text text-[1.7rem] leading-none tabular-nums" data-testid="hud-score">{hud.score.toLocaleString()}</span>
            <span className="text-[0.78rem] font-bold leading-none tracking-wide text-violet-100" data-testid="hud-distance">
              {hud.distance.toLocaleString()} m · {worldName}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <CoinCounter value={hud.coins} prefix="+" label="Coins this run" />
            <button className="icon-btn neutral pointer-events-auto" onClick={() => setPause(true)} aria-label="Pause game">
              <PauseIcon />
            </button>
          </div>
        </div>
        <PowerChips powers={hud.powers} />
        {hud.dragon && (
          <div className="panel mt-2 rounded-2xl border-[#ff7043]/70 px-3 py-2" data-testid="dragon-bar">
            <div className="flex items-center justify-between gap-2">
              <span className="panel-label flex items-center gap-1.5" style={{ color: "#ffb347" }}>
                <FlameIcon className="h-4 w-4" /> Dragon · Phase {hud.dragon.phase}
              </span>
              <span className="value-text text-[0.95rem] leading-none tabular-nums">{Math.ceil(hud.dragon.hp)} / {hud.dragon.maxHp}</span>
            </div>
            <div className="mt-1.5 h-3 overflow-hidden rounded-full bg-black/60">
              <div className="h-full rounded-full bg-gradient-to-r from-[#ff3d2e] via-[#ff9f1c] to-[#ffd166] transition-[width] duration-200" style={{ width: `${(hud.dragon.hp / hud.dragon.maxHp) * 100}%` }} />
            </div>
            <div className="mt-1 text-[0.68rem] font-semibold text-violet-100">Stomp its head or collect fire runes to damage it.</div>
          </div>
        )}
        {hud.ability && !paused && hud.score >= 0 && (
          <AbilityButton ability={hud.ability} onTrigger={() => gameRef.current?.triggerAbility()} />
        )}

        {hud.boss >= 0 && (
          <div className="panel mt-2 rounded-2xl px-3 py-2" data-testid="boss-bar">
            <div className="flex items-center justify-between gap-2">
              <span className="panel-label flex items-center gap-1.5" style={{ color: "#ff8a6a" }}>
                <FlameIcon className="h-4 w-4" /> The Warden
              </span>
              <span className="value-text text-[0.95rem] leading-none tabular-nums">{Math.round(hud.boss * 100)}%</span>
            </div>
            <div className="mt-1.5 h-2.5 overflow-hidden rounded-full bg-black/60">
              <div className="h-full rounded-full bg-gradient-to-r from-[#ff6a4d] via-[#ffd23f] to-[#7dffb0] transition-[width] duration-200" style={{ width: `${hud.boss * 100}%` }} />
            </div>
          </div>
        )}
      </div>

      {world && !paused && <WorldBanner world={world} lower={!!hud.dragon} />}

      {/* control hint */}
      {!paused && hud.distance < 5 && !debug && !startMeters && (
        <div className="pointer-events-none absolute inset-x-0 z-10 flex justify-center px-6" style={{ top: "30%", animation: "hintFade 5s ease forwards" }}>
          <div className="panel px-4 py-2.5 text-center text-[0.95rem] font-semibold leading-snug text-white">
            Hold the <b className="text-[#ffd62e]">left</b> or <b className="text-[#ffd62e]">right</b> side of the screen to move
          </div>
        </div>
      )}

      {paused && (
        <div className="fade-in absolute inset-0 z-20 flex flex-col items-center justify-center gap-6 px-8" style={{ background: "rgba(10,3,22,0.82)" }} role="dialog" aria-label="Paused">
          <StackedTitle lines={["PAUSED"]} />
          <div className="pop-in flex w-full max-w-[300px] flex-col gap-3.5">
            <button
              className="btn btn-play min-h-[68px] gap-2 text-[1.7rem]"
              onClick={() => {
                audio.sfx("click");
                setPause(false);
              }}
            >
              <PlayIcon className="h-7 w-7" /> RESUME
            </button>
            <button
              className="btn btn-purple min-h-[56px] gap-2 text-[1.2rem]"
              onClick={() => {
                audio.sfx("click");
                onExit(gameRef.current!.getRunStats());
              }}
            >
              <HomeIcon className="h-6 w-6" /> MAIN MENU
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
