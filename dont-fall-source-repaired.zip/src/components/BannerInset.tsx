import { useCallback, useEffect, useRef, useState } from "react";
import { ads } from "../game/ads";

/**
 * Reserves space at the bottom of an allowed screen (Main Menu, Character Shop,
 * Ability Shop) while the native banner is visible.
 * Uses reference-counted subscription in `ads` so opening/closing shop modals over
 * the Main Menu never drops the banner prematurely, and unmounting all allowed
 * screens (entering gameplay) removes the banner immediately.
 */
export function BannerInset() {
  const [height, setHeight] = useState(() => ads.getBannerHeight());
  const raf = useRef(0);

  const apply = useCallback((px: number) => {
    cancelAnimationFrame(raf.current);
    raf.current = requestAnimationFrame(() => setHeight(Math.round(px)));
  }, []);

  useEffect(() => {
    const unsubscribe = ads.subscribeBanner(apply);
    return () => {
      cancelAnimationFrame(raf.current);
      unsubscribe();
    };
  }, [apply]);

  if (height <= 0) return null;
  return <div aria-hidden="true" style={{ height: `${height}px`, flexShrink: 0 }} data-testid="banner-inset" />;
}
