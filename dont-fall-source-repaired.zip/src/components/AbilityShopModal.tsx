import { useState } from "react";
import { ABILITIES, abilityById } from "../game/abilities";
import { skinById } from "../game/skins";
import type { SaveData } from "../game/storage";
import { BannerInset } from "./BannerInset";
import { CoinCounter } from "./CoinCounter";
import { CheckIcon, CoinIcon, LockIcon } from "./Icons";
import { Modal } from "./Modal";
import { SkinPreview } from "./SkinPreview";

interface Props {
  save: SaveData;
  onBuy: (id: string) => void;
  onEquip: (characterId: string, abilityId: string | null) => void;
  onClose: () => void;
}

type RowState = "purchased" | "equipped" | "available" | "locked";

/** ABILITY SHOP — completely separate from the CHARACTER SHOP. */
export function AbilityShopModal({ save, onBuy, onEquip, onClose }: Props) {
  const [sel, setSel] = useState(save.equipped);
  const ability = abilityById(ABILITIES.find((a) => a.character === sel)?.id ?? "") ?? ABILITIES[0];
  const ownedSet = new Set(save.abilities?.owned ?? []);
  const equippedMap = save.abilities?.equipped ?? {};

  const stateOf = (id: string): RowState => {
    const def = abilityById(id)!;
    if (equippedMap[def.character] === id && save.owned.includes(def.character)) return "equipped";
    if (ownedSet.has(id)) return "purchased";
    if (!save.owned.includes(def.character)) return "locked";
    return "available";
  };

  const state = stateOf(ability.id);
  const afford = save.coins >= ability.price;
  const ownedCharacter = save.owned.includes(ability.character);
  const char = skinById(ability.character);

  const rowTone = (st: RowState) =>
    st === "equipped"
      ? "border-emerald-400/80 bg-[#1d4a46]"
      : st === "purchased"
        ? "border-teal-300/60 bg-[#20364f]"
        : st === "available"
          ? "border-[#ffd62e] bg-[#5a2f9e]"
          : "border-white/12 bg-black/40";

  return (
    <Modal title="Ability Shop" onClose={onClose} tall noScroll>
      <div className="shrink-0 border-b-2 border-white/10 px-3 pb-3 pt-2.5">
        <div className="mb-1.5 flex items-center justify-between gap-2">
          <CoinCounter value={save.coins} />
          <span className="flex items-center gap-1.5 text-[0.72rem] font-bold uppercase tracking-[0.12em] text-violet-100">
            Abilities
            <span className="value-text text-[1rem] leading-none">
              {(save.abilities?.owned ?? []).length}/{ABILITIES.length}
            </span>
          </span>
        </div>
        <div className="h-1.5 overflow-hidden rounded-full bg-black/50">
          <div className="h-full rounded-full bg-gradient-to-r from-[#7fd0ff] to-[#5a8bff] transition-[width] duration-300" style={{ width: `${((save.abilities?.owned ?? []).length / ABILITIES.length) * 100}%` }} />
        </div>

        {/* selected ability */}
        <div className="mt-2 flex items-center gap-3 rounded-2xl border-2 border-white/12 bg-black/30 p-2.5">
          <div className={`relative h-[74px] w-[74px] shrink-0 ${ownedCharacter ? "" : "opacity-50 saturate-50"}`}>
            <SkinPreview skin={char} />
            {!ownedCharacter && (
              <span className="absolute -bottom-1 -right-1 flex h-6 w-6 items-center justify-center rounded-full border-2 border-[#1b0a3d] bg-black/80 text-violet-200">
                <LockIcon className="h-3.5 w-3.5" />
              </span>
            )}
          </div>
          <div className="min-w-0 flex-1">
            <div className="panel-label">{char.name}</div>
            <div className="mt-1 font-display text-[1.2rem] leading-none tracking-wide text-white text-outline">{ability.name}</div>
            <div className="mt-1.5 text-[0.8rem] font-medium leading-snug text-violet-100">{ability.desc}</div>
            <div className="mt-1.5 flex items-center gap-3 text-[0.72rem] font-bold uppercase tracking-wide text-violet-200">
              <span>{ability.cooldown > 0 ? `Cooldown ${ability.cooldown}s` : `${ability.charges} charges`}</span>
              {ability.duration > 0 && <span>{ability.duration}s effect</span>}
            </div>
          </div>
        </div>

        {/* status + purchase / equip controls */}
        <div className="mt-2">
          {state === "equipped" ? (
            <div className="flex gap-2">
              <span className="btn btn-muted flex-1 gap-2 text-[1.05rem]" style={{ minHeight: 52 }}>
                <CheckIcon /> EQUIPPED
              </span>
              <button className="btn btn-purple px-4 text-[1rem]" style={{ minHeight: 52 }} onClick={() => onEquip(ability.character, null)}>
                TURN OFF
              </button>
            </div>
          ) : state === "purchased" ? (
            <button className="btn btn-play w-full text-[1.3rem]" style={{ minHeight: 52, animation: "none" }} onClick={() => onEquip(ability.character, ability.id)}>
              EQUIP FOR {char.name.toUpperCase()}
            </button>
          ) : !ownedCharacter ? (
            <button className="btn btn-muted w-full flex-col gap-0.5 text-[1rem] leading-tight" style={{ minHeight: 56 }} disabled data-testid="ability-lock">
              <span className="flex items-center gap-1.5 font-display tracking-wide text-[#ffd62e]">
                <LockIcon className="h-4 w-4" /> Character required.
              </span>
              <span className="font-body text-[0.78rem] font-semibold tracking-normal text-violet-200">
                Buy {char.name} in the Character Shop first.
              </span>
            </button>
          ) : afford ? (
            <button className="btn btn-gold w-full gap-2 text-[1.25rem]" style={{ minHeight: 54 }} onClick={() => onBuy(ability.id)}>
              BUY <CoinIcon className="h-7 w-7" /> {ability.price.toLocaleString()}
            </button>
          ) : (
            <div>
              <button className="btn btn-muted w-full gap-2 text-[1.1rem]" style={{ minHeight: 50 }} disabled>
                <CoinIcon className="h-6 w-6" /> {ability.price.toLocaleString()}
              </button>
              <div className="mt-2 rounded-2xl bg-black/35 p-2.5" data-testid="ability-progress">
                <div className="flex items-center justify-between text-[0.78rem] font-semibold text-violet-100">
                  <span>
                    Price <b className="text-white">{ability.price.toLocaleString()}</b>
                  </span>
                  <span>
                    Balance <b className="text-white">{save.coins.toLocaleString()}</b>
                  </span>
                </div>
                <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-black/50">
                  <div className="h-full rounded-full bg-gradient-to-r from-[#7fd0ff] to-[#5a8bff]" style={{ width: `${Math.min(100, (save.coins / ability.price) * 100)}%` }} />
                </div>
                <div className="mt-1 flex items-center justify-between text-[0.74rem] font-bold">
                  <span className="text-violet-100">Remaining: {(ability.price - save.coins).toLocaleString()} coins</span>
                  <span className="tabular-nums text-white">{Math.min(100, Math.round((save.coins / ability.price) * 100))}%</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* every character's ability, in character order */}
      <div className="scroll-thin min-h-0 flex-1 overflow-y-auto p-3">
        <p className="mb-2 text-center text-[0.76rem] font-semibold leading-snug text-violet-100">
          Each character has one exclusive ability. Buy the character first — buying it never grants the ability.
        </p>
        <div className="flex flex-col gap-2">
          {ABILITIES.map((a) => {
            const st = stateOf(a.id);
            const c = skinById(a.character);
            const enabled = equippedMap[a.character] === a.id;
            return (
              <div
                key={a.id}
                role="button"
                tabIndex={0}
                onClick={() => setSel(a.character)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") setSel(a.character);
                }}
                data-ability={a.id}
                data-state={st}
                className={`flex items-center gap-2.5 rounded-2xl border-2 p-2 text-left transition-colors ${rowTone(st)} ${sel === a.character ? "outline-2 outline-white/70 outline-offset-2" : ""}`}
              >
                <div className={`relative h-[52px] w-[52px] shrink-0 ${st === "locked" ? "opacity-45 saturate-50" : ""}`}>
                  <SkinPreview skin={c} />
                  {st === "locked" && (
                    <span className="absolute -bottom-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full border-2 border-[#1b0a3d] bg-black/80 text-violet-200">
                      <LockIcon className="h-3 w-3" />
                    </span>
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[0.72rem] font-bold uppercase tracking-wide text-violet-200">{c.name}</div>
                  <div className="truncate font-display text-[1.02rem] leading-tight text-white">{a.name}</div>
                  <div className="truncate text-[0.76rem] font-medium text-violet-100">{a.desc}</div>
                  {st === "locked" && (
                    <div className="mt-0.5 text-[0.7rem] font-bold uppercase tracking-wide text-[#ffb0c8]">Buy {c.name} first</div>
                  )}
                </div>
                <div className="flex shrink-0 flex-col items-end gap-1">
                  {st === "equipped" ? (
                    <span className="flex items-center gap-1 rounded-full bg-emerald-400 px-2 py-0.5 text-[0.66rem] font-bold uppercase text-[#06361b]">
                      <CheckIcon className="h-3 w-3" /> On
                    </span>
                  ) : st === "purchased" ? (
                    <span className="rounded-full border-2 border-teal-300 px-2 py-0.5 text-[0.66rem] font-bold uppercase text-teal-100">Owned</span>
                  ) : (
                    <span className={`flex items-center gap-1 font-display text-[0.95rem] ${st === "available" ? "text-[#ffd62e]" : "text-violet-300"}`}>
                      <CoinIcon className="h-4 w-4" />
                      {a.price.toLocaleString()}
                    </span>
                  )}
                  {st === "available" && (
                    <button
                      className="rounded-lg border-2 border-[#5a2f00] px-2 py-1 text-[0.66rem] font-bold uppercase disabled:opacity-60"
                      style={save.coins >= a.price
                        ? { background: "linear-gradient(180deg,#fff29a,#ffb300)", color: "#3b1a00", borderColor: "#5a2f00" }
                        : { background: "#3b2c58", color: "#cbb8ff", borderColor: "#150727" }}
                      onClick={(e) => {
                        e.stopPropagation();
                        onBuy(a.id);
                      }}
                      data-slot="ability-buy"
                      aria-label={`Buy ${a.name} for ${a.price.toLocaleString()} coins`}
                    >
                      {save.coins >= a.price ? "Buy" : "Need coins"}
                    </button>
                  )}
                  {enabled && st !== "equipped" && <span className="text-[0.62rem] font-bold uppercase text-emerald-300">enabled</span>}
                </div>
              </div>
            );
          })}
        </div>
        <BannerInset />
      </div>
    </Modal>
  );
}
