import type { HudState } from "../game/engine";

interface Props {
  ability: NonNullable<HudState["ability"]>;
  onTrigger: () => void;
}

/**
 * Dedicated in-game ability button. Only rendered for an owned + equipped ability,
 * and it swallows the pointer so it never doubles as a left/right steering touch.
 */
export function AbilityButton({ ability: a, onTrigger }: Props) {
  return (
    <button
      className="pointer-events-auto absolute select-none"
      style={{
        right: 14,
        bottom: "calc(78px + env(safe-area-inset-bottom))",
        width: 74,
        height: 74,
        touchAction: "none",
      }}
      onPointerDown={(e) => {
        e.stopPropagation();
        e.preventDefault();
        onTrigger();
      }}
      onPointerUp={(e) => e.stopPropagation()}
      onPointerMove={(e) => e.stopPropagation()}
      onContextMenu={(e) => e.preventDefault()}
      aria-label={a.ready ? `Use ${a.name}` : `${a.name} recharging`}
      data-testid="ability-button"
      data-ready={a.ready}
    >
      <span
        className="absolute inset-0 rounded-full border-[3px] border-[#1b0a3d]"
        style={{
          background: a.ready
            ? "radial-gradient(circle at 50% 32%, #fff6c8, #ffd166 46%, #f29100 100%)"
            : "linear-gradient(180deg,#3b2c58,#271a40)",
          boxShadow: a.ready
            ? "0 5px 0 #5a2f00, 0 0 22px rgba(255,214,46,0.6), inset 0 3px 0 rgba(255,255,255,0.55)"
            : "0 4px 0 #120a20, inset 0 2px 0 rgba(255,255,255,0.12)",
          opacity: a.ready ? 1 : 0.82,
        }}
      />
      {/* cooldown / charge ring */}
      <svg className="absolute inset-0" viewBox="0 0 100 100" aria-hidden="true">
        <circle
          cx="50"
          cy="50"
          r="44"
          fill="none"
          stroke={a.ready ? "#7dffb0" : "#5ff2ff"}
          strokeWidth="7"
          strokeLinecap="round"
          strokeDasharray={`${Math.max(0, Math.min(1, a.frac)) * 276} 276`}
          transform="rotate(-90 50 50)"
          opacity="0.95"
        />
      </svg>
      <span className="absolute inset-0 flex flex-col items-center justify-center leading-none">
        <span className="font-display text-[0.95rem] text-[#3b1a00]" style={a.ready ? undefined : { color: "#cbb8ff" }}>
          {a.ready ? "TAP" : `${Math.round(a.frac * 100)}%`}
        </span>
        {a.charges > 0 && (
          <span className="mt-0.5 rounded-full bg-black/40 px-1.5 text-[0.6rem] font-bold text-white">x{a.charges}</span>
        )}
      </span>
      <span className="absolute -bottom-5 left-0 right-0 truncate text-center text-[0.62rem] font-bold uppercase tracking-wide text-white" style={{ textShadow: "0 2px 0 rgba(15,4,30,0.9)" }}>
        {a.name}
      </span>
    </button>
  );
}
