/// <reference types="vite/client" />

interface ImportMetaEnv {
  /** "production" (default) or "development" — selects the AdMob ID set at build time. */
  readonly VITE_ADMOB_ENV?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
