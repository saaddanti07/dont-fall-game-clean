import { useCallback, useEffect, useRef, useState } from "react";
import { AbilityShopModal } from "./components/AbilityShopModal";
import { AudioSettingsModal } from "./components/AudioSettingsModal";
import { DailyRewardModal } from "./components/DailyRewardModal";
import { GameOver, type GameOverResult } from "./components/GameOver";
import { GameScreen } from "./components/GameScreen";
import { MainMenu } from "./components/MainMenu";
import { MissionsModal } from "./components/MissionsModal";
import { ShopModal } from "./components/ShopModal";
import { SplashScreen } from "./components/SplashScreen";
import { Toasts, type Toast } from "./components/Toasts";
import { WorldsModal } from "./components/WorldsModal";
import { VictoryScreen, type VictoryResult } from "./components/VictoryScreen";
import { audio } from "./game/audio";
import { ads } from "./game/ads";
import { INTERSTITIAL_EVERY } from "./game/ads-config";
import type { Game, GameOptions } from "./game/engine";
import { applyRun, evaluateAchievements, refreshPeriods, type Completed, type RunStats } from "./game/progression";
import { abilityById, checkAbilityBuy, equippedAbility } from "./game/abilities";
import { checkBuy, ordinalLabel, SECRET_SKIN, skinById, skinIndex } from "./game/skins";
import { activeStreak, canClaimDaily, dayKey, loadSave, nextStreak, persist, rewardForStreak, type SaveData } from "./game/storage";

type Screen = "menu" | "playing" | "over" | "victory";
type ModalName = "daily" | "shop" | "ability" | "missions" | "settings" | "worlds" | null;

/** Test hooks, only active when the page is opened with ?debug (never in normal play). */
function readDebug(): GameOptions | null {
  const q = new URLSearchParams(window.location.search);
  if (!q.has("debug")) return null;
  return { startMeters: Number(q.get("start") ?? 0) || 0, god: q.has("god"), bot: q.has("bot"), boss: q.has("boss") };
}

export default function App() {
  const [save, setSave] = useState<SaveData>(() => refreshPeriods(loadSave()));
  const saveRef = useRef(save);
  const [screen, setScreen] = useState<Screen>("menu");
  const [modal, setModal] = useState<ModalName>(null);
  // Recurring splash: true only on fresh launch (initial mount). Dismissed once
  // by timeout/tap and never re-armed, so returning from gameplay never replays it.
  const [showSplash, setShowSplash] = useState(true);
  const dismissSplash = useCallback(() => setShowSplash(false), []);
  const [runKey, setRunKey] = useState(0);
  const [runStart, setRunStart] = useState(0); // metres — set by the world select
  const [result, setResult] = useState<GameOverResult | null>(null);
  const [victory, setVictory] = useState<VictoryResult | null>(null);
  // --- AdMob state (all additive; gameplay and saves are untouched) ---
  const [reviveUsed, setReviveUsed] = useState(false);
  const [doubled, setDoubled] = useState(false);
  const [adBusy, setAdBusy] = useState(false);
  const adsState = useRef<{
    reviveUsed: boolean;
    doubled: boolean;
    recordedStats: RunStats | null;
  }>({ reviveUsed: false, doubled: false, recordedStats: null });
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [, setTick] = useState(0);
  const debug = useRef(readDebug()).current;
  const toastId = useRef(0);

  /** Single write path: updates state, the ref and localStorage synchronously (so a refresh can never lose or repeat a reward). */
  const mutate = useCallback((fn: (s: SaveData) => SaveData) => {
    const next = fn(saveRef.current);
    if (next === saveRef.current) return;
    saveRef.current = next;
    persist(next);
    audio.configure(next);
    setSave(next);
  }, []);

  useEffect(() => {
    persist(saveRef.current);
    audio.configure(saveRef.current);
    // roll missions over at midnight / when the app comes back to the foreground
    const check = () => {
      mutate(refreshPeriods);
      setTick((t) => t + 1);
    };
    const id = window.setInterval(check, 60000);
    document.addEventListener("visibilitychange", check);
    return () => {
      clearInterval(id);
      document.removeEventListener("visibilitychange", check);
    };
  }, [mutate]);

  const pushToasts = useCallback((items: Omit<Toast, "id">[]) => {
    if (!items.length) return;
    const withIds = items.slice(0, 3).map((t) => ({ ...t, id: ++toastId.current }));
    setToasts((cur) => [...cur, ...withIds]);
    window.setTimeout(() => setToasts((cur) => cur.filter((t) => !withIds.some((w) => w.id === t.id))), 3700);
  }, []);

  const completedToToasts = (c: Completed[]): Omit<Toast, "id">[] =>
    c.map((x) => ({
      title: x.kind === "achievement" ? "Achievement!" : x.kind === "weekly" ? "Weekly complete!" : "Mission complete!",
      sub: x.title,
      reward: x.reward,
    }));

  const update = useCallback((patch: Partial<SaveData>) => mutate((s) => ({ ...s, ...patch })), [mutate]);

  const click = () => {
    audio.unlock();
    audio.sfx("click");
  };

  // Initialize AdMob once at launch (consent → SDK). Never blocks the game.
  useEffect(() => {
    void ads.init().then((ok) => {
      if (ok) void ads.prepareInterstitial();
    });
    if (import.meta.env.DEV || debug) {
      (window as unknown as { __ads?: typeof ads }).__ads = ads;
    }
  }, []);

  // The live engine instance, published by GameScreen, so App can resume it on revive.
  const gameRef = useRef<Game | null>(null);

  /**
   * Rewarded revive: one per round.
   * Shows the rewarded ad FIRST, waits for official AdMob reward confirmation,
   * and ONLY then calls `gameRef.current?.revive()`.
   */
  const revive = useCallback(async () => {
    if (adsState.current.reviveUsed || adBusy || screen !== "over") return;
    if (!gameRef.current) return;
    setAdBusy(true);
    const reward = await ads.showRewarded("revive");
    setAdBusy(false);
    if (!reward) {
      pushToasts([{ title: "Ad not completed", sub: "No revive granted" }]);
      return;
    }
    if (gameRef.current.revive()) {
      adsState.current.reviveUsed = true;
      setReviveUsed(true);
      setScreen("playing");
    }
  }, [adBusy, screen, pushToasts]);

  /** Rewarded double coins: grants exactly the run's coin count, once, only after official reward confirmation. */
  const doubleCoins = useCallback(async () => {
    if (adsState.current.doubled || adBusy || !result || result.coins <= 0) return;
    setAdBusy(true);
    const reward = await ads.showRewarded("coins");
    setAdBusy(false);
    if (!reward) {
      pushToasts([{ title: "Ad not completed", sub: "No bonus coins granted" }]);
      return;
    }
    adsState.current.doubled = true;
    setDoubled(true);
    mutate((s) => ({ ...s, coins: s.coins + result.coins }));
    pushToasts([{ title: "Coins doubled!", sub: `+${result.coins} bonus coins` }]);
  }, [adBusy, result, mutate, pushToasts]);

  const play = (meters = 0) => {
    // Locked stages cannot be opened through a crafted UI event or another menu.
    const postGameEndless = meters === 10000 && saveRef.current.dragon.defeated;
    if (meters > 0 && !postGameEndless && saveRef.current.best < meters && saveRef.current.stats.highestWorld < Math.floor(meters / 500)) {
      audio.sfx("error");
      pushToasts([{ title: "Stage locked", sub: `Reach ${meters.toLocaleString()} m by clearing the previous stage first` }]);
      return;
    }
    click();
    setModal(null);
    adsState.current = { reviveUsed: false, doubled: false, recordedStats: null };
    setReviveUsed(false);
    setDoubled(false);
    setRunStart(meters);
    setRunKey((k) => k + 1);
    setScreen("playing");
  };

  const toMenu = () => {
    audio.setWorld(0);
    setScreen("menu");
  };

  const onCoin = useCallback((amount: number) => mutate((s) => ({ ...s, coins: s.coins + amount })), [mutate]);

  /** Fold a finished run into the save. `showOver` is false when the player quits from the pause menu. */
  const finishRun = useCallback(
    (stats: RunStats, showOver: boolean) => {
      const prev = adsState.current.recordedStats;
      const isFirstCompletion = prev === null;
      const effectiveRun: RunStats = prev
        ? {
            ...stats,
            distance: Math.max(0, stats.distance - prev.distance),
            score: Math.max(0, stats.score - prev.score),
            bonus: Math.max(0, stats.bonus - prev.bonus),
            coins: Math.max(0, stats.coins - prev.coins),
            platforms: Math.max(0, stats.platforms - prev.platforms),
            time: Math.max(0, stats.time - prev.time),
            powerups: Math.max(0, stats.powerups - prev.powerups),
            nearMisses: Math.max(0, stats.nearMisses - prev.nearMisses),
            bosses: Math.max(0, stats.bosses - prev.bosses),
            candies: Math.max(0, stats.candies - prev.candies),
          }
        : stats;
      adsState.current.recordedStats = { ...stats };

      const res = applyRun(saveRef.current, effectiveRun, {
        countGame: isFirstCompletion,
        fullDistance: stats.distance,
        fullScore: stats.score,
      });

      let nextSave = res.save;
      let shouldShowInterstitial = false;

      // Count only genuinely completed ordinary rounds (not manual exits from pause,
      // not boss fights, and never twice if the player revived in the same round).
      if (showOver && isFirstCompletion && !stats.wasBossFight) {
        const nextAdRounds = nextSave.adRounds + 1;
        const hitMilestone =
          nextAdRounds > 0 &&
          nextAdRounds % INTERSTITIAL_EVERY === 0 &&
          nextSave.lastInterstitialMilestone < nextAdRounds;
        nextSave = {
          ...nextSave,
          adRounds: nextAdRounds,
          lastInterstitialMilestone: hitMilestone ? nextAdRounds : nextSave.lastInterstitialMilestone,
        };
        shouldShowInterstitial = hitMilestone;
      }

      mutate(() => nextSave);

      if (showOver) {
        setResult({ distance: stats.distance, score: stats.score, bonus: stats.bonus, coins: stats.coins, best: nextSave.best, newBest: res.newBest, completed: res.completed });
        setScreen("over");
        audio.sfx("over");
        if (shouldShowInterstitial) {
          void ads.showInterstitial();
        }
        if (!adsState.current.reviveUsed) {
          void ads.prepareRewarded("revive");
        }
      } else {
        pushToasts(completedToToasts(res.completed));
      }
    },
    [mutate, pushToasts],
  );

  /** Final-stage victory: apply the run once, then grant the permanent first/replay reward. */
  const finishVictory = useCallback((stats: RunStats & { fightTime: number }) => {
    const s = saveRef.current;
    const firstVictory = !s.dragon.defeated;
    const reward = firstVictory ? 1000 : 250;
    const bestTime = s.dragon.bestTime > 0 ? Math.min(s.dragon.bestTime, stats.fightTime) : stats.fightTime;
    const rewarded: SaveData = {
      ...s,
      coins: s.coins + reward,
      owned: s.owned.includes(SECRET_SKIN.id) ? s.owned : [...s.owned, SECRET_SKIN.id],
      dragon: { defeated: true, wins: s.dragon.wins + 1, bestTime },
    };
    const res = applyRun(rewarded, stats);
    mutate(() => res.save);
    setVictory({ distance: stats.distance, score: stats.score, coins: stats.coins, fightTime: stats.fightTime, reward, firstVictory, completed: res.completed });
    setScreen("victory");
  }, [mutate]);

  /** ABILITY SHOP purchase: requires owning the character, deducts coins only on success. */
  const buyAbility = (id: string) => {
    const s = saveRef.current;
    const check = checkAbilityBuy(id, s);
    if (!check.ok) {
      audio.sfx("error");
      if (check.reason === "no-character") {
        const def = abilityById(id);
        pushToasts([{ title: "Ability locked", sub: `Buy ${def ? skinById(def.character).name : "its character"} in the Character Shop first` }]);
      } else if (check.reason === "funds") {
        const def = abilityById(id);
        pushToasts([{ title: "Not enough coins", sub: `You need ${def ? (def.price - s.coins).toLocaleString() : ""} more` }]);
      }
      return;
    }
    const def = check.ability;
    // buying an ability never changes characters and never equips silently:
    // the player equips it explicitly in the Ability Shop.
    const bought: SaveData = {
      ...s,
      coins: s.coins - def.price,
      abilities: { owned: [...s.abilities.owned, def.id], equipped: { ...s.abilities.equipped } },
    };
    const ev = evaluateAchievements(bought);
    mutate(() => ev.save);
    audio.sfx("buy");
    window.setTimeout(() => audio.sfx("unlock"), 90);
    pushToasts([{ title: `${def.name} unlocked!`, sub: `Equip it to use it with ${skinById(def.character).name}` }, ...completedToToasts(ev.completed)]);
  };

  /** Equip / unequip an owned ability for one specific character only. */
  const equipAbility = (characterId: string, abilityId: string | null) => {
    const s = saveRef.current;
    click();
    if (abilityId) {
      const def = abilityById(abilityId);
      if (!def || def.character !== characterId || !s.owned.includes(characterId) || !s.abilities.owned.includes(abilityId)) {
        audio.sfx("error");
        return;
      }
    }
    const equipped = { ...s.abilities.equipped };
    if (abilityId) equipped[characterId] = abilityId;
    else delete equipped[characterId];
    mutate((x) => ({ ...x, abilities: { owned: [...x.abilities.owned], equipped } }));
  };

  const claimDaily = () => {
    const s = saveRef.current;
    if (!canClaimDaily(s)) return;
    const streak = nextStreak(s);
    audio.sfx("reward");
    const claimed = { ...s, coins: s.coins + rewardForStreak(streak), streak, lastClaim: dayKey() };
    const ev = evaluateAchievements(claimed);
    mutate(() => ev.save);
    pushToasts(completedToToasts(ev.completed));
  };

  /** Sequential purchase: validated in the state layer, not only in the shop UI. */
  const buy = (id: string) => {
    const s = saveRef.current;
    const check = checkBuy(skinIndex(id), s.owned, s.coins);
    if (!check.ok) {
      // blocked — coins and the owned list are left completely untouched
      audio.sfx("error");
      if (check.reason === "sequence" && check.missing) {
        pushToasts([{ title: `Locked — buy ${ordinalLabel(skinIndex(check.missing.id))} first`, sub: `${check.missing.name} comes before ${skinById(id).name}` }]);
      } else if (check.reason === "funds") {
        pushToasts([{ title: "Not enough coins", sub: `You need ${check.need?.toLocaleString()} more` }]);
      }
      return;
    }
    const skin = check.skin;
    // a purchase never forces the character: equipped stays exactly as the player left it
    const bought = { ...s, coins: s.coins - skin.price, owned: [...s.owned, skin.id] };
    const ev = evaluateAchievements(bought);
    mutate(() => ev.save);
    audio.sfx("buy");
    window.setTimeout(() => audio.sfx("unlock"), 90);
    pushToasts([{ title: `${skin.name} unlocked!`, sub: "Select it in the shop whenever you like" }, ...completedToToasts(ev.completed)]);
  };

  const equip = (id: string) => {
    const s = saveRef.current;
    if (!s.owned.includes(id)) {
      audio.sfx("error");
      return;
    }
    click();
    mutate((x) => ({ ...x, equipped: id }));
  };

  const skin = skinById(save.equipped);
  const streak = activeStreak(save);

  return (
    <div className="fixed inset-0 flex justify-center bg-[#0d0418]">
      <div className="relative h-full w-full max-w-[480px] overflow-hidden font-body shadow-[0_0_60px_rgba(120,60,200,0.35)]">
        {showSplash ? (
          <SplashScreen onDone={dismissSplash} />
        ) : (
          <>
        {screen === "menu" && (
          <MainMenu
            coins={save.coins}
            best={save.best}
            totalDistance={save.stats.totalDistance}
            streak={streak}
            world={save.stats.highestWorld + 1}
            skin={skin}
            musicOn={save.musicOn}
            sfxOn={save.sfxOn}
            dailyReady={canClaimDaily(save)}
            showBanner={modal === null}
            onPlay={() => play(0)}
            onWorlds={() => {
              click();
              setModal("worlds");
            }}
            onDaily={() => {
              click();
              setModal("daily");
            }}
            onShop={() => {
              click();
              setModal("shop");
            }}
            onAbilities={() => {
              click();
              setModal("ability");
            }}
            onMissions={() => {
              click();
              setModal("missions");
            }}
            onSettings={() => {
              click();
              setModal("settings");
            }}
            onToggleMusic={() => {
              audio.unlock();
              update({ musicOn: !save.musicOn });
              audio.sfx("click");
            }}
            onToggleSfx={() => {
              audio.unlock();
              update({ sfxOn: !save.sfxOn });
              // play the click only when turning sounds on
              if (!save.sfxOn) setTimeout(() => audio.sfx("click"), 30);
            }}
          />
        )}

        {(screen === "playing" || screen === "over" || screen === "victory") && (
          <GameScreen
            key={runKey}
            skin={skin}
            debug={debug}
            startMeters={runStart || debug?.startMeters || 0}
            ability={equippedAbility(save)?.id ?? null}
            onCoin={onCoin}
            onGameOver={(r) => finishRun(r, true)}
            onVictory={finishVictory}
            gameRef={gameRef}
            onExit={(r) => {
              finishRun(r, false);
              toMenu();
            }}
            onRevive={revive}
          />
        )}

        {screen === "over" && result && (
          <GameOver
            result={result}
            onRestart={() => play(runStart)}
            onMenu={() => {
              click();
              toMenu();
            }}
            onRevive={revive}
            onDoubleCoins={doubleCoins}
            reviveUsed={reviveUsed}
            doubled={doubled}
            reviveBusy={adBusy}
            doubleBusy={adBusy}
          />
        )}

        {screen === "victory" && victory && (
          <VictoryScreen
            result={victory}
            onReplay={() => play(9500)}
            onEndless={() => play(10000)}
            onMenu={() => {
              click();
              toMenu();
            }}
          />
        )}

        {modal === "daily" && screen === "menu" && <DailyRewardModal save={save} onClaim={claimDaily} onClose={() => setModal(null)} />}
        {modal === "shop" && screen === "menu" && <ShopModal save={save} onBuy={buy} onEquip={equip} onClose={() => setModal(null)} />}
        {modal === "ability" && screen === "menu" && (
          <AbilityShopModal save={save} onBuy={buyAbility} onEquip={equipAbility} onClose={() => setModal(null)} />
        )}
        {modal === "missions" && screen === "menu" && <MissionsModal save={save} onClose={() => setModal(null)} />}
        {modal === "worlds" && screen === "menu" && (
          <WorldsModal
            save={save}
            onPlayAt={(m) => {
              click();
              play(m);
            }}
            onClose={() => setModal(null)}
          />
        )}
        {modal === "settings" && screen === "menu" && (
          <AudioSettingsModal save={save} onChange={update} onTestSfx={() => audio.sfx("click")} onClose={() => setModal(null)} />
        )}

        <Toasts items={toasts} />
          </>
        )}
      </div>
    </div>
  );
}

