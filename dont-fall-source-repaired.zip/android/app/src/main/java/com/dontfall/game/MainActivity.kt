package com.dontfall.game

import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import com.getcapacitor.BridgeActivity

/**
 * DON'T FALL — Android entry point.
 *
 * True immersive fullscreen:
 *  - status bar and navigation bar are hidden (API 30+ WindowInsetsController,
 *    classic systemUiVisibility flags on older devices),
 *  - IMMERSIVE STICKY: an edge swipe temporarily reveals the system bars,
 *    they fade out again on their own, and the app keeps running,
 *  - every time the activity regains window focus (returning from background,
 *    coming back from the app switcher, or after a transient bar reveal) the
 *    bars are hidden again — CSS alone cannot guarantee that on Android.
 *
 * This file replaces the generated MainActivity.kt (same package as the
 * appId in capacitor.config.ts). The GitHub Actions workflow copies it over
 * after `cap add android` so the change survives project regeneration.
 */
class MainActivity : BridgeActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyImmersiveFullscreen()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersiveFullscreen()
    }

    private fun applyImmersiveFullscreen() {
        val window = window ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // Edge-to-edge content: the WebView draws behind/under the system bars,
            // then the bars themselves are hidden.
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                // "Immersive sticky" behaviour:
                controller.systemBarsBehavior =
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        }
    }
}
