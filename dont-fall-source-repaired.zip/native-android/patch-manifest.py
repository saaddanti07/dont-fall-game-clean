#!/usr/bin/env python3
"""
Idempotently patches the Capacitor Android project for DON'T FALL:

  1. Points the <activity> at our immersive MainActivity (the template
     references com.getcapacitor.BridgeActivity on older versions).
  2. Lets the app extend into the display cutout (notch / punch-hole) so the
     whole physical screen is used.
  3. Sets the real app name and round launcher icon attribute.
  4. Registers the AdMob Application ID as a proper child <meta-data> inside
     <application>...</application> (test vs production selected by
     VITE_ADMOB_ENV at build time — the same switch the web bundle uses).
  5. Ensures Kotlin plugin support in android/build.gradle and
     android/app/build.gradle so MainActivity.kt compiles cleanly.
  6. Validates AndroidManifest.xml and strings.xml with an XML parser.

Safe to execute repeatedly after `npx cap add android` or `npx cap sync android`.
"""
import os
import re
import xml.etree.ElementTree as ET
from pathlib import Path

MANIFEST = Path("android/app/src/main/AndroidManifest.xml")
STRINGS = Path("android/app/src/main/res/values/strings.xml")
ROOT_GRADLE = Path("android/build.gradle")
APP_GRADLE = Path("android/app/build.gradle")
MAIN_ACTIVITY = "com.dontfall.game.MainActivity"

# SAFE DEFAULT: Google test ads. Real AdMob IDs are selected ONLY when
# VITE_ADMOB_ENV is explicitly "production". Missing, empty or unrecognised values
# resolve to "development", so a debug/dev build can never receive live IDs.
# This rule is mirrored in src/game/ads-config.ts — keep both in sync.
_ADMOB_RAW_ENV = (os.environ.get("VITE_ADMOB_ENV") or "").strip().lower()
ADMOB_ENV = "production" if _ADMOB_RAW_ENV == "production" else "development"
ADMOB_APP_ID = (
    "ca-app-pub-4047064090575681~7263910675"
    if ADMOB_ENV == "production"
    else "ca-app-pub-3940256099942544~3347511713"
)
ADMOB_META_NAME = "com.google.android.gms.ads.APPLICATION_ID"
ADMOB_META_TAG = (
    f'<meta-data android:name="{ADMOB_META_NAME}" '
    f'android:value="@string/admob_app_id" />'
)

m = MANIFEST.read_text(encoding="utf-8")

# Heal any previously malformed manifest where <meta-data .../> was inserted
# inside the unclosed <application ...> opening tag before its attributes.
m = re.sub(
    r'(<application\b)\s*<meta-data\s+android:name="com\.google\.android\.gms\.ads\.APPLICATION_ID"[^>]*/>\s*',
    r"\1\n        ",
    m,
)

if 'android:name="com.getcapacitor.BridgeActivity"' in m:
    m = m.replace(
        'android:name="com.getcapacitor.BridgeActivity"',
        f'android:name="{MAIN_ACTIVITY}"',
    )

if "windowLayoutInDisplayCutoutMode" not in m:
    m = re.sub(
        r"(<activity\b)(\s)",
        r'\1 android:windowLayoutInDisplayCutoutMode="shortEdges|always"\2',
        m,
        count=1,
    )

if "android:roundIcon" not in m:
    m = m.replace(
        'android:icon="@mipmap/ic_launcher"',
        'android:icon="@mipmap/ic_launcher"\n        android:roundIcon="@mipmap/ic_launcher_round"',
        1,
    )

# Insert AdMob <meta-data> as a proper child element AFTER the complete
# <application ...> opening tag.
if ADMOB_META_NAME not in m:
    m = re.sub(
        r"(<application\b[^>]*>)",
        rf"\1\n        {ADMOB_META_TAG}",
        m,
        count=1,
    )

MANIFEST.write_text(m, encoding="utf-8")

s = STRINGS.read_text(encoding="utf-8")

# Android string resources need the apostrophe escaped: DON\'T FALL
s = re.sub(
    r'(<string name="app_name">)[^<]*(</string>)',
    r"\1DON\\'T FALL\2",
    s,
    count=1,
)

if 'name="admob_app_id"' not in s:
    s = s.replace(
        "</resources>",
        f'    <string name="admob_app_id">{ADMOB_APP_ID}</string>\n</resources>',
    )
else:
    s = re.sub(
        r'(<string name="admob_app_id">)[^<]*(</string>)',
        rf"\g<1>{ADMOB_APP_ID}\g<2>",
        s,
        count=1,
    )

STRINGS.write_text(s, encoding="utf-8")

# Ensure Kotlin support is enabled for MainActivity.kt in Gradle.
if ROOT_GRADLE.exists():
    rg = ROOT_GRADLE.read_text(encoding="utf-8")
    if "kotlin-gradle-plugin" not in rg:
        rg = re.sub(
            r"(dependencies\s*\{\s*\n)",
            r'\1        classpath "org.jetbrains.kotlin:kotlin-gradle-plugin:2.2.20"\n',
            rg,
            count=1,
        )
        ROOT_GRADLE.write_text(rg, encoding="utf-8")

if APP_GRADLE.exists():
    ag = APP_GRADLE.read_text(encoding="utf-8")
    if "kotlin-android" not in ag:
        ag = ag.replace(
            "apply plugin: 'com.android.application'",
            "apply plugin: 'com.android.application'\napply plugin: 'kotlin-android'",
            1,
        )
    if "kotlinOptions" not in ag:
        ag = re.sub(
            r"(buildTypes\s*\{[\s\S]*?\n    \})",
            r"\1\n    compileOptions {\n        sourceCompatibility JavaVersion.VERSION_21\n        targetCompatibility JavaVersion.VERSION_21\n    }\n    kotlinOptions {\n        jvmTarget = '21'\n    }",
            ag,
            count=1,
        )
    APP_GRADLE.write_text(ag, encoding="utf-8")

# Validate XML structure and confirm <meta-data> is a direct child of <application>.
ANDROID_NS = "{http://schemas.android.com/apk/res/android}"
manifest_tree = ET.parse(MANIFEST)
manifest_root = manifest_tree.getroot()
app_el = manifest_root.find("application")
if app_el is None:
    raise RuntimeError("AndroidManifest.xml is missing <application>")

meta_nodes = [
    el
    for el in app_el.findall("meta-data")
    if el.attrib.get(f"{ANDROID_NS}name") == ADMOB_META_NAME
]
if len(meta_nodes) != 1:
    raise RuntimeError(
        f"Expected exactly 1 AdMob <meta-data> child under <application>, found {len(meta_nodes)}"
    )

strings_tree = ET.parse(STRINGS)
admob_nodes = [
    el
    for el in strings_tree.getroot().findall("string")
    if el.attrib.get("name") == "admob_app_id"
]
if len(admob_nodes) != 1 or admob_nodes[0].text != ADMOB_APP_ID:
    raise RuntimeError("strings.xml admob_app_id validation failed")

print(
    f"native-android patches applied & XML validated "
    f"(MainActivity, display cutout, app name, AdMob App ID [{ADMOB_ENV}: {ADMOB_APP_ID}])"
)
