#!/usr/bin/env bash
# Applies the DON'T FALL launcher icon (generated from the game's own renderers
# by scripts/generate-icon.mjs) into the Capacitor Android project.
#
# Idempotent: safe to run after every `npx cap add android` / `npx cap sync android`.
# The GitHub Actions workflow runs this so the icon survives project regeneration.
set -euo pipefail
cd "$(dirname "$0")/.."

SRC="native-android/icon/res"
DST="android/app/src/main/res"

if [ ! -d "$SRC" ]; then
  echo "icon assets missing — run: node scripts/generate-icon.mjs" >&2
  exit 1
fi
if [ ! -d "$DST" ]; then
  echo "android project missing — run: npx cap add android" >&2
  exit 1
fi

# Remove the Capacitor template's placeholder icon art so it can never shadow
# (or duplicate) the real assets:
#   drawable/ic_launcher_background.xml      (vector)  -> replaced by drawable-nodpi PNG
#   drawable-v24/ic_launcher_foreground.xml  (vector)  -> replaced by mipmap PNGs
#   values/ic_launcher_background.xml        (color)   -> unused once background is a PNG
rm -f "$DST/drawable/ic_launcher_background.xml"
rm -f "$DST/drawable-v24/ic_launcher_foreground.xml"
rm -f "$DST/values/ic_launcher_background.xml"
rmdir "$DST/drawable-v24" 2>/dev/null || true

# Copy every generated density + adaptive layer + adaptive XML.
cp -R "$SRC/." "$DST/"

echo "launcher icon applied:"
find "$DST" -name 'ic_launcher*' | sort | sed 's/^/  /'
