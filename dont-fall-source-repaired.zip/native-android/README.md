# native-android — persistent native overrides

`npx cap add android` regenerates `android/` from the Capacitor template, which
would wipe out any manual native edits. Instead of editing `android/` directly,
we keep the native changes **here** and re-apply them:

| File | Purpose |
| --- | --- |
| `MainActivity.kt` | Replaces the generated activity. Hides the status bar + navigation bar with **immersive sticky** behaviour (API 30+ `WindowInsetsController`, legacy flags below that) and re-applies fullscreen every time the app regains window focus. |
| `patch-manifest.py` | Idempotent patch for `AndroidManifest.xml` (activity name guard, display cutout, `roundIcon`) and `strings.xml` (real app name). |
| `apply-icons.sh` | Copies the generated launcher icon (`icon/res/**`) into `android/`, removing the Capacitor template's placeholder icon art first. |
| `icon/` | The launcher icon assets, **generated from the game's own renderers** by `scripts/generate-icon.mjs` (see below). Committed so CI never needs a browser. |

Applied locally or in CI by:

```bash
npx cap add android          # once (or: npx cap sync android if android/ exists)
cp native-android/MainActivity.kt android/app/src/main/java/com/dontfall/game/MainActivity.kt
python3 native-android/patch-manifest.py
```

The package `com.dontfall.game` in `MainActivity.kt` **must** match `appId` in
`capacitor.config.ts`. If you change the appId, change it here too.

Building the APK is done by the GitHub Actions workflow
(`.github/workflows/android-apk.yml`); the same commands work with a local
Android Studio / SDK.

## Launcher icon

The icon is a miniature of the actual game scene, not new artwork. It is produced
by `scripts/generate-icon.mjs`, which bundles and executes the game's own drawing
code in a headless canvas:

- `src/game/sprites.ts` → `drawPlayer` (with `ORIGINAL` from `src/game/skins.ts`), `drawPlatform`, `drawCoin`
- `src/game/worlds.ts` → `drawWorldBackground(ctx, 0, …)` (World 1: Cave)
- `src/game/engine.ts` → `Game.prototype.drawLava` (the real lava renderer)

Regenerate after changing any of that art:

```bash
node scripts/generate-icon.mjs     # writes native-android/icon/**
bash native-android/apply-icons.sh # copies into android/
```

Outputs: legacy `ic_launcher` / `ic_launcher_round` PNGs at mdpi–xxxhdpi
(48–192 px), adaptive `ic_launcher_foreground` PNGs (108–432 px, content inside
the 66 dp safe zone), a `drawable-nodpi/ic_launcher_background.png` (cave + lava),
`mipmap-anydpi-v26` adaptive XML (incl. Android 13 monochrome), a 512 px Play
Store icon and a 1024 px preview. The workflow applies all of it on every build,
so the icon survives `cap add android` regeneration.

## AdMob (Google Mobile Ads)

The app uses `@capacitor-community/admob` (v8.2.1, matching Capacitor 8.6).
Web-side code lives in `src/game/ads.ts` + `src/game/ads-config.ts`; the native
App ID is written by `patch-manifest.py` from the same build-time switch.

| Build | `VITE_ADMOB_ENV` | AdMob App ID | Ad unit IDs |
| --- | --- | --- | --- |
| Development (safe default) | unset / empty / `development` | `ca-app-pub-3940256099942544~3347511713` | Google's official test units |
| Production (explicit opt-in) | `production` | `ca-app-pub-4047064090575681~7263910675` | the owner's real units |

Switching: `npm run build` now builds with **Google test ads** (safe default);
set `VITE_ADMOB_ENV=production` to opt in to real IDs. The rule is identical in
`src/game/ads-config.ts` and `native-android/patch-manifest.py`: only an explicit
`production` selects production, and missing/empty/unrecognised values fall back
to development. In CI, the workflow's `admob_env` input (default `development`)
drives both the Vite build and the manifest patch. Never test with real IDs on a
dev device.

Ad placements:
- **Banner** — main menu, Character Shop, Ability Shop (never in gameplay).
  The web layout reserves space via `BannerInset`, so buttons are never covered.
- **Interstitial** — once after every 3 completed rounds, shown when returning
  to the menu (never mid-run, never during a boss fight).
- **Rewarded Revive** — optional button on the Game Over screen; one per round,
  granted only on the SDK reward callback.
- **Rewarded Coins** — optional "double the coins from this round" button on the
  Game Over screen; one per round, granted only on the reward callback.

Consent: Google UMP is requested before SDK initialization; ads only load when
`canRequestAds` is true. On web, every ad call is a safe no-op.
